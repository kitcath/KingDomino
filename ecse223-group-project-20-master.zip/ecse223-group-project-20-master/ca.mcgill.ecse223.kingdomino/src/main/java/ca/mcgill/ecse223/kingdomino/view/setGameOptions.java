package ca.mcgill.ecse223.kingdomino.view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.GridBagLayout;
import javax.swing.JButton;
import java.awt.GridBagConstraints;
import javax.swing.JLabel;
import java.awt.Insets;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.ActionEvent;
import javax.swing.JToggleButton;

import ca.mcgill.ecse223.kingdomino.controller.Controller;
import ca.mcgill.ecse223.kingdomino.controller.InvalidInputException;
import ca.mcgill.ecse223.kingdomino.model.Game;

public class setGameOptions {

	public JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void mainOptions() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					setGameOptions window = new setGameOptions();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public setGameOptions() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		frame.getContentPane().setLayout(gridBagLayout);
		
		JLabel lblNewLabel = new JLabel("Number of Players");
		lblNewLabel.setFont(new Font("Yu Gothic", Font.PLAIN, 18));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 2;
		gbc_lblNewLabel.gridy = 1;
		frame.getContentPane().add(lblNewLabel, gbc_lblNewLabel);
		
		JLabel lblBonusOptions = new JLabel("Bonus Options");
		lblBonusOptions.setFont(new Font("Yu Gothic", Font.PLAIN, 18));
		GridBagConstraints gbc_lblBonusOptions = new GridBagConstraints();
		gbc_lblBonusOptions.insets = new Insets(0, 0, 5, 5);
		gbc_lblBonusOptions.gridx = 5;
		gbc_lblBonusOptions.gridy = 1;
		frame.getContentPane().add(lblBonusOptions, gbc_lblBonusOptions);
		
		JButton button_2player = new JButton("2");
		button_2player.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Controller.setNumberPlayers(2);
				} catch (InvalidInputException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		button_2player.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
		GridBagConstraints gbc_startthegame = new GridBagConstraints();
		gbc_startthegame.insets = new Insets(0, 0, 5, 5);
		gbc_startthegame.gridx = 2;
		gbc_startthegame.gridy = 3;
		frame.getContentPane().add(button_2player, gbc_startthegame);
		
		JToggleButton tglbtnH = new JToggleButton("Harmony");
		GridBagConstraints gbc_tglbtnH = new GridBagConstraints();
		gbc_tglbtnH.insets = new Insets(0, 0, 5, 5);
		gbc_tglbtnH.gridx = 5;
		gbc_tglbtnH.gridy = 3;
		frame.getContentPane().add(tglbtnH, gbc_tglbtnH);
		tglbtnH.addItemListener(itemListenerH);
		
		JButton button_3player = new JButton("3");
		button_3player.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
		GridBagConstraints gbc_button_1 = new GridBagConstraints();
		gbc_button_1.insets = new Insets(0, 0, 5, 5);
		gbc_button_1.gridx = 2;
		gbc_button_1.gridy = 4;
		frame.getContentPane().add(button_3player, gbc_button_1);
		button_3player.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Controller.setNumberPlayers(3);
				} catch (InvalidInputException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		
		JButton button_4player = new JButton("4");
		button_4player.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Controller.setNumberPlayers(4);
				} catch (InvalidInputException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		
		JToggleButton tglMK = new JToggleButton("Middle Kingdom");
		GridBagConstraints gbc_tglMK = new GridBagConstraints();
		gbc_tglMK.insets = new Insets(0, 0, 5, 5);
		gbc_tglMK.gridx = 5;
		gbc_tglMK.gridy = 4;
		frame.getContentPane().add(tglMK, gbc_tglMK);
		button_4player.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
		GridBagConstraints gbc_btnMK = new GridBagConstraints();
		gbc_btnMK.insets = new Insets(0, 0, 5, 5);
		gbc_btnMK.gridx = 2;
		gbc_btnMK.gridy = 5;
		frame.getContentPane().add(button_4player, gbc_btnMK);
		
		JButton startthegame = new JButton("START");
		GridBagConstraints gbc_startthegame1 = new GridBagConstraints();
		gbc_startthegame1.insets = new Insets(0, 0, 0, 5);
		gbc_startthegame1.gridx = 3;
		gbc_startthegame1.gridy = 6;
		frame.getContentPane().add(startthegame, gbc_startthegame1);
		
		tglMK.addItemListener(itemListenerMK);
	}
	
	// ItemListener is notified whenever you click on the Button 
    ItemListener itemListenerMK = new ItemListener() { 

        // itemStateChanged() method is invoked automatically 
        // whenever you click or unclick on the Button. 
        public void itemStateChanged(ItemEvent itemEvent) 
        { 

            // event is generated in button 
            int state = itemEvent.getStateChange(); 

            // if selected print selected in console 
            if (state == ItemEvent.SELECTED) { 
                System.out.println("Middle Kingdom Selected"); 
                try {
					Controller.setIsUsingMiddleKingdom(true);
				} catch (InvalidInputException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            } 
            else { 

                // else print deselected in console 
                System.out.println("Middle Kingdom Deselected"); 
                try {
					Controller.setIsUsingMiddleKingdom(false);
				} catch (InvalidInputException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            } 
        } 
    }; 
    
    ItemListener itemListenerH = new ItemListener() { 

        // itemStateChanged() method is invoked automatically 
        // whenever you click or unclick on the Button. 
        public void itemStateChanged(ItemEvent itemEvent) 
        { 

            // event is generated in button 
            int state = itemEvent.getStateChange(); 

            // if selected print selected in console 
            if (state == ItemEvent.SELECTED) { 
                System.out.println("Harmony Selected"); 
                try {
					Controller.setIsUsingHarmony(true);
				} catch (InvalidInputException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            } 
            else { 

                // else print deselected in console 
                System.out.println("Harmony Deselected"); 
                try {
					Controller.setIsUsingHarmony(false);
				} catch (InvalidInputException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            } 
        } 
    }; 
    
    
}
