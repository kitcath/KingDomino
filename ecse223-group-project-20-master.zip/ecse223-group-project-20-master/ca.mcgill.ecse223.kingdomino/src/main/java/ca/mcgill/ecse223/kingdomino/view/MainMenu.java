package ca.mcgill.ecse223.kingdomino.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

import ca.mcgill.ecse223.kingdomino.KingdominoApplication;
import ca.mcgill.ecse223.kingdomino.controller.Controller;
import ca.mcgill.ecse223.kingdomino.controller.InvalidInputException;
import ca.mcgill.ecse223.kingdomino.model.Game;
import ca.mcgill.ecse223.kingdomino.model.User;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.GridLayout;
import javax.swing.BoxLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import javax.swing.JButton;
import javax.swing.JComboBox;

import java.awt.Insets;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.Font;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JDesktopPane;
import javax.swing.JTextField;

public class MainMenu extends JFrame {
	/**
	 * This class displays the main menu of the application. A user can either start a new game,
	 * load an old game, search a users statistics or exit the application
	 * @author Vadim Tuchila, Alexandra Gafencu & Catherine Van Gheluwe
	 */
	 

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainMenu frame = new MainMenu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	
	
	public MainMenu() {
		getContentPane().setBackground(new Color(224, 255, 255));
		setTitle("Kingdomino");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(224, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setBounds(100, 100, 1599, 918);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(0, 0, 1024, 266);
		lblNewLabel.setIcon(new ImageIcon(MainMenu.class.getResource("/viewresources/WZHJ9592.PNG")));
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(576, -59, 1024, 983);
		lblNewLabel_1.setIcon(new ImageIcon(MainMenu.class.getResource("/viewresources/CastleMenu.PNG")));
		getContentPane().setLayout(null);
		getContentPane().add(lblNewLabel);
		getContentPane().add(lblNewLabel_1);
		
		JButton btnStart = new JButton("New Game");
		btnStart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//double click the button after there
				
				setVisible(false); //you can't see me!
				
				Game game = new Game (48, KingdominoApplication.getKingdomino());
				KingdominoApplication.getKingdomino().setCurrentGame(game);
				AStartMenu start = new AStartMenu();
				start.newScreen();
			}
		});
		btnStart.setBackground(new Color(255, 51, 0));
		btnStart.setFont(new Font("Berlin Sans FB", Font.PLAIN, 17));
		btnStart.setBounds(171, 320, 262, 70);
		getContentPane().add(btnStart);
		
		JButton btnLoad = new JButton("Load");
		btnLoad.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {
							LoadFilePathWindow window = new LoadFilePathWindow();
							window.getFrame().setVisible(true);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
			}
		});
		btnLoad.setBackground(new Color(255, 204, 51));
		btnLoad.setFont(new Font("Berlin Sans FB", Font.PLAIN, 17));
		btnLoad.setBounds(171, 465, 262, 70);
		getContentPane().add(btnLoad);
		
		JButton btnUserStats = new JButton("User Stats");
		btnUserStats.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				SearchAUser search = new SearchAUser();
				search.viewStatistics();
				
			}
		});
		
		
		btnUserStats.setBackground(new Color(102, 255, 0));
		btnUserStats.setFont(new Font("Berlin Sans FB", Font.PLAIN, 17));
		btnUserStats.setBounds(171, 600, 262, 70);
		getContentPane().add(btnUserStats);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnExit.setFont(new Font("Berlin Sans FB", Font.PLAIN, 17));
		btnExit.setBackground(new Color(102, 204, 255));
		btnExit.setBounds(171, 732, 262, 70);
		getContentPane().add(btnExit);
		
		
		
	}

	
}

