package ca.mcgill.ecse223.kingdomino.persistence;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import ca.mcgill.ecse223.kingdomino.model.Kingdomino;


import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

import ca.mcgill.ecse223.kingdomino.KingdominoApplication;
import ca.mcgill.ecse223.kingdomino.model.Kingdomino;

/*
 * Class implementing the load and save methods for KingdominoApplication
 * Author : ECSE-223 course material (+ contributions : Vadim Tuchila & Catherine Van Gheluwe)
 */

public class KingDominoPersistence {
	
	
	public static ArrayList<Object> files = new ArrayList<Object>(); //ArrayList of previously saved files

	public static String filename = "data.txt";

	private static File aFile;

	private static Object Kingdomino;
	
	
	public static void save(Kingdomino kingDomino) {
		
	
		for(int i = 0; i <= files.size(); i++) {
			if(files.contains(kingDomino)) {
				files.remove(kingDomino);
				files.add(files.size(), kingDomino); //save the object kingDomino to the files list
				break; // once it found the first instance of the
			} else {
			files.add(files.size(), kingDomino);
			break;
			}
		} 
		
		PersistenceObjectStream.serialize(kingDomino);
	}
	
	public static Kingdomino load(String fileName) {
		PersistenceObjectStream.setFilename(fileName);
		Kingdomino kingDomino = (Kingdomino) PersistenceObjectStream.deserialize();
		
		// model cannot be loaded - create empty Kingdomino
		if (kingDomino == null) {
			kingDomino = new Kingdomino();
		}
		else {
			kingDomino.reinitialize(); 
		}
		return kingDomino;
	}
	
	
	
	public static ArrayList<Object>  getFiles(){
		return files;
	}
	public static void setFilename(String newFilename) {
		filename = newFilename;
	}
	
	public static String getFile(String file) throws Exception {
		Kingdomino kingdomino = load(file);
		if(kingdomino == null) {
			throw new Exception("file does not exist");
		}else {
			return file;
		}
	}
	
	
	public static  Kingdomino IntoObject( String filename) {
		
		Kingdomino kingdomino = new Kingdomino();
		File f1 = new File(filename);
		files.add(files.size(), f1);
		files.get(files.size());
		return kingdomino;
	
	}

	public static String getFileName(String filename) {

		//List<String> namesOfFiles;
		for(int i =0; i< files.size(); i++) {
			String aName = ((File) files.get(i)).getName();
			if(aName.contentEquals(filename)) {
				return (String) ((File) files.get(i)).getName();
			} else {
				//add the kingdomino object at the end of the list
				files.add(files.size(), IntoObject(filename));
				return (String) ((File) files.get(files.size())).getName();

			}
		}	

		return filename;		
	}

	

}
