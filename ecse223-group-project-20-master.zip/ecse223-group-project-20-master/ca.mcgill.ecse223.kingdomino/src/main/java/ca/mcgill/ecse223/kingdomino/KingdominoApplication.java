package ca.mcgill.ecse223.kingdomino;


import java.awt.EventQueue;

import ca.mcgill.ecse223.kingdomino.model.Gameplay;
import ca.mcgill.ecse223.kingdomino.model.Kingdomino;
import ca.mcgill.ecse223.kingdomino.persistence.KingDominoPersistence;
import ca.mcgill.ecse223.kingdomino.view.AStartMenu;
import ca.mcgill.ecse223.kingdomino.view.MainMenu;
import ca.mcgill.ecse223.kingdomino.view.setGameOptions;

public class KingdominoApplication {

	private static Kingdomino kingdomino;
	private static Gameplay stateMachine;

	/**
	 * @author Ryad Ammar
	 * Launches application
	 */
	public static void main(String[] args) {
		System.out.println("Hello World!");
		stateMachine = new Gameplay();
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainMenu frame = new MainMenu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public static Gameplay getStateMachine() {
		return stateMachine;
	}
	
	public static void setStateMachine(Gameplay sm) {
		stateMachine = sm;
	}
	
	public static Kingdomino getKingdomino() {
		if (kingdomino == null) {
			kingdomino = KingDominoPersistence.load(KingDominoPersistence.filename);
		}

		return kingdomino;
	}

	public static void setKingdomino(Kingdomino kd) {
		kingdomino = kd;
	}
}
