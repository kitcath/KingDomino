package ca.mcgill.ecse223.kingdomino.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import ca.mcgill.ecse223.kingdomino.KingdominoApplication;
import ca.mcgill.ecse223.kingdomino.controller.Controller;
import ca.mcgill.ecse223.kingdomino.controller.InvalidInputException;
import ca.mcgill.ecse223.kingdomino.model.Domino;
import ca.mcgill.ecse223.kingdomino.model.Game;
import ca.mcgill.ecse223.kingdomino.model.Gameplay;
import ca.mcgill.ecse223.kingdomino.model.Kingdomino;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JRadioButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JToggleButton;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.Toolkit;

public class AStartMenu extends JFrame {
	
	/**
	 * initiates the beginning of a game. It requires the user to input their names 
	 * and the different game modes of the application
	 * @author catherine van gheluwe, Alexandra Gafencu, Vadim Tuchila && Ryad Ammar
	 */

	private JPanel contentPane;
	private JLabel lblGameMode;
	private JComboBox comboBox_1;
	private JLabel lblNewLabel_5;
	private JLabel lblNewLabel_6;
	private JLabel lblGameMode_1;
	private JLabel lblNewLabel_7;
	private JComboBox numPlayerComboBox;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;

	private int numPlayers = 4;
	boolean setIsUsingHarmony = false;
	boolean setIsUsingMiddleKingdom = false;
	
	
	private JToggleButton tglMiddleKingdom;
	private JToggleButton tglbtnHarmony;
	
	
	

	/**
	 * Launch the application.
	 */
	public static void newScreen() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AStartMenu frame = new AStartMenu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}



	/**
	 * @author Ryad Ammar
	 * Set game options menu
	 */
	public AStartMenu() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(AStartMenu.class.getResource("/viewresources/icons8-castle-50.png")));
		setTitle("Kingdomino");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1599, 918);
		contentPane = new JPanel();

		contentPane.setBackground(new Color(224, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		JLabel lblNewLabel = new JLabel("Number of Players");
		lblNewLabel.setBounds(1152, 1049, 105, 16);

		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(1275, 1046, 69, 22);

		lblGameMode = new JLabel("Game Mode");
		lblGameMode.setBounds(1152, 1009, 105, 16);

		comboBox_1 = new JComboBox();
		comboBox_1.setBounds(1324, 1006, 69, 22);

		lblNewLabel_5 = new JLabel("");
		lblNewLabel_5.setBounds(289, 439, 0, 0);

		lblGameMode_1 = new JLabel("Select the Game Mode");
		lblGameMode_1.setFont(new Font("Berlin Sans FB", Font.PLAIN, 17));
		lblGameMode_1.setBounds(710, 317, 167, 16);

		lblNewLabel_7 = new JLabel("Number of Players");
		lblNewLabel_7.setFont(new Font("Berlin Sans FB", Font.PLAIN, 17));
		lblNewLabel_7.setBounds(696, 426, 137, 16);

		numPlayerComboBox = new JComboBox();
		numPlayerComboBox.setBackground(new Color(255, 250, 205));
		numPlayerComboBox.setBounds(845, 424, 34, 22);
		numPlayerComboBox.setMaximumRowCount(3);
		numPlayerComboBox.addItem("4");
		numPlayerComboBox.addItem("3");
		numPlayerComboBox.addItem("2");
		
		

		// Create an ActionListener for the JComboBox component.
		numPlayerComboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				// Get the source of the component, which is our combo
				// box.
				JComboBox comboBox = (JComboBox) event.getSource();

				// Print the selected items and the action command.
				Object selected = comboBox.getSelectedItem();

				numPlayers = Integer.valueOf((String) selected);

				System.out.println("Selected number of players  = " + numPlayers);

			}
		});
		
		textField_5 = new JTextField();
		textField_5.setBounds(748, 529, 131, 22);
		textField_5.setColumns(10);
		contentPane.add(textField_5);
		textField_5.setText("");
		
		textField_6 = new JTextField();
		textField_6.setBounds(748, 583, 131, 22);
		textField_6.setColumns(10);
		contentPane.add(textField_6);
		textField_6.setText("");
		
		
		
		textField_3 = new JTextField();
		textField_3.setBounds(748, 638, 131, 22);
		textField_3.setColumns(10);
		contentPane.add(textField_3);
		textField_3.setText("");
		
		
		textField_4 = new JTextField();
		textField_4.setBounds(748, 695, 131, 22);
		textField_4.setColumns(10);
		contentPane.add(textField_4);
		textField_4.setText("");
		
	
		JLabel lblNewLabel_3_1 = new JLabel("");
		lblNewLabel_3_1.setBounds(684, 675, 52, 50);
		lblNewLabel_3_1.setIcon(new ImageIcon(AStartMenu.class.getResource("/viewresources/Webp.net-resizeimage.png")));

		JLabel lblNewLabel_1_1 = new JLabel("");
		lblNewLabel_1_1.setBounds(684, 612, 51, 50);
		lblNewLabel_1_1.setIcon(new ImageIcon(AStartMenu.class.getResource("/viewresources/Webp.net-resizeimage (1).png")));

		JLabel lblNewLabel_2_1 = new JLabel("");
		lblNewLabel_2_1.setBounds(684, 560, 51, 50);
		lblNewLabel_2_1.setIcon(new ImageIcon(AStartMenu.class.getResource("/viewresources/Webp.net-resizeimage (2).png")));

		JLabel lblNewLabel_4_1 = new JLabel("");
		lblNewLabel_4_1.setBounds(684, 510, 51, 50);
		lblNewLabel_4_1.setIcon(new ImageIcon(AStartMenu.class.getResource("/viewresources/Webp.net-resizeimage (3).png")));
		
		takenBlue = new JLabel("Invalid name");
		takenBlue.setForeground(Color.RED);
		takenBlue.setFont(new Font("Berlin Sans FB", Font.PLAIN, 17));
		takenBlue.setBounds(891, 531, 98, 16);
		takenBlue.setVisible(false);
		contentPane.add(takenBlue);
		
		takenBlue_1 = new JLabel("Invalid name");
		takenBlue_1.setForeground(Color.RED);
		takenBlue_1.setFont(new Font("Berlin Sans FB", Font.PLAIN, 17));
		takenBlue_1.setBounds(891, 697, 98, 16);
		takenBlue_1.setVisible(false);
		contentPane.add(takenBlue_1);
		
		takenBlue_2 = new JLabel("Invalid name");
		takenBlue_2.setForeground(Color.RED);
		takenBlue_2.setFont(new Font("Berlin Sans FB", Font.PLAIN, 17));
		takenBlue_2.setBounds(891, 586, 98, 16);
		takenBlue_2.setVisible(false);
		contentPane.add(takenBlue_2);
		
		takenBlue_3 = new JLabel("Invalid name");
		takenBlue_3.setForeground(Color.RED);
		takenBlue_3.setFont(new Font("Berlin Sans FB", Font.PLAIN, 17));
		takenBlue_3.setBounds(891, 641, 98, 16);
		takenBlue_3.setVisible(false);
		contentPane.add(takenBlue_3);
	
		JButton startButton = new JButton("START");
		startButton.setBackground(new Color(255, 51, 0));
		startButton.setFont(new Font("Berlin Sans FB", Font.PLAIN, 17));
		startButton.setBounds(748, 770, 89, 41);
		startButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				List<String> namesToBeAdded =new ArrayList<String>();
				List<JLabel> specialCharacters = new ArrayList<JLabel>();
				namesToBeAdded.add(textField_5.getText());
				namesToBeAdded.add(textField_6.getText());
				namesToBeAdded.add( textField_3.getText());
				namesToBeAdded.add(textField_4.getText());
				
				specialCharacters.add(takenBlue);
				specialCharacters.add(takenBlue_2 );
				specialCharacters.add(takenBlue_3);
				specialCharacters.add(takenBlue_1);
				
				boolean valid;
				
					
				try{
					
					int count = 0;
					
					for(int i = 0; i < namesToBeAdded.size(); i++) {
						valid = Controller.specialCharacters(namesToBeAdded.get(i));
						
						if(valid) {
							specialCharacters.get(i).setVisible(true);
							count++;
						}
					
					}
					if(count > 0) {
						
						JOptionPane.showMessageDialog(contentPane,"oh no!Usernames are invalid.No special characters are allowed", "Yikes",JOptionPane.ERROR_MESSAGE);
						return;
					
					}
					
				Controller.startANewGame(numPlayers, namesToBeAdded);
				
				
				}catch(Exception e0) {
					JOptionPane.showMessageDialog(contentPane,"oh no!Usernames are already in use", "Yikes",JOptionPane.ERROR_MESSAGE);
					e0.printStackTrace();
					textField_5.setText("");
					textField_6.setText("");
					textField_3.setText("");
					textField_4.setText("");
					
					return;
					
				}
		
					
				Controller.initializeSetGameOptions();
				try {
					Controller.setNumberPlayers(numPlayers);
				} catch (InvalidInputException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					Controller.setIsUsingHarmony(setIsUsingHarmony);
				} catch (InvalidInputException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				try {
					Controller.setIsUsingMiddleKingdom(setIsUsingMiddleKingdom);
					
					AGameplay.AGameplay(); 
					
				} catch (InvalidInputException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			
				dispose();
				
			}
		});

		JLabel lblNewLabel_7_1 = new JLabel("Enter Username");
		lblNewLabel_7_1.setBounds(731, 477, 116, 20);
		lblNewLabel_7_1.setFont(new Font("Berlin Sans FB", Font.PLAIN, 17));

		tglMiddleKingdom = new JToggleButton("MIDDLE KINGDOM");
		tglMiddleKingdom.setIcon(null);
		tglMiddleKingdom.setBackground(new Color(255, 204, 51));
		tglMiddleKingdom.setFont(new Font("Berlin Sans FB", Font.PLAIN, 17));
		tglMiddleKingdom.setBounds(609, 346, 179, 41);

		tglMiddleKingdom.addItemListener(itemListenerMK);


		tglbtnHarmony = new JToggleButton("HARMONY");
		tglbtnHarmony.setIcon(null);
		tglbtnHarmony.setBackground(new Color(102, 204, 255));
		tglbtnHarmony.setFont(new Font("Berlin Sans FB", Font.PLAIN, 17));
		tglbtnHarmony.setBounds(800, 346, 167, 41);

		tglbtnHarmony.addItemListener(itemListenerH);

		backToMainMenuButton = new JButton("Back To Main Menu");
		backToMainMenuButton.setBounds(44, 798, 230, 27);
		backToMainMenuButton.setBackground(new Color(102, 255, 0));
		backToMainMenuButton.setFont(new Font("Berlin Sans FB", Font.PLAIN, 17));
		backToMainMenuButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {
							MainMenu frame = new MainMenu();
							frame.setVisible(true);
							setVisible(false); //you can't see me!
							dispose(); //Destroy the JFrame object
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
			}
		});
		contentPane.setLayout(null);
		contentPane.add(textField_5);
		contentPane.add(textField_6);
		contentPane.add(textField_3);
		contentPane.add(textField_4);
		contentPane.add(lblNewLabel_7_1);
		contentPane.add(lblNewLabel_5);
		contentPane.add(lblNewLabel_4_1);
		contentPane.add(lblNewLabel_2_1);
		contentPane.add(lblNewLabel_1_1);
		contentPane.add(lblNewLabel_3_1);
		contentPane.add(startButton);
		contentPane.add(lblGameMode_1);
		contentPane.add(tglMiddleKingdom);
		contentPane.add(tglbtnHarmony);
		contentPane.add(lblNewLabel);
		contentPane.add(comboBox);
		contentPane.add(lblGameMode);
		contentPane.add(comboBox_1);
		contentPane.add(lblNewLabel_7);
		contentPane.add(numPlayerComboBox);
		contentPane.add(backToMainMenuButton);
		
				lblNewLabel_6 = new JLabel("");
				lblNewLabel_6.setBounds(289, 41, 991, 273);
				lblNewLabel_6.setIcon(new ImageIcon(AStartMenu.class.getResource("/viewresources/WZHJ9592.PNG")));
				contentPane.add(lblNewLabel_6);
				
				JLabel lblNewLabel_1 = new JLabel("");
				lblNewLabel_1.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/CastleMenu.PNG")).getImage().getScaledInstance(350, 350, Image.SCALE_SMOOTH)));
				lblNewLabel_1.setBounds(1063, 346, 395, 423);
				contentPane.add(lblNewLabel_1);
				
				lblNewLabel_2 = new JLabel("");
				lblNewLabel_2.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/menugreencastle.PNG")).getImage().getScaledInstance(360, 360, Image.SCALE_SMOOTH)));
				lblNewLabel_2.setBounds(135, 346, 404, 413);
				contentPane.add(lblNewLabel_2);
				
				
				
				
	}

	// ItemListener is notified whenever you click on the Button 
	ItemListener itemListenerMK = new ItemListener() { 

		// itemStateChanged() method is invoked automatically 
		// whenever you click or unclick on the Button. 
		public void itemStateChanged(ItemEvent itemEvent) 
		{ 

			// event is generated in button 
			int state = itemEvent.getStateChange(); 

			// if selected print selected in console 
			if (state == ItemEvent.SELECTED) { 
				System.out.println("Middle Kingdom Selected"); 
				setIsUsingMiddleKingdom = true;
			} 
			else { 

				// else print deselected in console 
				System.out.println("Middle Kingdom Deselected"); 
				setIsUsingMiddleKingdom = false;
			} 
		} 
	}; 

	ItemListener itemListenerH = new ItemListener() { 

		// itemStateChanged() method is invoked automatically 
		// whenever you click or unclick on the Button. 
		public void itemStateChanged(ItemEvent itemEvent) 
		{ 

			// event is generated in button 
			int state = itemEvent.getStateChange(); 

			// if selected print selected in console 
			if (state == ItemEvent.SELECTED) { 
				System.out.println("Harmony Selected"); 
				setIsUsingHarmony = true;
			} 
			else { 

				// else print deselected in console 
				System.out.println("Harmony Deselected"); 
				setIsUsingHarmony = false;
			} 
		} 
	}; 
	private JButton backToMainMenuButton;
	private JLabel lblNewLabel_2;
	private JLabel takenBlue_1;
	private JLabel takenBlue_2;
	private JLabel takenBlue_3;
	private JLabel takenBlue;
	
	
}
