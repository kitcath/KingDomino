package ca.mcgill.ecse223.kingdomino.view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import ca.mcgill.ecse223.kingdomino.controller.Controller;
import ca.mcgill.ecse223.kingdomino.controller.InvalidInputException;
import ca.mcgill.ecse223.kingdomino.model.Kingdomino;

import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.DropMode;
import javax.swing.JButton;
import java.awt.SystemColor;

public class LoadFilePathWindow {

	private JFrame frame;
	private JTextField loadGameFilepathTextField;
	private JButton loadFilePathButton;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoadFilePathWindow window = new LoadFilePathWindow();
					window.getFrame().setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public LoadFilePathWindow() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		setFrame(new JFrame());
		getFrame().setBounds(100, 100, 912, 537);
		getFrame().setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel loadGameFilepathLabel = new JLabel("Insert the saved game's filepath");
		loadGameFilepathLabel.setBackground(new Color(240, 240, 240));
		loadGameFilepathLabel.setFont(new Font("MV Boli", Font.PLAIN, 33));
		loadGameFilepathLabel.setBounds(201, 165, 520, 53);
		frame.getContentPane().add(loadGameFilepathLabel);

		loadGameFilepathTextField = new JTextField();
		loadGameFilepathTextField.setText("Enter Filepath Here");
		loadGameFilepathTextField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		loadGameFilepathTextField.setBounds(123, 247, 656, 31);
		frame.getContentPane().add(loadGameFilepathTextField);
		loadGameFilepathTextField.setColumns(10);

		loadFilePathButton = new JButton("LOAD FILE");
		loadFilePathButton.setFont(new Font("Constantia", Font.PLAIN, 13));
		loadFilePathButton.setBackground(new Color(255, 204, 0));
		loadFilePathButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// clear error message
				try {
					// call the controller
					if ((loadGameFilepathTextField.getText().equalsIgnoreCase(""))){
						JOptionPane.showMessageDialog(null, "Insert a valid filepath to a saved game.");
					}
					else {
						Kingdomino kingdomino = Controller.load(loadGameFilepathTextField.getText());
						if (kingdomino == null)
							JOptionPane.showMessageDialog(null, "Insert a valid filepath to a saved game.");
					}

				} catch (InvalidInputException exception) {
					JOptionPane.showMessageDialog(null, "Insert a valid filepath to a saved game.");
				}

				// update visuals
				// refreshData();
			}
		});

		loadFilePathButton.setBounds(373, 327, 127, 53);
		frame.getContentPane().add(loadFilePathButton);

		JButton backToMainMenuButton = new JButton("Back to Main Menu");
		backToMainMenuButton.setBackground(new Color(245, 255, 250));
		backToMainMenuButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
			//	dispose();
					}
		});
		backToMainMenuButton.setBounds(31, 43, 161, 31);
		frame.getContentPane().add(backToMainMenuButton);
	}

	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
		frame.getContentPane().setFont(new Font("Tahoma", Font.PLAIN, 16));
		frame.getContentPane().setBackground(new Color(175, 238, 238));
		frame.getContentPane().setForeground(Color.ORANGE);
	}
}
