package ca.mcgill.ecse223.kingdomino.view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JToggleButton;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;
import javax.swing.UIManager;

import ca.mcgill.ecse223.kingdomino.KingdominoApplication;
import ca.mcgill.ecse223.kingdomino.controller.Controller;
import ca.mcgill.ecse223.kingdomino.controller.InvalidInputException;
import ca.mcgill.ecse223.kingdomino.model.Domino;
import ca.mcgill.ecse223.kingdomino.model.Player;
import ca.mcgill.ecse223.kingdomino.model.TerrainType;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;

public class BrowsingAllDominoesPage {

	private JFrame frame;
	private static List<Domino> allDominoes;


	/**
	 * Launch the application.
	 */
	public static void browsingAllDominoesPage() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BrowsingAllDominoesPage window = new BrowsingAllDominoesPage();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public BrowsingAllDominoesPage() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("Yu Gothic UI", Font.PLAIN, 13));
		frame.getContentPane().setForeground(Color.BLACK);
		frame.setBounds(100, 100, 1200, 756);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino1.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel_1.setBounds(12, 106, 134, 85);
		frame.getContentPane().add(lblNewLabel_1);

		JLabel lblNewLabel8 = new JLabel("New label");
		lblNewLabel8.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino8.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel8.setBounds(158, 204, 134, 85);
		frame.getContentPane().add(lblNewLabel8);

		JLabel lblNewLabel14 = new JLabel("New label");
		lblNewLabel14.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino14.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel14.setBounds(304, 204, 134, 85);
		frame.getContentPane().add(lblNewLabel14);

		JLabel lblNewLabel20 = new JLabel("New label");
		lblNewLabel20.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino20.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel20.setBounds(450, 204, 134, 85);
		frame.getContentPane().add(lblNewLabel20);

		JLabel lblNewLabel26 = new JLabel("New label");
		lblNewLabel26.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino26.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel26.setBounds(596, 204, 134, 85);
		frame.getContentPane().add(lblNewLabel26);

		JLabel lblNewLabel32 = new JLabel("New label");
		lblNewLabel32.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino32.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel32.setBounds(742, 204, 134, 85);
		frame.getContentPane().add(lblNewLabel32);

		JLabel lblNewLabel38 = new JLabel("New label");
		lblNewLabel38.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino38.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel38.setBounds(888, 204, 134, 85);
		frame.getContentPane().add(lblNewLabel38);

		JLabel lblNewLabel3 = new JLabel("New label");
		lblNewLabel3.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino3.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel3.setBounds(12, 302, 134, 85);
		frame.getContentPane().add(lblNewLabel3);

		JLabel lblNewLabel4 = new JLabel("New label");
		lblNewLabel4.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino4.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel4.setBounds(12, 400, 134, 85);
		frame.getContentPane().add(lblNewLabel4);

		JLabel lblNewLabel5 = new JLabel("New label");
		lblNewLabel5.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino5.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel5.setBounds(12, 498, 134, 85);
		frame.getContentPane().add(lblNewLabel5);

		JLabel lblNewLabel6 = new JLabel("New label");
		lblNewLabel6.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino6.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel6.setBounds(12, 596, 134, 85);
		frame.getContentPane().add(lblNewLabel6);

		JLabel lblNewLabel44 = new JLabel("New label");
		lblNewLabel44.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino44.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel44.setBounds(1034, 204, 134, 85);
		frame.getContentPane().add(lblNewLabel44);

		JLabel lblNewLabel7 = new JLabel("New label");
		lblNewLabel7.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino7.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel7.setBounds(158, 106, 134, 85);
		frame.getContentPane().add(lblNewLabel7);

		JLabel lblNewLabel13 = new JLabel("New label");
		lblNewLabel13.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino13.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel13.setBounds(304, 106, 134, 85);
		frame.getContentPane().add(lblNewLabel13);

		JLabel lblNewLabel19 = new JLabel("New label");
		lblNewLabel19.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino19.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel19.setBounds(450, 106, 134, 85);
		frame.getContentPane().add(lblNewLabel19);

		JLabel lblNewLabel25 = new JLabel("New label");
		lblNewLabel25.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino25.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel25.setBounds(596, 106, 134, 85);
		frame.getContentPane().add(lblNewLabel25);

		JLabel lblNewLabel31 = new JLabel("New label");
		lblNewLabel31.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino31.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel31.setBounds(742, 106, 134, 85);
		frame.getContentPane().add(lblNewLabel31);

		JLabel lblNewLabel37 = new JLabel("New label");
		lblNewLabel37.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino37.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel37.setBounds(888, 106, 134, 85);
		frame.getContentPane().add(lblNewLabel37);

		JLabel lblNewLabel43 = new JLabel("New label");
		lblNewLabel43.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino43.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel43.setBounds(1034, 106, 134, 85);
		frame.getContentPane().add(lblNewLabel43);

		JLabel lblNewLabel2 = new JLabel("New label");
		lblNewLabel2.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino2.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel2.setBounds(12, 204, 134, 85);
		frame.getContentPane().add(lblNewLabel2);

		JLabel lblNewLabel9 = new JLabel("New label");
		lblNewLabel9.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino9.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel9.setBounds(158, 302, 134, 85);
		frame.getContentPane().add(lblNewLabel9);

		JLabel lblNewLabel15 = new JLabel("New label");
		lblNewLabel15.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino15.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel15.setBounds(304, 302, 134, 85);
		frame.getContentPane().add(lblNewLabel15);

		JLabel lblNewLabel21 = new JLabel("New label");
		lblNewLabel21.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino21.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel21.setBounds(450, 302, 134, 85);
		frame.getContentPane().add(lblNewLabel21);

		JLabel lblNewLabel27 = new JLabel("New label");
		lblNewLabel27.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino27.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel27.setBounds(596, 302, 134, 85);
		frame.getContentPane().add(lblNewLabel27);

		JLabel lblNewLabel33 = new JLabel("New label");
		lblNewLabel33.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino33.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel33.setBounds(742, 302, 134, 85);
		frame.getContentPane().add(lblNewLabel33);

		JLabel lblNewLabel39 = new JLabel("New label");
		lblNewLabel39.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino39.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel39.setBounds(888, 302, 134, 85);
		frame.getContentPane().add(lblNewLabel39);

		JLabel lblNewLabel45 = new JLabel("New label");
		lblNewLabel45.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino45.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel45.setBounds(1034, 302, 134, 85);
		frame.getContentPane().add(lblNewLabel45);

		JLabel lblNewLabel12 = new JLabel("New label");
		lblNewLabel12.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino12.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel12.setBounds(158, 596, 134, 85);
		frame.getContentPane().add(lblNewLabel12);

		JLabel lblNewLabel10 = new JLabel("New label");
		lblNewLabel10.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino10.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel10.setBounds(158, 400, 134, 85);
		frame.getContentPane().add(lblNewLabel10);

		JLabel lblNewLabel11 = new JLabel("New label");
		lblNewLabel11.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino11.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel11.setBounds(158, 498, 134, 85);
		frame.getContentPane().add(lblNewLabel11);

		JLabel lblNewLabel16 = new JLabel("New label");
		lblNewLabel16.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino16.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel16.setBounds(304, 400, 134, 85);
		frame.getContentPane().add(lblNewLabel16);

		JLabel lblNewLabel17 = new JLabel("New label");
		lblNewLabel17.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino17.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel17.setBounds(304, 498, 134, 85);
		frame.getContentPane().add(lblNewLabel17);

		JLabel lblNewLabel18 = new JLabel("New label");
		lblNewLabel18.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino18.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel18.setBounds(304, 596, 134, 85);
		frame.getContentPane().add(lblNewLabel18);

		JLabel lblNewLabel22 = new JLabel("New label");
		lblNewLabel22.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino22.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel22.setBounds(450, 400, 134, 85);
		frame.getContentPane().add(lblNewLabel22);

		JLabel lblNewLabel23 = new JLabel("New label");
		lblNewLabel23.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino23.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel23.setBounds(450, 498, 134, 85);
		frame.getContentPane().add(lblNewLabel23);

		JLabel lblNewLabel24 = new JLabel("New label");
		lblNewLabel24.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino24.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel24.setBounds(450, 596, 134, 85);
		frame.getContentPane().add(lblNewLabel24);

		JLabel lblNewLabel28 = new JLabel("New label");
		lblNewLabel28.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino28.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel28.setBounds(596, 400, 134, 85);
		frame.getContentPane().add(lblNewLabel28);

		JLabel lblNewLabel34 = new JLabel("New label");
		lblNewLabel34.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino34.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel34.setBounds(742, 400, 134, 85);
		frame.getContentPane().add(lblNewLabel34);

		JLabel lblNewLabel40 = new JLabel("New label");
		lblNewLabel40.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino40.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel40.setBounds(888, 400, 134, 85);
		frame.getContentPane().add(lblNewLabel40);

		JLabel lblNewLabel46 = new JLabel("New label");
		lblNewLabel46.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino46.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel46.setBounds(1034, 400, 134, 85);
		frame.getContentPane().add(lblNewLabel46);

		JLabel lblNewLabel29 = new JLabel("New label");
		lblNewLabel29.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino29.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel29.setBounds(596, 498, 134, 85);
		frame.getContentPane().add(lblNewLabel29);

		JLabel lblNewLabel30 = new JLabel("New label");
		lblNewLabel30.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino30.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel30.setBounds(596, 596, 134, 85);
		frame.getContentPane().add(lblNewLabel30);

		JLabel lblNewLabel35 = new JLabel("New label");
		lblNewLabel35.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino35.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel35.setBounds(742, 498, 134, 85);
		frame.getContentPane().add(lblNewLabel35);

		JLabel lblNewLabel36 = new JLabel("New label");
		lblNewLabel36.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino36.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel36.setBounds(742, 596, 134, 85);
		frame.getContentPane().add(lblNewLabel36);

		JLabel lblNewLabel41 = new JLabel("New label");
		lblNewLabel41.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino41.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel41.setBounds(888, 498, 134, 85);
		frame.getContentPane().add(lblNewLabel41);

		JLabel lblNewLabel47 = new JLabel("New label");
		lblNewLabel47.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino47.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel47.setBounds(1034, 498, 134, 85);
		frame.getContentPane().add(lblNewLabel47);

		JLabel lblNewLabel42 = new JLabel("New label");
		lblNewLabel42.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino42.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel42.setBounds(888, 596, 134, 85);
		frame.getContentPane().add(lblNewLabel42);

		JLabel lblNewLabel48 = new JLabel("New label");
		lblNewLabel48.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino48.png")).getImage().getScaledInstance(135, 85, Image.SCALE_SMOOTH)));
		lblNewLabel48.setBounds(1034, 596, 134, 85);
		frame.getContentPane().add(lblNewLabel48);

		JButton btnNewButton = new JButton("Back to Game");
		btnNewButton.setBackground(Color.ORANGE);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				EventQueue.invokeLater(new Runnable() 
				{
					public void run() 
					{
						try 
						{
							frame.setVisible(false);
						} catch (Exception e) 
						{
							e.printStackTrace();
						}
					}
				});
			}
		});
		
		
		btnNewButton.setBounds(12, 13, 145, 33);
		frame.getContentPane().add(btnNewButton);

		JLabel Title = new JLabel("Browsing All Dominoes");
		Title.setHorizontalAlignment(SwingConstants.CENTER);
		Title.setBackground(new Color(253, 245, 230));
		Title.setForeground(Color.ORANGE);
		Title.setFont(new Font("Gabriola", Font.BOLD, 55));
		Title.setBounds(12, 13, 1156, 80);
		frame.getContentPane().add(Title);


		//				JButton backToGameButton = new JButton("Back To Game");
		//				backToGameButton.setForeground(Color.DARK_GRAY);
		//				backToGameButton.setBackground(Color.PINK);
		//				backToGameButton.addActionListener(new ActionListener() {
		//					public void actionPerformed(ActionEvent e) {
		//						EventQueue.invokeLater(new Runnable() 
		//						{
		//							public void run() 
		//							{
		//								try 
		//								{
		//									frame.setVisible(false);
		//
		//								} catch (Exception e) 
		//								{
		//									e.printStackTrace();
		//								}
		//							}
		//						});
		//					}
		//				});
		//				backToGameButton.setBounds(12, 13, 129, 39);
		//				frame.getContentPane().add(backToGameButton);

		JLabel browseAllDominoesLabel = new JLabel("");
		browseAllDominoesLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/8-Smooth-Concrete-Background-Texture.png")).getImage().getScaledInstance(1203, 746, Image.SCALE_SMOOTH)));
		browseAllDominoesLabel.setBackground(new Color(255, 200, 0));
		browseAllDominoesLabel.setFont(new Font("Mongolian Baiti", Font.PLAIN, 25));
		browseAllDominoesLabel.setForeground(Color.BLUE);
		browseAllDominoesLabel.setBounds(0, -11, 1185, 721);
		frame.getContentPane().add(browseAllDominoesLabel);

	}
}
