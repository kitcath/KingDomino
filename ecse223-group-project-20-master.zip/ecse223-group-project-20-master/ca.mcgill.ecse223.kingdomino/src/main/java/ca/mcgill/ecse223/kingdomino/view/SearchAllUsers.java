package ca.mcgill.ecse223.kingdomino.view;

import java.awt.Color;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.Collections;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import ca.mcgill.ecse223.kingdomino.model.Kingdomino;
import ca.mcgill.ecse223.kingdomino.model.User;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

/**
 * this class displays a JTable with all the existing users in the Kingdmoino Application
 * @author cath
 *
 */

public class SearchAllUsers extends JFrame{
	
	
	public SearchAllUsers() {
		setTitle("Kingdomino");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setBackground(new Color(204, 255, 255));
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\r\n");
		lblNewLabel.setIcon(new ImageIcon(SearchAllUsers.class.getResource("/viewresources/CastleMenu.PNG")));
		lblNewLabel.setBounds(357, -99, 933, 855);
		getContentPane().add(lblNewLabel);
	}
	
	
   public static void searching(Kingdomino kingdomino) {
	   EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					createPanel(kingdomino);
					  
					   }
				catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
   }
   
   /**
    * creation of the JTable
    * @author Catherine Van Gheluwe
    * @param kingdomino
    */
   private static void createPanel(Kingdomino kingdomino) {
	   
	   JButton close = new JButton("Close");
	   
	   DefaultTableModel tableModel = new DefaultTableModel();
	      JTable table = new JTable(tableModel);
	      table.setBackground(new Color(204, 255, 255));
	      tableModel.addColumn("Names");
	      tableModel.addColumn("Games Played");
	      tableModel.addColumn("Games Won");
	      
	      int sizeOfUsers = kingdomino.getUsers().size();
	      String[] name = new String[sizeOfUsers];
	      Object[][] users = new Object[sizeOfUsers][3];
	      
	      //sort all users in alphabetical order
	      for(int i = 0; i < sizeOfUsers; i++) {
				User aUser = kingdomino.getUser(i);
				String names = aUser.getName();
				
				name[i] = names;
	      }
	      
	      Arrays.sort(name,Collections.reverseOrder());
	      
		for(int i = 0; i < name.length; i++) {
			User aUser =User.getWithName(name[i]);
			Integer played =(aUser.getPlayedGames());
			Integer wins = (aUser.getWonGames());
	    
				users[i][0] = name[i];
				users[i][1] = played;
				users[i][2] = wins;
			}
			
		   
	      for(int i = 0; i < name.length; i ++) {
	    	//  for (int j = 0; j <names.length)
	    	  tableModel.insertRow(0,users[i]);
	      }
	 
	      JFrame f = new JFrame();
	      f.setBackground(new Color(204, 255, 255));
	      f.getContentPane().setBackground(new Color(204, 255, 255));
	      f.setSize(500, 500);
	      JScrollPane scrollPane = new JScrollPane(table);
	      f.getContentPane().add(scrollPane);
	      //f.add(close);
	      f.setVisible(true);
	      
	      
	      close.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					f.dispose();
				}
	      });
   }
}