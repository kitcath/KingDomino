package ca.mcgill.ecse223.kingdomino.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;


/**
 * 
 * @author catherine van gheluwe
 *this class displays the statistics of one user
 */
public class viewUsers extends JFrame {

	private JPanel contentPane;

	private DefaultTableModel userModel;
	private String userModelColumnNames[]={"NAME", "Games Played", " Games Won"};
	private static final int HEIGHT_USERMODEL_TABLE = 200;
	private JScrollPane userScrollPane;
	private JLabel lblName;
	private JLabel lblNewLabel_1;
	private JLabel lblGamesPlayed;
	private JLabel lblGamesPlayed_1;
	private JLabel lblNewLabel_3;
	private JLabel lblNewLabel_2;
	
	/**
	 * Launch the application.
	 */
	public static void viewing(String name, String played, String won) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					viewUsers frame = new viewUsers(name, played, won);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
	
	/**
	 * Create the frame.
	 */
	public viewUsers(String name, String played, String won) {
		
	

		setBackground(new Color(204, 255, 255));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 905, 673);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(204, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setBounds(100, 100, 1599, 918);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon(viewUsers.class.getResource("/viewresources/CastleMenu.PNG")));
		lblNewLabel.setBounds(597, 0, 972, 871);
		contentPane.add(lblNewLabel);
		

		
		JButton btnMainMenu = new JButton("Back\r\n");
		btnMainMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				
			}
		});
		btnMainMenu.setBackground(new Color(204, 153, 255));
		btnMainMenu.setBounds(12, 13, 97, 25);
		contentPane.add(btnMainMenu);
		
		lblName = new JLabel("Name");
		lblName.setForeground(new Color(0, 0, 0));
		lblName.setFont(new Font("Berlin Sans FB", Font.PLAIN, 17));
		lblName.setOpaque(true);
		lblName.setBackground(new Color(153, 255, 51));
		lblName.setBounds(12, 180, 241, 31);
		contentPane.add(lblName);
		
		lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setText(won);
		lblNewLabel_1.setOpaque(true);
		lblNewLabel_1.setBackground(new Color(255, 255, 255));
		lblNewLabel_1.setBounds(253, 242, 369, 31);
		contentPane.add(lblNewLabel_1);
		
		lblGamesPlayed = new JLabel("Games Played");
		lblGamesPlayed.setOpaque(true);
		lblGamesPlayed.setFont(new Font("Berlin Sans FB", Font.PLAIN, 17));
		lblGamesPlayed.setBackground(new Color(204, 255, 102));
		lblGamesPlayed.setBounds(12, 211, 241, 31);
		contentPane.add(lblGamesPlayed);
		
		lblGamesPlayed_1 = new JLabel("Games Won");
		lblGamesPlayed_1.setOpaque(true);
		lblGamesPlayed_1.setFont(new Font("Berlin Sans FB", Font.PLAIN, 17));
		lblGamesPlayed_1.setBackground(new Color(204, 255, 102));
		lblGamesPlayed_1.setBounds(12, 241, 241, 31);
		contentPane.add(lblGamesPlayed_1);
		
		lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setText(won);
		lblNewLabel_3.setOpaque(true);
		lblNewLabel_3.setBackground(Color.WHITE);
		lblNewLabel_3.setBounds(253, 212, 369, 31);
		contentPane.add(lblNewLabel_3);
		
		lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setText(name);
		lblNewLabel_2.setOpaque(true);
		lblNewLabel_2.setBackground(Color.WHITE);
		lblNewLabel_2.setBounds(253, 181, 369, 31);
		contentPane.add(lblNewLabel_2);
	}
}
