package ca.mcgill.ecse223.kingdomino.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.Component;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JSeparator;
import javax.swing.table.DefaultTableModel;

import ca.mcgill.ecse223.kingdomino.controller.InvalidInputException;
import ca.mcgill.ecse223.kingdomino.model.Kingdomino;
import ca.mcgill.ecse223.kingdomino.model.User;
import ca.mcgill.ecse223.kingdomino.KingdominoApplication;
import ca.mcgill.ecse223.kingdomino.controller.Controller;

import javax.swing.JScrollBar;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;

/**
 * 
 * @author catherine van gheluwe
 * This class displays a search bar for the user to find itself in the application
 *the user can also create a new profile here
 *
 */

public class SearchAUser extends JFrame {
	private JPanel contentPane;
	private JTextField textField;
	private JTable table;
	private JPanel newPannel;
	
	//private String error = null;
	private JButton btnNewButton;
	private JLabel lblEnterYourName;
	private JLabel lblNewLabel;
	private JButton btnSearchAll;
	private JLabel label;
	private JLabel error;
	
	String playedGames,wonGames;
	private JLabel lblNewLabel_1;
	private JButton btnCreateAProfile;
	

	/**
	 * Launch the application.
	 */
	public static void viewStatistics() {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SearchAUser frame = new SearchAUser();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	

	/**
	 * Create the frame.
	 */
	public SearchAUser() {
		initialize();
	}
	private void initialize() {
		String empty = " Name cannot be empty";
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1309, 886);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(224, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setBounds(100, 100, 1599, 918);
		setContentPane(contentPane);
		
		textField = new JTextField();
		textField.setBounds(50, 506, 448, 22);
		textField.setColumns(10);
		

		lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setFont(new Font("Bernard MT Condensed", Font.PLAIN, 18));
		lblNewLabel_1.setForeground(new Color(255, 0, 0));
		lblNewLabel_1.setBounds(169, 481, 244, 25);
		contentPane.add(lblNewLabel_1);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.setBackground(new Color(255, 204, 51));
		btnSearch.setFont(new Font("Berlin Sans FB", Font.PLAIN, 17));
		btnSearch.setBounds(188, 541, 137, 25);
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String searchedName = textField.getText();
				if(searchedName == "") {
					lblNewLabel_1 .setText(empty);
	
				}else {
					try {
						User aUser = Controller.provideUserProfile(textField.getText(),false);
						
						if(aUser == null) {
							lblNewLabel_1 .setText("Name cannot be found");
							contentPane.add(lblNewLabel_1);
							
							
							Object[] options = {"Yes,please","No thanks"};
							int n = JOptionPane.showOptionDialog(contentPane, "Would you like to create a profile?", "User Creation", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
							if(n == 0) {
								//boolean creation = Controller.createUser(textField.getText());
								 User aUser1 = Controller.provideUserProfile(textField.getText(),true);
								if(KingdominoApplication.getKingdomino().getUsers().contains(aUser1)) {
									JOptionPane.showMessageDialog(contentPane,"success! You now have a user profile"," confirmation",JOptionPane.INFORMATION_MESSAGE,null);
								}
							}
							textField.setText("");
							return; 
							
							}else {
							 playedGames = Integer.toString(aUser.getPlayedGames());
							 wonGames = Integer.toString(aUser.getWonGames());
							 
							viewUsers findUser = new viewUsers (textField.getText(),playedGames,wonGames);
							findUser.viewing(textField.getText(),playedGames,wonGames);
							
							textField.setText("");
						}
					}catch (Exception e1) {
						lblNewLabel_1 .setText("Name cannot be found");
						return;
					}
				}
					
				
			}
			
		});
		
		JSeparator separator = new JSeparator();
		separator.setBounds(27, 88, 1, 2);
		separator.setBackground(new Color(0, 0, 0));
		separator.setForeground(new Color(0, 0, 0));
		
		
		table = new JTable();
		table.setBounds(267, 295, 1, 1);
		
		btnNewButton = new JButton(" Back to Main Menu");
		btnNewButton.setBounds(12, 13, 155, 42);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {
							setVisible(false); //you can't see me!
							dispose(); //Destroy the JFrame object
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
				}
		});
		btnNewButton.setBackground(Color.PINK);
		contentPane.setLayout(null);
		contentPane.add(textField);
		contentPane.add(btnSearch);
		contentPane.add(table);
		contentPane.add(btnNewButton);
		contentPane.add(separator);
		
		lblEnterYourName = new JLabel("Enter Your Name");
		lblEnterYourName.setFont(new Font("Berlin Sans FB", Font.PLAIN, 17));
		lblEnterYourName.setBounds(197, 453, 128, 40);
		contentPane.add(lblEnterYourName);
		
		lblNewLabel = new JLabel("\r\n\r\n");
		lblNewLabel.setIcon(new ImageIcon(SearchAUser.class.getResource("/viewresources/CastleMenu.PNG")));
		lblNewLabel.setBounds(562, 13, 1211, 871);
		contentPane.add(lblNewLabel);
		
		btnSearchAll = new JButton("Search All");
		btnSearchAll.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				SearchAllUsers table = new SearchAllUsers();
				table.searching(KingdominoApplication.getKingdomino());
				contentPane.setVisible(true); // remove
			}
		});
		btnSearchAll.setBackground(new Color(255, 153, 51));
		btnSearchAll.setFont(new Font("Berlin Sans FB", Font.PLAIN, 17));
		btnSearchAll.setBounds(188, 579, 137, 25);
		contentPane.add(btnSearchAll);
		
		btnCreateAProfile = new JButton("Create A Profile");
		btnCreateAProfile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				boolean valid;
				Kingdomino kingdomino = KingdominoApplication.getKingdomino();
				String desiredName = JOptionPane.showInputDialog("Please entered desired name: ");
				
				try {
						valid = Controller.specialCharacters(desiredName);
						
						if(valid) {
							JOptionPane.showMessageDialog(contentPane, "Special Characters are not allowed in names. Use letters or numbers", "error",JOptionPane.ERROR_MESSAGE);
							
							return;
						}
					
					
					User aUser = Controller.provideUserProfile(desiredName,false);
					if(aUser == null) {
						aUser = Controller.provideUserProfile(desiredName,true);
						
						int size = kingdomino.getUsers().size();
						String actual = kingdomino.getUser(kingdomino.getUsers().size()-1).getName();
						if(actual.contentEquals(desiredName)){
							JOptionPane.showMessageDialog(contentPane,"Success! You now have a profile", "Success",JOptionPane.INFORMATION_MESSAGE,null);
						}else {
							JOptionPane.showMessageDialog(contentPane,"oh no!Something went wrong. Maybe because Im a shit programmer", "Yikes",JOptionPane.ERROR_MESSAGE);
							return;
						}
					}else {
						JOptionPane.showMessageDialog(contentPane, "name already taken", "error",JOptionPane.ERROR_MESSAGE);	
						return;
					}
					}catch(InvalidInputException e1) {
					JOptionPane.showMessageDialog(contentPane, "name already taken", "error",JOptionPane.ERROR_MESSAGE);	
					return;
				}catch(Exception e2) {
					
				}
			}
		});
		btnCreateAProfile.setFont(new Font("Berlin Sans FB", Font.PLAIN, 15));
		btnCreateAProfile.setBackground(new Color(153, 255, 0));
		btnCreateAProfile.setBounds(189, 617, 136, 25);
		contentPane.add(btnCreateAProfile);
		
		
		
		
		
	}
}
