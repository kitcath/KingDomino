package ca.mcgill.ecse223.kingdomino.controller;

import java.io.File;
import java.util.List;

import ca.mcgill.ecse223.kingdomino.model.Domino;
import ca.mcgill.ecse223.kingdomino.model.DominoInKingdom;
import ca.mcgill.ecse223.kingdomino.model.Draft;
import ca.mcgill.ecse223.kingdomino.model.Game;
import ca.mcgill.ecse223.kingdomino.model.Kingdomino;
import ca.mcgill.ecse223.kingdomino.model.Player;
import ca.mcgill.ecse223.kingdomino.model.Property;
import ca.mcgill.ecse223.kingdomino.model.TerrainType;
import ca.mcgill.ecse223.kingdomino.model.User;
import ca.mcgill.ecse223.kingdomino.model.DominoInKingdom.DirectionKind;

public interface ControllerInterface {

	public static void initializeSetGameOptions() throws InvalidInputException  {
	}

	public static void setNumberPlayers(Integer int1)throws InvalidInputException {

	}

	public static Integer setIsUsingHarmony(Boolean b) throws InvalidInputException {
		return null;

	}

	public static int setIsUsingMiddleKingdom(Boolean b) throws InvalidInputException {
		return 0;

	}

	public static void createNextDraft() throws Exception {

	}

	public static void discardDomino(DominoInKingdom domino) {

	}

	public static void calculatePropertyAttribute(Player player) throws InvalidInputException {

	}

	/* HELPER METHODS */
	static boolean getDominoCondition(DominoInKingdom domino, Player player) {
		return false;
		
	}
	
	/////////////////////////////////////////////////////////////////////////////////////////////

	public static List<Domino> shuffleDominoPile() {
		return null;
		
	}

	public static void chooseNextDomino(Draft nextDraft, Player player, Domino selectedDomino) throws Exception {
		
	}

	public static List<Property> identifyKingdomProperties(Player player) {
		return null;
		
	}

	public static List<Player> calculateRanking() throws InvalidInputException {
		return null;
		
	}

	public static boolean verifyNeighborAdjacency(DominoInKingdom domino) {
		return false;
		
	}

	public static void moveCurrentDomino(DominoInKingdom domino, DirectionKind movement) {

	}

	public static int calculatePlayerScore(Player player) throws InvalidInputException {
		return 0;

	}

	/////////////////////////////////////////////////////////////////////////////////////////////

	static void placeCurrentDomino(Player player, Domino domino, int x, int y, DirectionKind direction) {
		
	}

	static void orderNextDraft(Game game) {
		
	}

	static boolean verifyGridSize(Player player) {
		return false;
		
	}

	static boolean verifyCastleAdjacency(DominoInKingdom domino) {
		return false;
		
	}

	/////////////////////////////////////////////////////////////////////////////////////////////

	public static int calculateBonusScore(Player player) throws InvalidInputException {
		return 0;

	}

	public static Player resolveTieBreak() throws InvalidInputException {
		return null;
	
	}

	public static List<Domino> browseDominoPile() throws InvalidInputException {
		return null;

	}
	
	public static Domino browseDominoPile(int id) throws InvalidInputException {
		return null;

	}
	
	public static List<Domino> browseDominoPile(TerrainType terrainType) throws InvalidInputException {
		return null;

	}

	public static Kingdomino load (String filePath) throws InvalidInputException {
		return null;
	}
	
	public static void printDominoesInPile (List<Domino> dominoPile) throws InvalidInputException {
		
	}
	/////////////////////////////////////////////////////////////////////////////////////////////

	public static Game startANewGame(int numberOfPlayers) throws InvalidInputException {
		return null;
	}

	public static boolean VerifyNoOverlapping(DominoInKingdom dominoPreplaced) throws InvalidInputException  {
		return false;

	} 

	public static User provideUserProfile(String userName) throws InvalidInputException {
		return null;

	}

	public static void save(Kingdomino kingDomino) throws InvalidInputException {

	}
	
}
