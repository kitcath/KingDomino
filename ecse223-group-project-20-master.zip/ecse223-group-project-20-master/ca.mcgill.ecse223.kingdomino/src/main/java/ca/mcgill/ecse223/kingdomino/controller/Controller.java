package ca.mcgill.ecse223.kingdomino.controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import javax.swing.JOptionPane;

import java.util.Random;
import java.util.*;

import ca.mcgill.ecse223.kingdomino.KingdominoApplication;
import ca.mcgill.ecse223.kingdomino.model.BonusOption;
import ca.mcgill.ecse223.kingdomino.model.Castle;
import ca.mcgill.ecse223.kingdomino.model.Domino;
import ca.mcgill.ecse223.kingdomino.model.Domino.DominoStatus;
import ca.mcgill.ecse223.kingdomino.model.DominoInKingdom;
import ca.mcgill.ecse223.kingdomino.model.DominoInKingdom.DirectionKind;
import ca.mcgill.ecse223.kingdomino.model.DominoSelection;
import ca.mcgill.ecse223.kingdomino.model.Draft;
import ca.mcgill.ecse223.kingdomino.model.Draft.DraftStatus;
import ca.mcgill.ecse223.kingdomino.model.Player.PlayerColor;
import ca.mcgill.ecse223.kingdomino.persistence.KingDominoPersistence;
import ca.mcgill.ecse223.kingdomino.view.AGameplay;
import ca.mcgill.ecse223.kingdomino.model.Game;
import ca.mcgill.ecse223.kingdomino.model.Gameplay;
import ca.mcgill.ecse223.kingdomino.model.Kingdom;
import ca.mcgill.ecse223.kingdomino.model.KingdomTerritory;
import ca.mcgill.ecse223.kingdomino.model.Kingdomino;
import ca.mcgill.ecse223.kingdomino.model.Player;
import ca.mcgill.ecse223.kingdomino.model.Property;
import ca.mcgill.ecse223.kingdomino.model.TerrainType;
import ca.mcgill.ecse223.kingdomino.model.User;

public class Controller implements ControllerInterface {

	/////////////////////////////////////////////////////////////////////////////////////////////

	static int turnCounter =0;
	
	public static void initializeSetGameOptions() {

		/*
		 * F#1: Set game options: As a player, I want to configure the designated
		 * options of the Kingdomino game including the number of players (2, 3 or 4)
		 * and thevalid bonus scoring options.
		 * 
		 * @author Ryad Ammar
		 */

		/*
		 * This method initializes the setGameOption feature by storing four different
		 * BonusOption instance in a list (Kingdomino.bonusOptions) for them to be
		 * easily retrieved later on.
		 */

		Kingdomino kingdomino = KingdominoApplication.getKingdomino();
		BonusOption harmony = new BonusOption("Harmony", kingdomino);
		BonusOption middleKingdom = new BonusOption("MiddleKingdom", kingdomino);
		kingdomino.addBonusOption(harmony);
		kingdomino.addBonusOption(middleKingdom);
		
	

	}

	public static void setNumberPlayers(Integer int1) throws InvalidInputException {

		/*
		 * @author Ryad Ammar
		 */

		/*
		 * This method takes an Integer as input. The input is stored in the current
		 * game number of player (Game.numberOfPlayers).
		 */

		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		if (game == null) {
			throw new InvalidInputException("A game must exist to define game settings.");
		}

		if (int1 < 2 || int1 > 4) {
			throw new InvalidInputException("The number of players must be between 2 and 4.");
		}
		game.setNumberOfPlayers(int1);
	}

	public static void setIsUsingHarmony(Boolean b) throws InvalidInputException {

		/*
		 * @author Ryad Ammar
		 */

		/*
		 * This method takes a boolean value as input. If the input is true, then
		 * isUsingHarmony is added to the current game selected bonus list
		 * (Game.selectedBonusOptions). Otherwise isNotUsingHarmony is added instead.
		 */

		Kingdomino kingdomino = KingdominoApplication.getKingdomino();
		Game game = kingdomino.getCurrentGame();

		if (game == null) {
			throw new InvalidInputException("A game must exist to define game settings.");
		}
		if (b) {
			game.addSelectedBonusOption(kingdomino.getBonusOption(0));
		} else {
			game.removeSelectedBonusOption(kingdomino.getBonusOption(0));
		}
	}

	public static void setIsUsingMiddleKingdom(Boolean b) throws InvalidInputException {

		/*
		 * @author Ryad Ammar
		 */

		/*
		 * This method takes a boolean value as input. If the input is true, then
		 * isUsingMiddleKingdom is added to the current game selected bonus list
		 * (Game.selectedBonusOptions). Otherwise isNotUsingMiddleKingdom is added
		 * instead.
		 */

		Kingdomino kingdomino = KingdominoApplication.getKingdomino();
		Game game = kingdomino.getCurrentGame();

		if (game == null) {
			throw new InvalidInputException("A game must exist to define game settings.");
		}
		if (b) {
			game.addSelectedBonusOption(kingdomino.getBonusOption(1));
		} else {
			game.removeSelectedBonusOption(kingdomino.getBonusOption(1));
		}
	}

	public static void createNextDraft() throws Exception {

		/*
		 * F#8: Reveal next draft of dominos: As a player, I want the Kingdomino app to
		 * automatically reveal the next four dominos once the previous round is
		 * finished.
		 * 
		 * @author Ryad Ammar
		 */

		/*
		 * THIS FEATURE REQUIRES THAT: - the dominos are linked together with
		 * Domino.setNextDomino() after being shuffled (F5) - orderNextDraft() (F9)
		 * sorts the List<Domino> idUnsortedDominos in Draft
		 */

		/*
		 * This method reads the top 5 dominoes in the current game's pile. It adds the
		 * first 4 dominos to an unsorted list of dominos (Draft.idUnsortedDominos)
		 * which will have to be sorted later on (F9). It stores the fifth top domino in
		 * the current game's top domino attribute (Game.topDomino). It reads the number
		 * of player and checks whether the pile is empty. If it is, Game.pileIsEmpty is
		 * set to true, the next draft is null, the top domino is null and an exception
		 * is thrown.
		 */

		Kingdomino kingdomino = KingdominoApplication.getKingdomino();
		Game game = kingdomino.getCurrentGame();

		if (game == null) {
			throw new InvalidInputException("A game must exist to define game settings.");
		}

		Draft nextDraft = game.getNextDraft();

		if ((game.getNumberOfPlayers() == 3 | game.getNumberOfPlayers() == 4) && (game.numberOfAllDrafts() == 12)) {
			game.setTopDominoInPile(null);
			game.setNextDraft(null);
			game.setPileIsEmpty(true);
			throw new Exception("The pile is empty & there is no next draft.");
		} else {
			if ((game.getNumberOfPlayers() == 2) && (game.numberOfAllDrafts() == 6)) {
				game.setTopDominoInPile(null);
				game.setNextDraft(null);
				game.setPileIsEmpty(true);
				throw new Exception("The pile is empty & there is no next draft.");
			} else {

				if (game.getTopDominoInPile() == null)
					throw new Exception("The pile is empty when it should not.");
				
				Domino d1 = game.getTopDominoInPile();
				Domino d2 = d1.getNextDomino();
				Domino d3 = d2.getNextDomino();
				Domino d4 = d3.getNextDomino();
				Domino d5 = d4.getNextDomino();
				
				nextDraft.addIdUnsortedDomino(d1);
				nextDraft.addIdUnsortedDomino(d2);
				nextDraft.addIdUnsortedDomino(d3);
				nextDraft.addIdUnsortedDomino(d4);

				d1.setStatus(DominoStatus.InNextDraft);
				d2.setStatus(DominoStatus.InNextDraft);
				d3.setStatus(DominoStatus.InNextDraft);
				d4.setStatus(DominoStatus.InNextDraft);

				nextDraft.setDraftStatus(DraftStatus.FaceDown);

				game.setTopDominoInPile(d5);
				d5.setStatus(DominoStatus.InPile);
			}
		}

		KingdominoApplication.getStateMachine().draftReady();
		game.setCurrentDraft(nextDraft);
	}

	public static void discardDomino(DominoInKingdom domino) {

		/*
		 * F#18: Discard domino: As a player, I wish to discard a domino if it cannot be
		 * placed to my kingdom in a valid way
		 * 
		 * @author Ryad Ammar
		 */

		/*
		 * THIS FEATURE REQUIRES: - the feature(s) F14, F15, F16, F17
		 */

		/*
		 * This method scans the 10 cells surrounding the castle of the kingdom and
		 * tries to place the domino on each cell. If there is an available cell for the
		 * domino, the domino is "ErroneouslyPreplaced". Otherwise, the domino is
		 * "Discarded".
		 */

		Kingdomino kingdomino = KingdominoApplication.getKingdomino();
		Game game = kingdomino.getCurrentGame();
		
		Player player = domino.getKingdom().getPlayer();

		HashMap<Integer, DirectionKind> direction = new HashMap<Integer, DirectionKind>();
		direction.put(0, DirectionKind.Up);
		direction.put(1, DirectionKind.Down);
		direction.put(2, DirectionKind.Left);
		direction.put(3, DirectionKind.Right);

		for (Integer i = -4; i <= 4; i++) {
			domino.setX(i);

			for (Integer j = -4; j <= 4; j++) {
				domino.setY(j);

				for (Integer k = 0; k <= 1; k++) {
					domino.setDirection(direction.get(k));

					if (getDominoCondition(domino, player)) {
						domino.getDomino().setStatus(DominoStatus.ErroneouslyPreplaced);
						domino.setDirection(direction.get(0));
						domino.setX(0);
						domino.setY(0);
						System.out.println("Nothing to discard");
						return;
					}

				}
			}
		}

		
		
		System.out.println("Discarding "+domino.getKingdom().getPlayer().getColor()+"'s domino");
		AGameplay.discard(player.getColor().toString());
		player.removeSelection();
		game.setNextPlayer(player.getNext());
		turnCounter++;
		if(turnCounter==game.getNumberOfPlayers()) {
			KingdominoApplication.getStateMachine().dominoPlaced(); //call state change
			System.out.println(KingdominoApplication.getStateMachine().getGamestatusFullName());
			turnCounter = 0; //reset counter
			try {
				AGameplay.addDraftToView();
			} catch (InvalidInputException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		domino.setX(0);
		domino.setY(0);
		domino.getDomino().setStatus(DominoStatus.Discarded);
		return;
	}

	public static void calculatePropertyAttribute(Player player) throws InvalidInputException {

		/*
		 * F#20: Calculate property attributes: I want the Kingdomino app to
		 * automatically calculate the size of a property and the total number of crowns
		 * in that property.
		 * 
		 * @author Ryad Ammar
		 */

		/*
		 * THIS FEATURE REQUIRES: - the feature(s) F19
		 */

		/*
		 * This method iterates through the list of properties (identified by F19)
		 * contained in the players kingdom. For each property, it stores the number of
		 * dominos it includes in property.size. Also, it iterates though the list of
		 * included dominos of each property and stores the number of crowns contained
		 * in each of its dominos in property.crowns.
		 */

		Kingdomino kingdomino = KingdominoApplication.getKingdomino();
		Game game = kingdomino.getCurrentGame();
		if (game == null) {
			throw new InvalidInputException("A game must exist to define game settings.");
		}

		identifyKingdomProperties(player);

		List<Property> playerProperties = player.getKingdom().getProperties();

		for (int i = 0; i < playerProperties.size(); i++) {

			int sizeOfProperty = 0;
			int numberOfCrowns = 0;

			Property property = playerProperties.get(i);
			List<Domino> includedDominos = property.getIncludedDominos();
			TerrainType terrainType = property.getPropertyType();

			for (int j = 0; j < includedDominos.size(); j++) {
				Domino domino = includedDominos.get(j);
				if(domino.getStatus()!=Domino.DominoStatus.Discarded) {
				if (domino.getLeftTile() == terrainType) {
					sizeOfProperty += 1;
					numberOfCrowns += domino.getLeftCrown();
				}
				if (domino.getRightTile() == terrainType) {
					sizeOfProperty += 1;
					numberOfCrowns += domino.getRightCrown();
				}
			}
			}

			property.setCrowns(numberOfCrowns);
			property.setSize(sizeOfProperty);

		}

	}

	/* HELPER METHODS */
	public static boolean getDominoCondition(DominoInKingdom domino, Player player) {
		// Returns true if the domino is correctly placed
		if(domino.getDomino().getStatus()==Domino.DominoStatus.Discarded)
		return true;
		else
		return ((verifyCastleAdjacency(domino) || verifyNeighborAdjacency(domino)) && verifyGridSize(player)
				&& !VerifyNoOverlapping(domino));
	}

	/////////////////////////////////////////////////////////////////////////////////////////////

	/**
	 * F#5: Shuffle domino pile: As a player, I want to play have a randomly
	 * shuffled pile of dominos so that every game becomes unique
	 * 
	 * @author Michael Buchar
	 * @param no parameters
	 *
	 */

	public static void shuffleDominoPile() {
		List<Domino> dominoList = new ArrayList<>();
		List<Domino> dominoInPileList = new ArrayList<>();

		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		dominoList = game.getAllDominos();

		for (int i = 0; i < dominoList.size(); i++) {
			Domino curDomino = dominoList.get(i);
			dominoInPileList.add(curDomino);

		}
		// Shuffling the pile a random number of times
		Random r1 = new Random();
		int numOfTimes = r1.nextInt(10); // upper limit bound 10
		for (int i = 0; i < numOfTimes; i++) {
			Collections.shuffle(dominoInPileList);
			Random r2 = new Random();
			Collections.shuffle(dominoInPileList, r2);
		}

		for (int i = 0; i < dominoInPileList.size(); i++) {
			game.addOrMoveAllDominoAt(dominoInPileList.get(i), i);
		}

		for (int i = 0; i < dominoInPileList.size() - 1; i++) { // the last domino will have a nextDomino == null
			Domino domino = dominoInPileList.get(i);
			domino.setNextDomino(dominoInPileList.get(i + 1));
		}

		// Getting the number of dominos on table based on number of players
		int dominosOnTable = 0;
		int numPlayers = game.getNumberOfPlayers();

		switch (numPlayers) { // setting domino counts for different # of players
		case 2:
			dominosOnTable = 4;
			break;
		case 3:
			dominosOnTable = 3;
			break;
		case 4:
			dominosOnTable = 4;
			break;
		default:
			break;
		}

		Draft draft = new Draft(DraftStatus.FaceDown, game);

		// Looping through dominos and setting corresponding status, first 4 dominos go
		// in the draft, rest go in pile
		Domino curDomino;
		for (int i = 0; i < game.getMaxPileSize(); i++) {
			curDomino = dominoInPileList.get(i); // probably i but might be i+1
			if (i < dominosOnTable) {
				curDomino.setStatus(DominoStatus.InCurrentDraft);
				draft.addIdUnsortedDomino(curDomino);
			} else {
				curDomino.setStatus(DominoStatus.InPile);
			}
		}
		game.setCurrentDraft(draft);
		game.setTopDominoInPile(dominoList.get(dominosOnTable)); // set top domino to first domino after draft

	}

	/**
	 * F#10: Choose next domino: As a player, I wish to be able to choose a
	 * designated domino from the next draft assuming that this domino has not yet
	 * been chosen by any other players.
	 * 
	 * @author Michael Buchar
	 * @param Draft nextDraft - the next draft (the draft we are choosing from),
	 *              Player player - the player choosing the next domino, Domino
	 *              selectedDomino - the domino the player wants to select
	 * @throws Exception
	 * 
	 */
	public static void chooseNextDomino(Draft nextDraft, Player player, Domino selectedDomino)
			throws InvalidInputException {
		
		Kingdomino kingdomino = KingdominoApplication.getKingdomino();
		Game game = kingdomino.getCurrentGame();

		List<Domino> draftDominoes = new ArrayList<>();

		draftDominoes = nextDraft.getIdSortedDominos();

		boolean dominoInDraft = false;

		for (int i = 0; i < draftDominoes.size(); i++) {
			if (draftDominoes.get(i).getId() == selectedDomino.getId()) {
				dominoInDraft = true;
			}
		}

		if (!dominoInDraft) {
			throw new InvalidInputException("Domino not present in Draft");
		}
		
		for (DominoSelection existingSelection : nextDraft.getSelections()) {
			if (existingSelection.getDomino().getId() == selectedDomino.getId()) {
				return; // do not add a selection and exit the function
			}
		}

		// add the domino to the players grid or game
		player.removeSelection();
		nextDraft.clearSlection();
		DominoSelection dominoSelection = new DominoSelection(player, selectedDomino, nextDraft);
		nextDraft.addSelection(dominoSelection);
		player.setDominoSelection(dominoSelection); //added for completeness to update model properly
		
		rotateOrder();
		
		turnCounter++;
		if(turnCounter==game.getNumberOfPlayers()) {
			KingdominoApplication.getStateMachine().dominoSelected(); //call state change
			System.out.println(KingdominoApplication.getStateMachine().getGamestatusFullName());
			turnCounter = 0; //reset counter
		}
		
	}
	
	public static void rotateOrder() {
		// Contributors: Ryad, ...
		Kingdomino kingdomino = KingdominoApplication.getKingdomino();
		Game game = kingdomino.getCurrentGame();
		game.setNextPlayer(game.getNextPlayer().getNext());
	}

	public static List<Player> generateInitialPlayerOrder() {
		// Contributors: Niilo, ...

		Kingdomino kingdomino = KingdominoApplication.getKingdomino();
		Game game = kingdomino.getCurrentGame();

		List<Player> players = KingdominoApplication.getKingdomino().getCurrentGame().getPlayers();
		int numPlayers = players.size();
		List<Player> playersCpy = new ArrayList<Player>();

		for (int i = 0; i < numPlayers; i++) {
			playersCpy.add(players.get(i));
		}

		List<Player> order = new ArrayList<Player>();
		List<Float> orderInt = new ArrayList<Float>();
		int hiIndex = 0;
		double prev = 0;

		Random rand = new Random();

		for (int i = 0; i < numPlayers; i++) {
			orderInt.add(rand.nextFloat());
		}
		for (int j = numPlayers; j > 0; j--) {
			for (int k = 0; k < j; k++) {
				if (orderInt.get(k) >= prev) {
					hiIndex = k;
				}
				prev = orderInt.get(k);
			}
			order.add(playersCpy.get(hiIndex));
			orderInt.remove(hiIndex);
			playersCpy.remove(hiIndex);
			hiIndex = 0;
			prev = 0;
		}

		KingdominoApplication.getKingdomino().getCurrentGame().setNextPlayer(order.get(0));
		Player nextPlayer = KingdominoApplication.getKingdomino().getCurrentGame().getNextPlayer();

		if (game.getNumberOfPlayers() == 4) {
			nextPlayer.setNext(order.get(1));
			nextPlayer.getNext().setNext(order.get(2));
			nextPlayer.getNext().getNext().setNext(order.get(3));
			nextPlayer.getNext().getNext().getNext().setNext(order.get(0));
		}
		if (game.getNumberOfPlayers() == 3) {
			nextPlayer.setNext(order.get(1));
			nextPlayer.getNext().setNext(order.get(2));
			nextPlayer.getNext().getNext().setNext(order.get(0));
		}
		if (game.getNumberOfPlayers() == 2) {
			nextPlayer.setNext(order.get(1));
			nextPlayer.getNext().setNext(order.get(0));
		}

		return order;
	}

	/**
	 * F#19: Identify kingdom properties: As a player, I want the Kingdomino app to
	 * automatically determine each properties of my kingdom so that my score can be
	 * calculated.
	 * 
	 * @author Michael Buchar
	 * @param Player player - player whose properties should be identified
	 * 
	 */
	public static void identifyKingdomProperties(Player player) {

		Kingdom kingdom = player.getKingdom();
		// Creating the kingdom array - very weird structure
		ArrayList<ArrayList<HashMap<String, String>>> kingdom2 = new ArrayList<ArrayList<HashMap<String, String>>>();
		for (int i = 0; i < 9; i++) {
			kingdom2.add(i, new ArrayList<HashMap<String, String>>());
			for (int j = 0; j < 9; j++) {
				kingdom2.get(i).add(j, new HashMap<String, String>());
				kingdom2.get(i).get(j).put("type", "");
				kingdom2.get(i).get(j).put("ID", "");
				kingdom2.get(i).get(j).put("checked", "N");
			}
		}

		// Adding the castle to array
		addToKingdomArray(0, 0, "C", 0, kingdom2);

		// Getting all the dominos and adding them to the array
		for (KingdomTerritory territory : kingdom.getTerritories()) {
			if (territory instanceof DominoInKingdom) {
				Domino dom = ((DominoInKingdom) territory).getDomino();
				int x = ((DominoInKingdom) territory).getX(), y = ((DominoInKingdom) territory).getY();
				DirectionKind dir = ((DominoInKingdom) territory).getDirection();

				if (dir == DirectionKind.Up) {
					addToKingdomArray(x, y, getTerrainType(dom.getLeftTile()), dom.getId(), kingdom2);
					addToKingdomArray(x, y + 1, getTerrainType(dom.getRightTile()), dom.getId(), kingdom2);
				} else if (dir == DirectionKind.Left) {
					addToKingdomArray(x, y, getTerrainType(dom.getLeftTile()), dom.getId(), kingdom2);
					addToKingdomArray(x - 1, y, getTerrainType(dom.getRightTile()), dom.getId(), kingdom2);
				} else if (dir == DirectionKind.Right) {
					addToKingdomArray(x, y, getTerrainType(dom.getLeftTile()), dom.getId(), kingdom2);
					addToKingdomArray(x + 1, y, getTerrainType(dom.getRightTile()), dom.getId(), kingdom2);
				} else if (dir == DirectionKind.Down) {
					addToKingdomArray(x, y, getTerrainType(dom.getLeftTile()), dom.getId(), kingdom2);
					addToKingdomArray(x, y - 1, getTerrainType(dom.getRightTile()), dom.getId(), kingdom2);
				}
			}
		}

		// Looping until all dominoes have been checked
		boolean done = false;
		while (done == false) {
			done = checker(kingdom, kingdom2);
		}
	}

	// Add values to kingdom
	private static void addToKingdomArray(int x, int y, String type, Integer dominoNum,
			ArrayList<ArrayList<HashMap<String, String>>> kingdom) {
		kingdom.get(4 - y).get(x + 4).replace("type", type);
		kingdom.get(4 - y).get(x + 4).replace("ID", dominoNum.toString());
	}

	// Looping through all tiles and seeing if they have been checked, if yes return
	// true
	private static boolean checker(Kingdom kingdom, ArrayList<ArrayList<HashMap<String, String>>> kingdom2) {
		HashMap<String, String> tile;
		for (int i = 0; i < 9; i++) {
			for (int j = 0; j < 9; j++) {
				tile = kingdom2.get(i).get(j);
				if (i == 4 && j == 4) {
					continue;
				}
				if ((tile.get("type")).compareTo("") != 0 && tile.get("checked").compareTo("N") == 0) {
					Property property = new Property(kingdom);
					// Just to test
					property.setPropertyType(getTerrainType(tile.get("type")));
					// Adding the starting domino to property
					property.addIncludedDomino(getdominoByID(tileTester(tile.get("type"), kingdom2.get(i).get(j))));
					// Running recursive call
					addAdjacentDominoesToProperty(property, tile.get("type"), kingdom2, i, j);
					return false;
				}
			}
		}
		return true;
	}

	// recursive helper method //
	// Recursively get all surrounding tiles and call TestTile on them //
	// If neighboring tiles are of the same type then call checkNeighbors on them //
	private static void addAdjacentDominoesToProperty(Property property, String type,
			ArrayList<ArrayList<HashMap<String, String>>> kingdom, int posX, int posY) {
		Integer rightTileOkay, leftTileOkay, upTileOkay, downTileOkay;

		// If not at borders check the next 4 tiles
		if (posX > 0) {
			leftTileOkay = tileTester(type, kingdom.get(posX - 1).get(posY));
		} else {
			leftTileOkay = null;

		}
		if (posX < 8) {
			rightTileOkay = tileTester(type, kingdom.get(posX + 1).get(posY));
		} else {
			rightTileOkay = null;
		}

		if (posY < 8) {
			upTileOkay = tileTester(type, kingdom.get(posX).get(posY + 1));
		} else {
			upTileOkay = null;
		}
		if (posY > 0) {
			downTileOkay = tileTester(type, kingdom.get(posX).get(posY - 1));
		} else {
			downTileOkay = null;
		}

		// If neighbor tile is of the same type then add the property to kingdom
		// Also check the neighbors of the tile
		if (rightTileOkay != null) {
			// Prevents adding dominoes that already exist in property
			property.addOrMoveIncludedDominoAt(getdominoByID(rightTileOkay), 0);
			addAdjacentDominoesToProperty(property, type, kingdom, posX + 1, posY);
		}
		if (leftTileOkay != null) {
			property.addOrMoveIncludedDominoAt(getdominoByID(leftTileOkay), 0);
			addAdjacentDominoesToProperty(property, type, kingdom, posX - 1, posY);
		}
		if (upTileOkay != null) {
			property.addOrMoveIncludedDominoAt(getdominoByID(upTileOkay), 0);
			addAdjacentDominoesToProperty(property, type, kingdom, posX, posY + 1);
		}
		if (downTileOkay != null) {
			property.addOrMoveIncludedDominoAt(getdominoByID(downTileOkay), 0);
			addAdjacentDominoesToProperty(property, type, kingdom, posX, posY - 1);
		}
	}

	// another helper method //
	// Test if tile is of type Type //
	private static Integer tileTester(String type, HashMap<String, String> tile) {
		// If tile has the same type and has not bee checked then return back id and
		// change tile to checked
		if (tile.get("type").compareTo(type) == 0 && tile.get("checked").compareTo("N") == 0) {
			tile.replace("checked", "Y");
			return Integer.parseInt(tile.get(("ID")));
		}
		return null;
	}

	/**
	 * F#23: Calculate ranking: As a player, I want the Kingdomino app to
	 * automatically calculate the ranking in order to know the winner of a finished
	 * game
	 * 
	 * @author Michael Buchar
	 * @param none
	 * @throws InvalidInputException
	 * @returns ranking of players in descending order (the winner is first in the
	 *          list, the loser last, etc)
	 * 
	 */
	public static List<Player> calculateRanking(Game game) throws InvalidInputException {

		// Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		List<Player> rankingOfPlayers = new ArrayList<>();
		HashMap<Player, Integer> playerScoreHashMap = new HashMap<>();

		// Adding all the values into the HashMap
		for (int i = 0; i < game.getNumberOfPlayers(); i++) {
			Player currentPlayer = game.getPlayers().get(i);
			int score = calculatePlayerScore(currentPlayer); // Modify based on other person's function
			Integer integerScore = new Integer(score);
			playerScoreHashMap.put(currentPlayer, integerScore);

		}

		// Sorting in descending order
		playerScoreHashMap = sortByValue(playerScoreHashMap);

		// To rank the players
		Iterator<Player> iter = playerScoreHashMap.keySet().iterator();
		int index = 0;
		while (iter.hasNext()) {
			Player player = iter.next();
			rankingOfPlayers.add(player);
			player.setCurrentRanking(index + 1);
			index++;
		}

		for (int i = 1; i < rankingOfPlayers.size(); i++) {
			int x1 = playerScoreHashMap.get(rankingOfPlayers.get(i));
			int x2 = playerScoreHashMap.get(rankingOfPlayers.get(i - 1));
			if (x1 == x2) {
				resolveTieBreak(rankingOfPlayers);
			}
		}
		return rankingOfPlayers; // returns the ranking of players in descending order (the winner is 1st etc..)
	}
	
	public static void generateOrderForPlacingDomino() {
		
		Kingdomino kingdomino = KingdominoApplication.getKingdomino();
		Game game = kingdomino.getCurrentGame();
		List<Domino> listDominos = game.getCurrentDraft().getIdSortedDominos();
		List<Player> listOfPlayers = game.getPlayers();
		ArrayList<Player> listOfPlayersOrdered = new ArrayList<Player>(listOfPlayers.size());
		
		for(Domino domino : listDominos) {
			for(Player player : listOfPlayers) {
				if(player.getDominoSelection().getDomino().getId() == domino.getId()) {
					listOfPlayersOrdered.add(player);
					break;
				}
			}
		}
		
		game.setNextPlayer(listOfPlayersOrdered.get(0));
		Player nextPlayer = game.getNextPlayer();
		
		if (game.getNumberOfPlayers() == 4) {
			nextPlayer.setNext(listOfPlayersOrdered.get(1));
			nextPlayer.getNext().setNext(listOfPlayersOrdered.get(2));
			nextPlayer.getNext().getNext().setNext(listOfPlayersOrdered.get(3));
			nextPlayer.getNext().getNext().getNext().setNext(listOfPlayersOrdered.get(0));
		}
		if (game.getNumberOfPlayers() == 3) {
			nextPlayer.setNext(listOfPlayersOrdered.get(1));
			nextPlayer.getNext().setNext(listOfPlayersOrdered.get(2));
			nextPlayer.getNext().getNext().setNext(listOfPlayersOrdered.get(0));
		}
		if (game.getNumberOfPlayers() == 2) {
			nextPlayer.setNext(listOfPlayersOrdered.get(1));
			nextPlayer.getNext().setNext(listOfPlayersOrdered.get(0));
		}
		
	}

	// function to sort HashMap by values
	public static HashMap<Player, Integer> sortByValue(HashMap<Player, Integer> hashmap) {
		// Create a list from elements of HashMap
		List<Entry<Player, Integer>> listOfEntries = new LinkedList<Map.Entry<Player, Integer>>(hashmap.entrySet());

		// Sort the list
		Collections.sort(listOfEntries, new Comparator<Map.Entry<Player, Integer>>() {
			public int compare(Map.Entry<Player, Integer> entry1, Map.Entry<Player, Integer> entry2) {
				return ((entry1.getValue()).compareTo(entry2.getValue()) * (-1));
			}
		});

		// put data from sorted list to hashmap
		HashMap<Player, Integer> hashmap2 = new LinkedHashMap<Player, Integer>();
		for (Map.Entry<Player, Integer> entries : listOfEntries) {
			hashmap2.put(entries.getKey(), entries.getValue());
		}
		return hashmap2;
	}

	/////////////////////////////////////////////////////////////////////////////////////////////

	/**
	 * F#15: Verify neighbor adjacency: As a player, I want the Kingdomino app to
	 * automatically check if my current domino is placed to an adjacent territory.
	 * 
	 * @author Alexandra Gafencu
	 * @return
	 */
	public static boolean verifyNeighborAdjacency(DominoInKingdom domino) {

		List<KingdomTerritory> territories = domino.getKingdom().getTerritories();

		int domX = domino.getX();
		int domY = domino.getY();

		TerrainType leftTileTerrain = domino.getDomino().getLeftTile();
		TerrainType rightTileTerrain = domino.getDomino().getRightTile();

		int crtId = domino.getDomino().getId();

		int domX2 = domX;
		int domY2 = domY;

		switch (domino.getDirection()) {
		case Up:
			domY2++;
			break;
		case Down:
			domY2--;
			break;
		case Left:
			domX2--;
			break;
		case Right:
			domX2++;
			break;
		}

		for (KingdomTerritory aDomino : territories) {
			if (aDomino instanceof DominoInKingdom) {
				DominoInKingdom domInKingdom = (DominoInKingdom) aDomino;
				// to not retest same id
				if (crtId == domInKingdom.getDomino().getId())
					continue;

				int tempX = aDomino.getX();
				int tempY = aDomino.getY();

				int tempX2 = tempX;
				int tempY2 = tempY;

				switch (domInKingdom.getDirection()) {
				case Up:
					tempY2++;
					break;
				case Down:
					tempY2--;
					break;
				case Left:
					tempX2--;
					break;
				case Right:
					tempX2++;
					break;
				}
				TerrainType tempLeftTileTerrain = domInKingdom.getDomino().getLeftTile();
				TerrainType tempRightTileTerrain = domInKingdom.getDomino().getRightTile();

				if (tempX == domX - 1 && tempY == domY) {
					if (tempLeftTileTerrain == leftTileTerrain)
						return true;
				}
				if (tempX == domX + 1 && tempY == domY) {
					if (tempLeftTileTerrain == leftTileTerrain)
						return true;
				}
				if (tempX == domX && tempY == domY - 1) {
					if (tempLeftTileTerrain == leftTileTerrain)
						return true;
				}
				if (tempX == domX && tempY == domY + 1) {
					if (tempLeftTileTerrain == leftTileTerrain)
						return true;
				}

				if (tempX == domX2 - 1 && tempY == domY2) {
					if (tempLeftTileTerrain == rightTileTerrain)
						return true;
				}
				if (tempX == domX2 + 1 && tempY == domY2) {
					if (tempLeftTileTerrain == rightTileTerrain)
						return true;
				}
				if (tempX == domX2 && tempY == domY2 - 1) {
					if (tempLeftTileTerrain == rightTileTerrain)
						return true;
				}
				if (tempX == domX2 && tempY == domY2 + 1) {
					if (tempLeftTileTerrain == rightTileTerrain)
						return true;
				}

				if (tempX2 == domX - 1 && tempY2 == domY) {
					if (tempRightTileTerrain == leftTileTerrain)
						return true;
				}
				if (tempX2 == domX + 1 && tempY2 == domY) {
					if (tempRightTileTerrain == leftTileTerrain)
						return true;
				}
				if (tempX2 == domX && tempY2 == domY - 1) {
					if (tempRightTileTerrain == leftTileTerrain)
						return true;
				}
				if (tempX2 == domX && tempY2 == domY + 1) {
					if (tempRightTileTerrain == leftTileTerrain)
						return true;
				}

				if (tempX2 == domX2 - 1 && tempY2 == domY2) {
					if (tempRightTileTerrain == rightTileTerrain)
						return true;
				}
				if (tempX2 == domX2 + 1 && tempY2 == domY2) {
					if (tempRightTileTerrain == rightTileTerrain)
						return true;
				}
				if (tempX2 == domX2 && tempY2 == domY2 - 1) {
					if (tempRightTileTerrain == rightTileTerrain)
						return true;
				}
				if (tempX2 == domX2 && tempY2 == domY2 + 1) {
					if (tempRightTileTerrain == rightTileTerrain)
						return true;
				}
			}
		}

		return false;
	}

	public static DominoInKingdom preplaceCurrentDomino(Player player, Domino domino) {

		DominoInKingdom preplacedDomino = new DominoInKingdom(0, 0, player.getKingdom(), domino);
		discardDomino(preplacedDomino);
		return preplacedDomino;
		
		
		
	}

	/**
	 * F#11: Move current domino: As a player, I wish to evaluate a provisional
	 * placement of my current domino by moving the domino around into my kingdom
	 * (up, down, left, right)
	 * 
	 * @author Alexandra Gafencu
	 */
	public static void moveCurrentDomino(DominoInKingdom domino, DirectionKind movement) {

		if (domino.getDomino().getStatus() == DominoStatus.InCurrentDraft) {
			domino.setX(0);
			domino.setY(0);
			domino.getDomino().setStatus(DominoStatus.ErroneouslyPreplaced);
			return;
		}

		int domX = domino.getX();
		int domY = domino.getY();

		int newX = domX;
		int newY = domY;

		switch (movement) {
		case Up:
			newY++;
			break;
		case Down:
			newY--;
			break;
		case Left:
			newX--;
			break;
		case Right:
			newX++;
			break;
		}

		int newX2 = newX;
		int newY2 = newY;

		switch (domino.getDirection()) {
		case Up:
			newY2++;
			break;
		case Down:
			newY2--;
			break;
		case Left:
			newX2--;
			break;
		case Right:
			newX2++;
			break;
		}

		if (!VerifyInKingdom(domino, newX, newY, newX2, newY2)) {
			domino.getDomino().setStatus(DominoStatus.ErroneouslyPreplaced);
		} else {
			domino.setX(newX);
			domino.setY(newY);
			boolean res;
			res = !VerifyNoOverlapping(domino);
			res &= (verifyNeighborAdjacency(domino) || verifyCastleAdjacency(domino));
			res &= verifyGridSize(domino);

			domino.getDomino().setStatus(res ? DominoStatus.CorrectlyPreplaced : DominoStatus.ErroneouslyPreplaced);
		}

	}

	// helper function to get min and max so that the way you move your domino will
	// not go past 5x5
	private static boolean VerifyInKingdom(DominoInKingdom domino, int newX, int newY, int newX2, int newY2) {
		List<KingdomTerritory> territories = domino.getKingdom().getTerritories();
		int crtId = domino.getDomino().getId();

		int minX = 4;
		int minY = 4;
		int maxX = -4;
		int maxY = -4;

		if (newX > minX || newX < maxX || newX2 > minX || newX2 < maxX) {
			return false;
		}
		if (newY > minY || newY < maxY || newY2 > minY || newY2 < maxY) {
			return false;
		}

		for (KingdomTerritory aDomino : territories) {
			if (aDomino instanceof DominoInKingdom) {
				DominoInKingdom domInKingdom = (DominoInKingdom) aDomino;
				if (crtId == domInKingdom.getDomino().getId())
					continue;

				int tempX = aDomino.getX();
				int tempY = aDomino.getY();

				int tempX2 = tempX;
				int tempY2 = tempY;

				switch (domInKingdom.getDirection()) {
				case Up:
					tempY2++;
					break;
				case Down:
					tempY2--;
					break;
				case Left:
					tempX2--;
					break;
				case Right:
					tempX2++;
					break;
				}

				if (minX > tempX)
					minX = tempX;
				if (minY > tempY)
					minY = tempY;
				if (maxX < tempX)
					maxX = tempX;
				if (maxY < tempY)
					maxY = tempY;
				if (minX > tempX2)
					minX = tempX2;
				if (minY > tempY2)
					minY = tempY2;
				if (maxX < tempX2)
					maxX = tempX2;
				if (maxY < tempY2)
					maxY = tempY2;
			} else {
				int tempX = aDomino.getX();
				int tempY = aDomino.getY();

				if (minX > tempX)
					minX = tempX;
				if (minY > tempY)
					minY = tempY;
				if (maxX < tempX)
					maxX = tempX;
				if (maxY < tempY)
					maxY = tempY;
			}
		}

		if (Math.abs(newX - minX) < 5 && Math.abs(maxX - newX) < 5 && Math.abs(newY - minY) < 5
				&& Math.abs(maxY - newY) < 5)
			return true;
		if (Math.abs(newX2 - minX) < 5 && Math.abs(maxX - newX2) < 5 && Math.abs(newY - minY) < 5
				&& Math.abs(maxY - newY2) < 5)
			return true;
		return false;
	}

	public enum RotationKind {
		clockwise, counterclockwise
	}

	/**
	 * F#12: Rotate current domino: As a player, I wish to evaluate a provisional
	 * placement of my current domino in my kingdom by rotating it (clockwise or
	 * counter-clockwise).
	 * 
	 * @author Alexandra Gafencu
	 */
	public static void rotateCurrentDomino(DominoInKingdom domino, RotationKind rotation) {

		if (domino.getDomino().getStatus() == DominoStatus.InCurrentDraft) {
			domino.setX(0);
			domino.setY(0);
			domino.getDomino().setStatus(DominoStatus.ErroneouslyPreplaced);
		}

		DirectionKind domDir = domino.getDirection();
		DirectionKind newDir = domDir;

		switch (rotation) {
		case clockwise:
			switch (domDir) {
			case Up:
				newDir = DirectionKind.Right;
				break;
			case Down:
				newDir = DirectionKind.Left;
				break;
			case Left:
				newDir = DirectionKind.Up;
				break;
			case Right:
				newDir = DirectionKind.Down;
				break;
			}
			break;
		case counterclockwise:
			switch (domDir) {
			case Up:
				newDir = DirectionKind.Left;
				break;
			case Down:
				newDir = DirectionKind.Right;
				break;
			case Left:
				newDir = DirectionKind.Down;
				break;
			case Right:
				newDir = DirectionKind.Up;
				break;
			}
			break;
		}

		int newX = domino.getX();
		int newY = domino.getY();

		int newX2 = newX;
		int newY2 = newY;

		switch (newDir) {
		case Up:
			newY2++;
			break;
		case Down:
			newY2--;
			break;
		case Left:
			newX2--;
			break;
		case Right:
			newX2++;
			break;
		}

		if (!VerifyInKingdom(domino, newX, newY, newX2, newY2)) {
			domino.getDomino().setStatus(DominoStatus.ErroneouslyPreplaced);
		} else {
			domino.setDirection(newDir);
			boolean res;
			res = !VerifyNoOverlapping(domino);
			res &= (verifyNeighborAdjacency(domino) || verifyCastleAdjacency(domino));
			res &= verifyGridSize(domino);

			domino.getDomino().setStatus(res ? DominoStatus.CorrectlyPreplaced : DominoStatus.ErroneouslyPreplaced);
		}

	}

	/**
	 * F#22: Calculate player score: As a player, I want the Kingdomino app to
	 * automatically calculate the score for each of my property based upon the size
	 * of that property and the number of crowns. The total score of the player
	 * should also include the bonus score.
	 * 
	 * @author Alexandra Gafencu
	 * @throws InvalidInputException
	 * @returns the player's score
	 */
	public static int calculatePlayerScore(Player player) throws InvalidInputException {

		// Kingdomino kingDomino = KingdominoApplication.getKingdomino();

		calculatePropertyAttribute(player);
		List<Property> playerProperties = player.getKingdom().getProperties();
		Controller.calculateBonusScore(player);
		int propertyScore = 0;
		for (Property property : playerProperties) {

			propertyScore += property.getCrowns() * property.getSize();
		}
		player.setPropertyScore(propertyScore);

		return player.getBonusScore() + propertyScore;
	}

	// Niilo's method but i just change the parameter to make it easier to use in my
	// function
	// his original is still there
	private static boolean verifyGridSize(DominoInKingdom domino) {

		List<KingdomTerritory> territories = domino.getKingdom().getTerritories();
		int x;
		int y;
		int maxX = 0;
		int maxY = 0;
		int minX = 0;
		int minY = 0;

		for (int i = 0; i < territories.size(); i++) {
			KingdomTerritory current = territories.get(i);
			x = territories.get(i).getX();
			y = territories.get(i).getY();
			if (x < minX) {
				minX = x;
				if (current instanceof DominoInKingdom
						&& ((DominoInKingdom) current).getDirection() == DirectionKind.Left) {
					minX = x - 1;
				}
			} else if (x > maxX) {
				maxX = x;
				if (current instanceof DominoInKingdom
						&& ((DominoInKingdom) current).getDirection() == DirectionKind.Right) {
					maxX = x + 1;
				}
			}
			if (y < minY) {
				minY = y;
				if (current instanceof DominoInKingdom
						&& ((DominoInKingdom) current).getDirection() == DirectionKind.Down) {
					minY = y - 1;
				}
			} else if (y > maxY) {
				maxY = y;
				if (current instanceof DominoInKingdom
						&& ((DominoInKingdom) current).getDirection() == DirectionKind.Up) {
					maxY = y + 1;
				}
			}
		}

		if (Math.abs(maxX - minX) < 5 && Math.abs(maxY - minY) < 5)
			return true;
		else
			return false;

	}
	/////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////

	/**
	 * F#13 Places the current domino in the specified coordinates, throws an
	 * exception if the coordinates and direction aren't valid
	 * 
	 * @author Niilo Vuokila
	 * @param the         current player
	 * @param the         current domino
	 * @param x           coordinate of the pivot point
	 * @param y           coordinate of the pivot point
	 * @param orientation of the domino
	 * @throws InvalidInputException
	 */

	public static void placeCurrentDomino(Player player, Domino domino, int x, int y, DirectionKind direction) throws InvalidInputException {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		DominoInKingdom placedDomino = null;
		for(int i =0; i<player.getKingdom().getTerritories().size();i++) {
			if(player.getKingdom().getTerritory(i) instanceof DominoInKingdom) {
				if(((DominoInKingdom) player.getKingdom().getTerritory(i)).getDomino().getId() == domino.getId()) {
					placedDomino = (DominoInKingdom) player.getKingdom().getTerritory(i);
				}
			}
		}
		
		if (getDominoCondition(placedDomino, player)) {
			domino.setStatus(DominoStatus.PlacedInKingdom);
			player.removeSelection();
			game.setNextPlayer(player.getNext());
		} else {
			throw new InvalidInputException("The domino cannot be placed in the orientation or coordinates provided");
		}
		
		turnCounter++;
		if(turnCounter==game.getNumberOfPlayers()) {
			KingdominoApplication.getStateMachine().dominoPlaced(); //call state change
			System.out.println(KingdominoApplication.getStateMachine().getGamestatusFullName());
			turnCounter = 0; //reset counter
			AGameplay.addDraftToView();
		}
	}

	/**
	 * F#9 Orders the next draft of dominos using selection sort and reveals the
	 * draft
	 * 
	 * @author Niilo Vuokila
	 */
	public static void orderAndRevealNextDraft() {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		if (game.getNextDraft().getDraftStatus().equals(DraftStatus.FaceDown)) {
			List<Domino> unsortedList = game.getNextDraft().getIdUnsortedDominos();
			Domino[] sortedList = new Domino[unsortedList.size()];
			Draft draft = game.getNextDraft();

			for (int i = 0; i < unsortedList.size(); i++) {
				sortedList[i] = unsortedList.get(i);
			}

			Domino minID;
			Domino temp = null;
			int index = 0;

			// sorting list using selection sort
			for (int i = 0; i < sortedList.length; i++) {
				minID = sortedList[i];

				for (int j = i; j < sortedList.length; j++) {
					if (sortedList[j].getId() <= minID.getId()) {
						minID = sortedList[j];
						index = j;
					}
				}
				temp = sortedList[i];
				sortedList[i] = minID;
				sortedList[index] = temp;

			}

			for (int i = 0; i < sortedList.length; i++) {
				draft.addIdSortedDomino(sortedList[i]);
			}
			draft.setIdSortedDominos(sortedList);
			draft.setDraftStatus(DraftStatus.Sorted);
		}

		else if (game.getNextDraft().getDraftStatus().equals(DraftStatus.Sorted)) { // added the else if statement as I
																					// was unaware of the changes made
																					// to this method's requirements at
																					// the time of iteration 2
			game.getNextDraft().setDraftStatus(DraftStatus.FaceUp);
		}
		
		game.getNextDraft().getIdUnsortedDominosModifiable().clear();

	}

	/**
	 * F#17: Verifies the kingdom grid size through coordinates on the dominos as
	 * well as their orientation
	 * 
	 * @author Niilo Vuokila
	 * @param The player for whom the grid size is verified
	 * @returns True if kingdom is of correct size, false otherwise
	 */
	public static boolean verifyGridSize(Player player) {
		Kingdom kingdom = player.getKingdom();
		List<KingdomTerritory> territories = kingdom.getTerritories();
		int x;
		int y;
		int maxX = 0;
		int maxY = 0;
		int minX = 0;
		int minY = 0;

		for (int i = 0; i < territories.size(); i++) {
			KingdomTerritory current = territories.get(i);
			x = territories.get(i).getX();
			y = territories.get(i).getY();
			if (x < minX) {
				minX = x;
				if (current instanceof DominoInKingdom
						&& ((DominoInKingdom) current).getDirection() == DirectionKind.Left) {
					minX = x - 1;
				}
			} else if (x > maxX) {
				maxX = x;
				if (current instanceof DominoInKingdom
						&& ((DominoInKingdom) current).getDirection() == DirectionKind.Right) {
					maxX = x + 1;
				}
			}
			if (y < minY) {
				minY = y;
				if (current instanceof DominoInKingdom
						&& ((DominoInKingdom) current).getDirection() == DirectionKind.Down) {
					minY = y - 1;
				}
			} else if (y > maxY) {
				maxY = y;
				if (current instanceof DominoInKingdom
						&& ((DominoInKingdom) current).getDirection() == DirectionKind.Up) {
					maxY = y + 1;
				}
			}
		}

		if (Math.abs(maxX - minX) < 5 && Math.abs(maxY - minY) < 5)
			return true;
		else
			return false;
	}

	/**
	 * F#14: Verifies whether or not the domino in kingdom is adjacent to a castle
	 * 
	 * @author Niilo Vuokila
	 * @param the current domino in kingdom
	 * @returns true if input domino is adjacent to a castle, false otherwise
	 */
	public static boolean verifyCastleAdjacency(DominoInKingdom domino) {
		List<KingdomTerritory> territories = domino.getKingdom().getTerritories();
		Castle castle = null;
		int domX = domino.getX();
		int domY = domino.getY();

		for (int i = 0; i < territories.size(); i++) {
			if (territories.get(i) instanceof Castle) {
				castle = (Castle) territories.get(i);
			}
		}

		int casX = castle.getX();
		int casY = castle.getY();
		// pivot point is next to castle:
		if (domX - 1 == casX && domY == casY || domX + 1 == casX && domY == casY || domX == casX && domY - 1 == casY
				|| domX == casX && domY + 1 == casY) {
			return true;
		}
		// pivot point is not next to castle, but other side is:
		if (domino.getDirection() == DirectionKind.Up) {
			if (domX + 1 == casX && domY + 1 == casY || domX - 1 == casX && domY + 1 == casY
					|| domX == casX && domY + 2 == casY) {
				return true;
			}
		}
		if (domino.getDirection() == DirectionKind.Left) {
			if (domX - 1 == casX && domY - 1 == casY || domX - 1 == casX && domY + 1 == casY
					|| domX - 2 == casX && domY == casY) {
				return true;
			}
		}
		if (domino.getDirection() == DirectionKind.Down) {
			if (domX + 1 == casX && domY - 1 == casY || domX - 1 == casX && domY - 1 == casY
					|| domX == casX && domY - 2 == casY) {
				return true;
			}
		}
		if (domino.getDirection() == DirectionKind.Right) {
			if (domX + 1 == casX && domY - 1 == casY || domX + 1 == casX && domY + 1 == casY
					|| domX + 2 == casX && domY == casY) {
				return true;
			}
		}
		return false;
	}

	/////////////////////////////////////////////////////////////////////////////////////////////

	/**
	 * #21: Calculate bonus scores: As a player, I want the Kingdomino app to
	 * automatically calculate the bonus scores (for Harmony and middle Kingdom) if
	 * those bonus scores were selected as a game option.
	 * 
	 * @author Vadim Tuchila
	 * @param player - player whose bonus score we want to calculate
	 * @return int - bonus score of the player
	 * @throws InvalidInputException
	 */

	public static int calculateBonusScore(Player player) throws InvalidInputException {

		Kingdomino kingDomino = KingdominoApplication.getKingdomino();
		Game game = kingDomino.getCurrentGame();// current game
		Kingdom kingdom = player.getKingdom(); // player's kingdom
		List<KingdomTerritory> playerTerritories = player.getKingdom().getTerritories(); // a list of all properties of
																							// the inputted player
		List<BonusOption> bonusOptions = game.getSelectedBonusOptions(); // selected bonus options in the game

		int middleKingdomScore = 0;
		int kingdomDominoes = 0; // sum of included dominoes in the player's kingdom used for the determination
									// of harmonyScore
		int harmonyScore = 0;
		int bonusScore = 0; // sum of harmonyScore and middleKingdomScore
		boolean middleKingdom = false;
		boolean harmony = false;

		// booleans necessary for the determination of the presence of a certain domino
		// at the boundaries
		// of the board, used specifically for the verification of the validity of the
		// bonus score MiddleKingdom
		boolean hasDominoXMinus2 = false;
		boolean hasDominoXPlus2 = false;
		boolean hasDominoYMinus2 = false;
		boolean hasDominoYPlus2 = false;

		if (player == null || game == null || kingDomino == null) {
			throw new InvalidInputException("");
		}

		// List of bonusOptions chosen by the player

		// whether option has been selected or not
		if (bonusOptions.size() > 0) {
			for (BonusOption bonus : bonusOptions) {
				if ((bonus.getOptionName().equalsIgnoreCase("MiddleKingdom"))
						|| (bonus.getOptionName().equalsIgnoreCase("isUsingMiddleKingdom"))) {
					middleKingdom = true;
				}
			}
			for (BonusOption bonus : bonusOptions) {
				if ((bonus.getOptionName().equalsIgnoreCase("Harmony"))
						|| (bonus.getOptionName().equalsIgnoreCase("isUsingHarmony"))) {
					harmony = true;
				}
			}

			// if no bonus option was selected
			if (!middleKingdom && !harmony) {
				return 0;
			}

			if (harmony) { // if Harmony bonus option has been selected
				if (playerTerritories == null) {
					return 0;
				} else if (playerTerritories != null) {
					kingdomDominoes = playerTerritories.size();
					// if ((game.getNumberOfPlayers() == 4) || (game.getNumberOfPlayers() == 3)) {
					// //in a 3 or 4 player game
					if (kingdomDominoes >= 12) { // if the kingdom contains all 12 dominoes, then the bonus for harmony
													// is 5
						harmonyScore = 5; // harmony bonus score is set to 5
					}
					// }
					// else if((game.getNumberOfPlayers() == 2) && (kingdomDominoes == 6)) {
					// harmonyScore = 5; //if the kingdom contains all 6 dominoes (in a 2 player
					// game), then the bonus for harmony is 5
					// }
				}
			}

			if (middleKingdom) { // if MiddleKingdom bonus option has been selected
				for (KingdomTerritory kingdomTerritory : playerTerritories) {
					if (kingdomTerritory instanceof DominoInKingdom) {
						DominoInKingdom someDominoInKingdom = (DominoInKingdom) kingdomTerritory;
						DirectionKind dir = someDominoInKingdom.getDirection();

						// verifying that there is a domino at the boundaries of the board, if yes, then
						// MiddleKingdom bonus is 10; 0 otherwise.
						if (dir.equals(DirectionKind.Up)) {
							if (someDominoInKingdom.getX() == -2) {
								hasDominoXMinus2 = true;
							} else if (someDominoInKingdom.getX() == 2) {
								hasDominoXPlus2 = true;
							} else if (someDominoInKingdom.getY() + 1 == 2) {
								hasDominoYPlus2 = true;
							} else if (someDominoInKingdom.getY() == -2) {
								hasDominoYMinus2 = true;
							}
						}

						else if (dir.equals(DirectionKind.Down)) {
							if (someDominoInKingdom.getX() == -2) {
								hasDominoXMinus2 = true;
							} else if (someDominoInKingdom.getX() == 2) {
								hasDominoXPlus2 = true;
							} else if (someDominoInKingdom.getY() == 2) {
								hasDominoYPlus2 = true;
							} else if (someDominoInKingdom.getY() - 1 == -2) {
								hasDominoYMinus2 = true;
							}
						}

						else if (dir.equals(DirectionKind.Left)) {
							if (someDominoInKingdom.getX() - 1 == -2) {
								hasDominoXMinus2 = true;
							} else if (someDominoInKingdom.getX() == 2) {
								hasDominoXPlus2 = true;
							} else if (someDominoInKingdom.getY() == 2) {
								hasDominoYPlus2 = true;
							} else if (someDominoInKingdom.getY() == -2) {
								hasDominoYMinus2 = true;
							}
						}

						else if (dir.equals(DirectionKind.Right)) {
							if (someDominoInKingdom.getX() == -2) {
								hasDominoXMinus2 = true;
							} else if (someDominoInKingdom.getX() + 1 == 2) {
								hasDominoXPlus2 = true;
							} else if (someDominoInKingdom.getY() == 2) {
								hasDominoYPlus2 = true;
							} else if (someDominoInKingdom.getY() == -2) {
								hasDominoYMinus2 = true;
							}
						}
						// //if at least one domino is at a distance larger than 2 tiles from the castle
						// (situated at (0,0)), then the kingdom is not in the center and the bonus
						// score is equal to 0
						// if ((kingdomTerritory.getX()<-2) || (kingdomTerritory.getX()>2) ||
						// (kingdomTerritory.getY()<-2) || (kingdomTerritory.getY()>2)) {
						// return harmonyScore; //middleKingdom is 0, so the only value composing the
						// bonusScore is harmonyScore
						// }
					}

				}
				if (hasDominoXMinus2 && hasDominoXPlus2 && hasDominoYMinus2 && hasDominoYPlus2) {
					middleKingdomScore = 10;
				}
			}
		}
		bonusScore = harmonyScore + middleKingdomScore;
		player.setBonusScore(bonusScore); // set player's final bonus score at the end of the game
		return bonusScore;
	}

	/**
	 * Feature #24: Resolve tiebreak: As a player, I want the Kingdomino app to
	 * automatically resolve a potential tiebreak (i.e. equal score between players)
	 * by evaluating the most extended (largest) property and then the total number
	 * of crowns.
	 * 
	 * @author Vadim Tuchila
	 * @param List<Player> playerRankings - initial player rankings
	 * @throws InvalidInputException
	 */
	public static void resolveTieBreak(List<Player> playerRankings) throws InvalidInputException {

		Player player1 = playerRankings.get(0);
		Player player2 = playerRankings.get(1);

		Player player3 = playerRankings.get(2);
		Player player4 = playerRankings.get(3);
		player3.setCurrentRanking(3);
		player4.setCurrentRanking(4);

		int p1LargestProperty = 0;
		int p2LargestProperty = 0;

		Kingdom kingdom1 = player1.getKingdom();
		Kingdom kingdom2 = player2.getKingdom();

		for (Property p1 : kingdom1.getProperties()) {
			if (p1.getSize() > p1LargestProperty) {
				p1LargestProperty = p1.getSize();
			}
		}

		for (Property p2 : kingdom2.getProperties()) {
			if (p2.getSize() > p2LargestProperty) {
				p2LargestProperty = p2.getSize();
			}
		}

		if (p1LargestProperty > p2LargestProperty) {
			player1.setCurrentRanking(1);
			player2.setCurrentRanking(2);
		} else if (p1LargestProperty < p2LargestProperty) {
			player2.setCurrentRanking(1);
			player1.setCurrentRanking(2);

			// if they're equal look at number of crowns
		} else {

			int p1Crowns = 0;
			int p2Crowns = 0;

			for (Property p1 : kingdom1.getProperties()) {
				p1Crowns = p1Crowns + p1.getCrowns();
			}

			for (Property p2 : kingdom2.getProperties()) {
				p2Crowns = p2Crowns + p2.getCrowns();
			}

			if (p1Crowns > p2Crowns) {
				player1.setCurrentRanking(1);
				player2.setCurrentRanking(2);

			} else if (p1Crowns < p2Crowns) {
				player2.setCurrentRanking(1);
				player1.setCurrentRanking(2);

			} else {
				player1.setCurrentRanking(1);
				player2.setCurrentRanking(1);
				playerRankings.get(2).setCurrentRanking(2);
				playerRankings.get(3).setCurrentRanking(3);
			}
		}
	}

	/**
	 * Feature #4: Browse domino pile: As a player, I wish to browse the set of all
	 * dominos in increasing order of numbers prior to playing the game so that I
	 * can adjust my strategy
	 * 
	 * @author Vadim Tuchila
	 * @return List<Domino> - list of all dominoes in the pile before the start of
	 *         the game
	 * @throws InvalidInputException
	 */
	public static List<Domino> browseDominoes() throws InvalidInputException {

		Kingdomino kingDomino = KingdominoApplication.getKingdomino();
		Game game = kingDomino.getCurrentGame();

		List<Domino> allDominoes = new ArrayList<Domino>(); // all dominoes in the game no matter their status
															// (discarded, inPile, inCurrentDraft, etc)

		if (game == null) {
			throw new InvalidInputException("No game is being currently played. Start a new game.");
		}

		// Make browsing by terrain type with a for loop, selecting only those with the
		// corresponding terrain type
		else if (game != null) {
			allDominoes = game.getAllDominos(); // all dominoes in the game no matter their status (discarded, inPile,
												// inCurrentDraft, etc)

		}
		return allDominoes;
	}

	/**
	 * Feature #4: Browse domino pile: As a player, I wish to browse the set of all
	 * dominos in increasing order of numbers prior to playing the game so that I
	 * can adjust my strategy
	 * 
	 * @author Vadim Tuchila
	 * @return Domino - domino in the pile with Id
	 * @throws InvalidInputException
	 */
	public static Domino browseDominoes(int id) throws InvalidInputException {
		Kingdomino kingDomino = KingdominoApplication.getKingdomino();
		Game game = kingDomino.getCurrentGame();

		List<Domino> allDominoes = new ArrayList<Domino>(); // all dominoes in the game no matter their status
															// (discarded, inPile, inCurrentDraft, etc)

		if (game == null) {
			throw new InvalidInputException("No game is being currently played. Start a new game.");
		}

		else if (game != null) {
			allDominoes = game.getAllDominos(); // all dominoes in the game no matter their status (discarded, inPile,
												// inCurrentDraft, etc)

			for (Domino someDomino : allDominoes) {
				if (someDomino.getId() == id) {
					return someDomino;
				}
			}
		}
		return null;
	}

	/**
	 * Feature #4: Browse domino pile: As a player, I wish to browse the set of all
	 * dominos in increasing order of numbers prior to playing the game so that I
	 * can adjust my strategy
	 * 
	 * @author Vadim Tuchila
	 * @return List<Domino> - list of dominoes in the pile by terrain type before
	 *         the start of the game
	 * @throws InvalidInputException
	 */
	public static List<Domino> browseDominoes(TerrainType terrainType) throws InvalidInputException {
		Kingdomino kingDomino = KingdominoApplication.getKingdomino();
		Game game = kingDomino.getCurrentGame();

		List<Domino> dominoesByTerrainType = new ArrayList<Domino>(); // dominoes by terrain type
		List<Domino> allDominoes = new ArrayList<Domino>(); // all dominoes in the game no matter their status
															// (discarded, inPile, inCurrentDraft, etc)

		// Make browsing by terrain type with a for loop, selecting only those with the
		// corresponding terrain type
		if (game == null) {
			throw new InvalidInputException("No game is being currently played. Start a new game.");
		}

		else if (game != null) {
			allDominoes = game.getAllDominos(); // all dominoes in the game no matter their status (discarded, inPile,
												// inCurrentDraft, etc)

			for (Domino someDomino : allDominoes) {
				if ((someDomino.getLeftTile().equals(terrainType)) || (someDomino.getRightTile().equals(terrainType))) {
					dominoesByTerrainType.add(someDomino);
				}
			}
		}
		return dominoesByTerrainType;
	}

	/**
	 * @author Vadim Tuchila
	 * @param List<Domino> - list of dominoes in the pile before the start of the
	 *                     game
	 * @throws InvalidInputException
	 */
	public static void printDominoesInPile(List<Domino> dominoPile) throws InvalidInputException {
		for (Domino domino : dominoPile) {
			domino.toString();
		}
	}

	/**
	 * Feature #6: Load game: As a player, I want to load a previously played game
	 * so that I can continue it from the last position.
	 * 
	 * @author Vadim Tuchila
	 * @return Kingdomino - Kingdomino from the file at filePath (location of file)
	 * @throws InvalidInputException
	 */
	public static Kingdomino load(String filePath) throws InvalidInputException {

		Kingdomino kingDomino = null;
		if (filePath == null) {
			throw new RuntimeException("The Game File Is Invalid");
		}
		kingDomino = ca.mcgill.ecse223.kingdomino.persistence.KingDominoPersistence.load(filePath);
		KingdominoApplication.setKingdomino(kingDomino);

//		kingDomino = KingdominoApplication.getKingdomino();
//		ArrayList<String> input = new ArrayList<String>();
//		try {
//			FileInputStream fis = new FileInputStream(filePath);
//			Scanner s = new Scanner(fis);
//			while(s.hasNextLine() ) {
//				input.add(s.nextLine());
//			}
//			s.close();
//
//		} catch(IOException e) {
//			e.printStackTrace();
//		}

		return kingDomino;

	}

	/////////////////////////////////////////////////////////////////////////////////////////////

	/**
	 * F#3: Start a new game: As a Kingdomino player, I want to start a new game of
	 * Kingdomino against some opponents with my castle placed on my territory with
	 * the current settings of the game. The initial order of player should be
	 * randomly determined.
	 * 
	 * @author Catherine Van Gheluwe
	 * @param numberOfPlayers
	 * @return
	 * @throws InvalidInputException
	 */
	public static void startANewGame(int numberOfPlayers, List<String> namesToBeAdded) throws Exception {
		Game newGame;

		Kingdomino kingDomino = KingdominoApplication.getKingdomino();// get the kingDomino app
		Game game = kingDomino.getCurrentGame();

		if (game == null) {
			game = new Game(48, kingDomino);
		}

		List<Player> playersInGame;
		int aMaxPileSize;

		// make a new list of players in the game
		if (numberOfPlayers == 2) {

			aMaxPileSize = 48;
			addUserToGame(namesToBeAdded, numberOfPlayers);
			game.setNumberOfPlayers(numberOfPlayers);
			kingDomino.setCurrentGame(game);

			Random random = new Random();
			// determine the order of players

			for (int i = 0; i < game.getPlayers().size(); i++) {
				int newIndex = random.nextInt(1);
				Player newPlayer = game.getPlayer(i);
				game.addOrMovePlayerAt(newPlayer, newIndex);

			}
			game.setNextPlayer(game.getPlayer(0));

		} else if (numberOfPlayers == 3) {
			aMaxPileSize = 36;
			addUserToGame(namesToBeAdded, numberOfPlayers);
			game.setNumberOfPlayers(numberOfPlayers);

			Random random = new Random();
			// determine the order of players

			for (int i = 0; i < game.getPlayers().size(); i++) {
				int newIndex = random.nextInt(2);
				Player newPlayer = game.getPlayer(i);
				game.addOrMovePlayerAt(newPlayer, newIndex);
			}
			game.setNextPlayer(game.getPlayer(0));

		} else {

			aMaxPileSize = 48;
			addUserToGame(namesToBeAdded, 4);
			game.setNumberOfPlayers(numberOfPlayers);
			kingDomino.setCurrentGame(game);

			Random random = new Random();
			// determine the order of players

			for (int i = 0; i < game.getPlayers().size(); i++) {
				int newIndex = random.nextInt(3);
				Player newPlayer = game.getPlayer(i);
				game.addOrMovePlayerAt(newPlayer, newIndex);
			}
			game.setNextPlayer(game.getPlayer(0));

		}

		// adding all the dominos;
		createAllDominoes(game);

		if (numberOfPlayers == 2) {
			specialModeDominoPile(24);
		}

		if (numberOfPlayers == 3) {
			specialModeDominoPile(12);
		} else {
			shuffleDominoPile();

		}
		game.setNextDraft(game.getCurrentDraft());
		orderAndRevealNextDraft();

		game.getAllDraft(0).setDraftStatus(DraftStatus.FaceUp);

		KingDominoPersistence.save(kingDomino);

		KingdominoApplication.getStateMachine().buttonPressed();

	}

	private static void createAllDominoes(Game game) {
		try {
			BufferedReader br = new BufferedReader(new FileReader("src/main/resources/alldominoes.dat"));
			String line = "";
			String delimiters = "[:\\+()]";
			while ((line = br.readLine()) != null) {
				String[] dominoString = line.split(delimiters); // {id, leftTerrain, rightTerrain, crowns}
				int dominoId = Integer.decode(dominoString[0]);
				TerrainType leftTerrain = getTerrainType(dominoString[1]);
				TerrainType rightTerrain = getTerrainType(dominoString[2]);
				int numCrown = 0;
				if (dominoString.length > 3) {
					numCrown = Integer.decode(dominoString[3]);
				}
				new Domino(dominoId, leftTerrain, rightTerrain, numCrown, game);
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
			throw new java.lang.IllegalArgumentException(
					"Error occured while trying to read alldominoes.dat: " + e.getMessage());
		} 
	}

	/**
	 * F#16: Verify no overlapping: As a player, I want the Kingdomino app to
	 * automatically check that my current domino is not overlapping with existing
	 * dominos.
	 *
	 * @author catherine van gheluwe
	 * 
	 * @param DominoInKingdom dominoPreplaced
	 * 
	 * @return false if no overlapping, true otherwise
	 */
	public static boolean VerifyNoOverlapping(DominoInKingdom dominoPreplaced) {

		// find ll attributes of the preplaced domino
		DirectionKind dominoPreplacedDirection = dominoPreplaced.getDirection();
		int dominoPreplacedId = dominoPreplaced.getDomino().getId();

		List<KingdomTerritory> territories = dominoPreplaced.getKingdom().getTerritories();

		int dominoPreplacedX = dominoPreplaced.getX();
		int dominoPreplacedY = dominoPreplaced.getY();

		int crtId = dominoPreplaced.getDomino().getId();

		int dominoPreplacedX2 = dominoPreplacedX;
		int dominoPreplacedY2 = dominoPreplacedY;

		switch (dominoPreplaced.getDirection()) {
		case Up:
			dominoPreplacedY2++;
			break;
		case Down:
			dominoPreplacedY2--;
			break;
		case Left:
			dominoPreplacedX2--;
			break;
		case Right:
			dominoPreplacedX2++;
			break;
		}

		for (KingdomTerritory aDomino : territories) {
			if (aDomino instanceof DominoInKingdom) {
				DominoInKingdom domInKingdom = (DominoInKingdom) aDomino;

				if (crtId == domInKingdom.getDomino().getId())
					continue;

				int aDominoX = aDomino.getX();
				int aDominoY = aDomino.getY();

				int aDominoX2 = aDominoX;
				int aDominoY2 = aDominoY;

				switch (domInKingdom.getDirection()) {
				case Up:
					aDominoY2++;
					break;
				case Down:
					aDominoY2--;
					break;
				case Left:
					aDominoX2--;
					break;
				case Right:
					aDominoX2++;
					break;
				}
				if ((aDominoX == dominoPreplacedX && aDominoY == dominoPreplacedY)
						|| (aDominoX == dominoPreplacedX2 && aDominoY == dominoPreplacedY2)
						|| (aDominoX2 == dominoPreplacedX && aDominoY2 == dominoPreplacedY)
						|| (aDominoX2 == dominoPreplacedX2 && aDominoY2 == dominoPreplacedY2))
					return true;

			} // end of if statement
		} // end of for statement
		return false; // means that it was not found. verify this i'm just guessing
	} // end of feature method

	private static TerrainType getTerrainType(String terrain) {
		switch (terrain) {
		case "W":
			return TerrainType.WheatField;
		case "F":
			return TerrainType.Forest;
		case "M":
			return TerrainType.Mountain;
		case "G":
			return TerrainType.Grass;
		case "S":
			return TerrainType.Swamp;
		case "L":
			return TerrainType.Lake;
		default:
			throw new java.lang.IllegalArgumentException("Invalid terrain type: " + terrain);
		}
	}

	private static String getTerrainType(TerrainType terrain) {
		switch (terrain) {
		case WheatField:
			return "W";
		case Forest:
			return "F";
		case Mountain:
			return "M";
		case Grass:
			return "G";
		case Swamp:
			return "S";
		case Lake:
			return "L";
		default:
			throw new java.lang.IllegalArgumentException("Invalid terrain type: " + terrain);
		}
	}

	private static Domino getdominoByID(int id) {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		for (Domino domino : game.getAllDominos()) {
			if (domino.getId() == id) {
				return domino;
			}
		}
		throw new java.lang.IllegalArgumentException("Domino with ID " + id + " not found.");
	}

	/**
	 *
	 * F#2: Provide user profile: As a player, I wish to use my unique user name in
	 * when a game starts. I also want the Kingdomino app to maintain my game
	 * statistics (e.g. number of games played, won, etc.).
	 * 
	 * @author catherine van gheluwe
	 * @param String userName - user's name
	 * @return User
	 */
	public static User provideUserProfile(String userName, boolean create) throws Exception {
		boolean validate;
		Kingdomino kingDomino = KingdominoApplication.getKingdomino();
		Game game = kingDomino.getCurrentGame();

		List<User> users = kingDomino.getUsers();

		List<String> userNames = new ArrayList<String>();

		// added a for loop
		for (User user : users) {
			userNames.add(user.getName());
		}

		int sizeOfList = kingDomino.numberOfUsers();
		
		if(create == true) {
			validate = ValidCreation(userName);

		}else {
			validate = ValidUserName(userName);
			if(!validate) {
				validate = true;
			}
		}
		
		if (validate == true) {

			// use unique name to maintain the users statistics
			for (int i = 0; i < userNames.size(); i++) {
				if (userNames.contains(userName)) {
					User aUser = User.getWithName(userName);
					int playedGames = aUser.getPlayedGames();
					int wonGames = aUser.getPlayedGames();
					KingDominoPersistence.save(kingDomino);
					return aUser;
				} else {
					if (create == true) {

						User aUser = new User(userName, kingDomino);
						kingDomino.addUserAt(aUser, kingDomino.getUsers().size() + 1);
						KingDominoPersistence.save(kingDomino);

					} else {
						return null;
						// throw new Exception("no user with the name " + userName + " exists!");
					}

				}
			}
			if (create == true) {

				User aUser = new User(userName, kingDomino);
				KingDominoPersistence.save(kingDomino);
				return aUser;

			}

		} else {

			throw new InvalidInputException("Special Characters are not allowed in names. Use letters or numbers");
		}

		KingDominoPersistence.save(kingDomino);
		return null;

	}

	/**
	 * F#7: Save game: As a player, I want to save the current game if the game has
	 * not yet been finished so that I can continue it later.
	 * 
	 * @author Catherine
	 * @throws InvalidInputException
	 */
	public static void save(Kingdomino kingDomino) throws InvalidInputException {

		kingDomino = KingdominoApplication.getKingdomino();
		// PersistenceObjectStream.serialize(kingDomino);

		if (kingDomino == null) {
			throw new InvalidInputException("There is no game to save");
		} else {
			ca.mcgill.ecse223.kingdomino.persistence.KingDominoPersistence.save(kingDomino);

		}
	}

	// helper for gherkin tests
	private static Player currentPlayer;

	public static void setCurrentPlayer(Player cPlayer) {
		currentPlayer = cPlayer;
	}

	public static Player getCurrentPlayer() {
		return currentPlayer;
	}

	/**
	 * This method takes as input all the names inputed from the View when started a
	 * new game. It gos through all names and adds the players and their
	 * corresponding users to the game. If the list of users in the application is
	 * empty, the method will create a new user and a new player. If it isnt empty,
	 * the method will go through the list of names in the database. It first checks
	 * if the inputed name is correct ( if the person has a name " ", the method
	 * ignores it and skips to the next name). If the name is correct, the method
	 * will then check if a user of such name exists. if it exists already, it will
	 * add a player to a game and increment the players played game y 1. If the name
	 * does not exist, the method will create a new User with corresponding name.
	 * 
	 * @param names
	 * @author Catherine Van Gheluwe
	 * @throws Exception
	 */
	private static void addUserToGame(List<String> names, int numPlayers) throws Exception {
		Kingdomino kingDomino = KingdominoApplication.getKingdomino();
		Game game = kingDomino.getCurrentGame();

		List<User> userList = kingDomino.getUsers();
		List<String> userNames = getListOfNames(kingDomino);

		if (numPlayers == 2 || numPlayers == 3) {
			try {
				specialMode(names);
				return;
			} catch (Exception e) {
				throw new Exception("the username is already used");
			}

		}

		if (userList.isEmpty()) {
			for (int i = 0; i < names.size(); i++) {
				User newUser = new User(names.get(i), kingDomino);
				Player player = new Player(game);
				player.setUser(newUser);
				player.setColor(PlayerColor.values()[i]);
				newUser.setPlayedGames(newUser.getPlayedGames() + 1);
				Kingdom kingdom = new Kingdom(player);
				game.addPlayerAt(player, i);
				new Castle(0, 0, kingdom, player);
				userNames.add(names.get(i));
			}
		} else {
			for (int i = 0; i < names.size(); i++) {
				if (names.equals("")) {
					continue;
				}
				boolean goodName = specialCharacters(names.get(i));
				if (goodName == false) {

					if (userNames.contains(names.get(i))) {
						User existingUser = User.getWithName(names.get(i));
						Player newPlayer = new Player(game);
						newPlayer.setUser(existingUser);
						newPlayer.setColor(PlayerColor.values()[i]);
						existingUser.setPlayedGames(existingUser.getPlayedGames() + 1);
						Kingdom kingdom = new Kingdom(newPlayer);
						new Castle(0, 0, kingdom, newPlayer);
						existingUser.setPlayedGames(existingUser.getPlayedGames() + 1);
						game.addPlayerAt(newPlayer, i);
					} else {
						User newUser = new User(names.get(i), kingDomino);
						Player player = new Player(game);
						player.setUser(newUser);
						player.setColor(PlayerColor.values()[i]);
						newUser.setPlayedGames(newUser.getPlayedGames() + 1);
						Kingdom kingdom = new Kingdom(player);
						new Castle(0, 0, kingdom, player);
						game.addPlayerAt(player, i);
					}

				} else {
					throw new Exception("Either the username is already in use or has invalid characters");
				}
			}
		}
	}

	/**
	 * This method will track if one of the inputed names in the UI when starting a
	 * game is empty when selecting a two or three player game.If it is
	 * empty,Controller will ignore the empty string and pass to the next name
	 * 
	 * @author catherine van gheluwe
	 * @param names
	 * @return List<String>
	 */

	private static void specialMode(List<String> names) throws Exception {
		Kingdomino kingDomino = KingdominoApplication.getKingdomino();
		Game game = kingDomino.getCurrentGame();

		List<User> userList = kingDomino.getUsers();
		List<String> userNames = getListOfNames(kingDomino);

		List<String> temp = new ArrayList<String>();

		for (int i = 0; i < names.size(); i++) {
			if (names.get(i).length() == 0) {
				continue;
			}
				if (userList.isEmpty()) {
						User newUser = new User(names.get(i), kingDomino);
						Player player = new Player(game);
						player.setUser(newUser);
						player.setColor(PlayerColor.values()[i]);
						newUser.setPlayedGames(newUser.getPlayedGames() + 1);
						Kingdom kingdom = new Kingdom(player);
						game.addPlayerAt(player, i);
						new Castle(0, 0, kingdom, player);
						userNames.add(names.get(i));
					}
				 else {
					boolean goodName = specialCharacters(names.get(i));
					if (goodName == false) {
						if (userNames.contains(names.get(i))) {
							User existingUser = User.getWithName(names.get(i));
							Player newPlayer = new Player(game);
							newPlayer.setUser(existingUser);
							newPlayer.setColor(PlayerColor.values()[i]);
							existingUser.setPlayedGames(existingUser.getPlayedGames() + 1);
							Kingdom kingdom = new Kingdom(newPlayer);
							new Castle(0, 0, kingdom, newPlayer);
							existingUser.setPlayedGames(existingUser.getPlayedGames() + 1);
							game.addPlayerAt(newPlayer, i);
						} else {
							User newUser = new User(names.get(i), kingDomino);
							Player player = new Player(game);
							player.setUser(newUser);
							player.setColor(PlayerColor.values()[i]);
							newUser.setPlayedGames(newUser.getPlayedGames() + 1);
							Kingdom kingdom = new Kingdom(player);
							new Castle(0, 0, kingdom, player);
							game.addPlayerAt(player, i);
						}

					} else {
							throw new Exception("Either the username is already in use or has invalid characters");
					}
				}
			}
	}
	

	/**
	 * For a 2-3 player game 
	 * @author Catherine Van Gheluwe
	 * @param number of times we must remove dominos
	 * @return
	 */
	public static void specialModeDominoPile(int numRemove) {
		List<Domino> dominoList = new ArrayList<>();
		List<Domino> dominoInPileList = new ArrayList<>();

		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		dominoList = game.getAllDominos();

		for (int i = 0; i < dominoList.size(); i++) {
			Domino curDomino = dominoList.get(i);
			dominoInPileList.add(curDomino);

		}
		// Shuffling the pile a random number of times
		Random r1 = new Random();
		int numOfTimes = r1.nextInt(10); // upper limit bound 10

		for (int i = 0; i < numOfTimes + 1; i++) {
			Collections.shuffle(dominoInPileList);
			Random r2 = new Random();
			Collections.shuffle(dominoInPileList, r2);
		}

		List<Integer> pickedNumbers = new ArrayList<Integer>();

		for (int i = 0; i < numRemove; i++) {
			Random r2 = new Random();
			int rand = r2.nextInt(48);
			if (pickedNumbers.contains(rand)) {
				i = i - 1;
				continue;
			}
			pickedNumbers.add(rand);
			dominoInPileList.remove(game.getAllDomino(rand));
		}

		for (int i = 0; i < dominoInPileList.size(); i++) {
			game.addOrMoveAllDominoAt(dominoInPileList.get(i), i);
		}

		for (int i = 0; i < dominoInPileList.size() - 1; i++) { // the last domino will have a nextDomino == null
			Domino domino = dominoInPileList.get(i);
			domino.setNextDomino(dominoInPileList.get(i + 1));
		}

		// Getting the number of dominos on table based on number of players
		int dominosOnTable = 0;
		int numPlayers = game.getNumberOfPlayers();

		switch (numPlayers) { // setting domino counts for different # of players
		case 2:
			dominosOnTable = 4;
			break;
		case 3:
			dominosOnTable = 3;
			break;
		case 4:
			dominosOnTable = 4;
			break;
		default:
			break;
		}

		Draft draft = new Draft(DraftStatus.FaceDown, game);

		// Looping through dominos and setting corresponding status, first 4 dominos go
		// in the draft, rest go in pile
		Domino curDomino;
		for (int i = 0; i < game.getMaxPileSize(); i++) {
			if (i == 24 || i == 36) {
				break;
			}
			curDomino = dominoInPileList.get(i); // probably i but might be i+1
			if (i < dominosOnTable) {
				curDomino.setStatus(DominoStatus.InCurrentDraft);
				draft.addIdUnsortedDomino(curDomino);
			} else {
				curDomino.setStatus(DominoStatus.InPile);
			}
		}
		game.setCurrentDraft(draft);
		game.setTopDominoInPile(dominoList.get(dominosOnTable)); // set top domino to first domino after draft

	}


/**
 * Query method used to obain all the names in the game 
 * @param kingdomino
 * @return List<String> of names
 */
	public static List<String> getListOfNames(Kingdomino kingdomino) {

		List<User> userList = kingdomino.getUsers();
		List<String> userNames = new ArrayList<String>();

		for (User user : userList) {
			userNames.add(user.getName());
		}

		return userNames;

	}
/**
 * To check if any of the names have special characters
 * @author catherine van gheluwe
 * @param name
 * @return boolean if there is any special characters present
 */
	
	//used for starting a game
	public static boolean specialCharacters(String name) {
		Kingdomino kingdomino = KingdominoApplication.getKingdomino();
		
		List<String> userNames = getListOfNames(kingdomino);
		
		String specialChars = "~`!@#$%^&*()-_=+\\|[{]};:'\",<.>/?  ";
		String space = " ";
		boolean spacePresent = false;
		boolean specialCharacterPresent = false;
		
			for(int i  = 0; i < name.length(); i++) {
				char current = name.charAt(i);
				if (specialChars.contains(String.valueOf(current))) {
					specialCharacterPresent = true;
					return true;
				}else if(space.contains(String.valueOf(current))) {
					spacePresent = true;
				}
			}
			return false;
		
	}
/**check if there are any duplicated names while creating a new user
 * @author catherine van gheluwe
 * @param names
 * @return boolean
 */
	
	public static boolean duplicateName(String names) {
		Kingdomino kingdomino = KingdominoApplication.getKingdomino();
		
		List<String> userNames = getListOfNames(kingdomino);
		
	
			if(!userNames.isEmpty()) {
				if (userNames.contains(names.toLowerCase())) {
					return true;
				}
			}
			
			return false;
	}
	
	/**
	 * Called during create a new game to check if all names dont contain any special characters
	 * @author catherine van gheluwe
	 * @param name
	 * @return boolean
	 */
	private static boolean ValidUserName(String name) {
		Kingdomino kingdomino = KingdominoApplication.getKingdomino();
		
		
		boolean specialCharacter = specialCharacters(name);
		
		if(specialCharacter) {
			return true;
		}else {
			return false;
		}
	}	
	
/**
 * used during the creation of a user when create a user is initiated. 
 * During the creation, the application must ensure there is no duplicated names
 * or the desired name has special characters
 * @author catherine van gheluwe
 * @param name
 * @return boolean
 */
	private static boolean ValidCreation(String name) {
		Kingdomino kingdomino = KingdominoApplication.getKingdomino();
		
		boolean duplicate = duplicateName(name);
		boolean specialCharacter = specialCharacters(name);
		
		if(duplicate || specialCharacter) {
			return false;
		}else {
			return true;
		}

	}

}
