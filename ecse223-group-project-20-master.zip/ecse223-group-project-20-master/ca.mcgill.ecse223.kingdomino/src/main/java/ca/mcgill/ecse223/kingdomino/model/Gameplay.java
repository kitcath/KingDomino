/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.29.0.4181.a593105a9 modeling language!*/

package ca.mcgill.ecse223.kingdomino.model;
import ca.mcgill.ecse223.kingdomino.KingdominoApplication;
import ca.mcgill.ecse223.kingdomino.controller.*;
import ca.mcgill.ecse223.kingdomino.model.*;
import ca.mcgill.ecse223.kingdomino.model.Domino.DominoStatus;
import ca.mcgill.ecse223.kingdomino.model.Draft.DraftStatus;
import java.util.ArrayList;
import ca.mcgill.ecse223.kingdomino.model.DominoInKingdom.DirectionKind;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;

// line 4 "../../../../../Gameplay.ump"
public class Gameplay
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Gameplay State Machines
  public enum Gamestatus { Initializing, InGame, Finalizing }
  public enum GamestatusInitializing { Null, SettingGameOptions, CreatingFirstDraft, SelectingFirstDomino }
  public enum GamestatusInGame { Null, PlacingDomino, SelectingDomino, DiscardingDomino, CreatingNewDraft }
  public enum GamestatusFinalizing { Null, PlacingLastDomino, DiscardingLastDomino, CalculatingPlayerScore, RevealingFinalResult, GameOver }
  private Gamestatus gamestatus;
  private GamestatusInitializing gamestatusInitializing;
  private GamestatusInGame gamestatusInGame;
  private GamestatusFinalizing gamestatusFinalizing;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Gameplay()
  {
    setGamestatusInitializing(GamestatusInitializing.Null);
    setGamestatusInGame(GamestatusInGame.Null);
    setGamestatusFinalizing(GamestatusFinalizing.Null);
    setGamestatus(Gamestatus.Initializing);
  }

  //------------------------
  // INTERFACE
  //------------------------

  public String getGamestatusFullName()
  {
    String answer = gamestatus.toString();
    if (gamestatusInitializing != GamestatusInitializing.Null) { answer += "." + gamestatusInitializing.toString(); }
    if (gamestatusInGame != GamestatusInGame.Null) { answer += "." + gamestatusInGame.toString(); }
    if (gamestatusFinalizing != GamestatusFinalizing.Null) { answer += "." + gamestatusFinalizing.toString(); }
    return answer;
  }

  public Gamestatus getGamestatus()
  {
    return gamestatus;
  }

  public GamestatusInitializing getGamestatusInitializing()
  {
    return gamestatusInitializing;
  }

  public GamestatusInGame getGamestatusInGame()
  {
    return gamestatusInGame;
  }

  public GamestatusFinalizing getGamestatusFinalizing()
  {
    return gamestatusFinalizing;
  }

  public boolean buttonPressed()
  {
    boolean wasEventProcessed = false;
    
    GamestatusInitializing aGamestatusInitializing = gamestatusInitializing;
    switch (aGamestatusInitializing)
    {
      case SettingGameOptions:
        if (gameExists())
        {
          exitGamestatusInitializing();
          setGamestatusInitializing(GamestatusInitializing.CreatingFirstDraft);
          wasEventProcessed = true;
          break;
        }
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  public boolean draftReady()
  {
    boolean wasEventProcessed = false;
    
    GamestatusInitializing aGamestatusInitializing = gamestatusInitializing;
    GamestatusInGame aGamestatusInGame = gamestatusInGame;
    switch (aGamestatusInitializing)
    {
      case CreatingFirstDraft:
        exitGamestatusInitializing();
        // line 41 "../../../../../Gameplay.ump"
        orderAndRevealNextDraft(); generateInitialPlayerOrder();
        setGamestatusInitializing(GamestatusInitializing.SelectingFirstDomino);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    switch (aGamestatusInGame)
    {
      case CreatingNewDraft:
        exitGamestatusInGame();
        // line 86 "../../../../../Gameplay.ump"
        orderAndRevealNextDraft(); generateInitialPlayerOrder();
        setGamestatusInGame(GamestatusInGame.SelectingDomino);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  public boolean dominoSelected()
  {
    boolean wasEventProcessed = false;
    
    GamestatusInitializing aGamestatusInitializing = gamestatusInitializing;
    GamestatusInGame aGamestatusInGame = gamestatusInGame;
    switch (aGamestatusInitializing)
    {
      case SelectingFirstDomino:
        if (validateDominoSelection())
        {
          exitGamestatus();
        // line 47 "../../../../../Gameplay.ump"
          ;
          setGamestatusInGame(GamestatusInGame.PlacingDomino);
          wasEventProcessed = true;
          break;
        }
        break;
      default:
        // Other states do respond to this event
    }

    switch (aGamestatusInGame)
    {
      case SelectingDomino:
        if (validateDominoSelection()&&!(pileIsAlmostEmpty()))
        {
          exitGamestatusInGame();
          setGamestatusInGame(GamestatusInGame.PlacingDomino);
          wasEventProcessed = true;
          break;
        }
        if (isFinalTurnOfLastPlayerInGame()&&validateDominoSelection()&&pileIsAlmostEmpty())
        {
          exitGamestatus();
          setGamestatusFinalizing(GamestatusFinalizing.PlacingLastDomino);
          wasEventProcessed = true;
          break;
        }
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  public boolean dominoPlaced()
  {
    boolean wasEventProcessed = false;
    
    GamestatusInGame aGamestatusInGame = gamestatusInGame;
    GamestatusFinalizing aGamestatusFinalizing = gamestatusFinalizing;
    switch (aGamestatusInGame)
    {
      case PlacingDomino:
        if (!(pileIsAlmostEmpty()))
        {
          exitGamestatusInGame();
          setGamestatusInGame(GamestatusInGame.CreatingNewDraft);
          wasEventProcessed = true;
          break;
        }
        break;
      default:
        // Other states do respond to this event
    }

    switch (aGamestatusFinalizing)
    {
      case PlacingLastDomino:
        exitGamestatusFinalizing();
        setGamestatusFinalizing(GamestatusFinalizing.CalculatingPlayerScore);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  public boolean discardDomino()
  {
    boolean wasEventProcessed = false;
    
    GamestatusInGame aGamestatusInGame = gamestatusInGame;
    GamestatusFinalizing aGamestatusFinalizing = gamestatusFinalizing;
    switch (aGamestatusInGame)
    {
      case PlacingDomino:
        exitGamestatusInGame();
        setGamestatusInGame(GamestatusInGame.DiscardingDomino);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    switch (aGamestatusFinalizing)
    {
      case PlacingLastDomino:
        exitGamestatusFinalizing();
        setGamestatusFinalizing(GamestatusFinalizing.DiscardingLastDomino);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  public boolean dominoDiscarded()
  {
    boolean wasEventProcessed = false;
    
    GamestatusInGame aGamestatusInGame = gamestatusInGame;
    switch (aGamestatusInGame)
    {
      case DiscardingDomino:
        exitGamestatusInGame();
        setGamestatusInGame(GamestatusInGame.CreatingNewDraft);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  public boolean lastDominoDiscarded()
  {
    boolean wasEventProcessed = false;
    
    GamestatusFinalizing aGamestatusFinalizing = gamestatusFinalizing;
    switch (aGamestatusFinalizing)
    {
      case DiscardingLastDomino:
        exitGamestatusFinalizing();
        setGamestatusFinalizing(GamestatusFinalizing.CalculatingPlayerScore);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  public boolean playerScoreCalculated()
  {
    boolean wasEventProcessed = false;
    
    GamestatusFinalizing aGamestatusFinalizing = gamestatusFinalizing;
    switch (aGamestatusFinalizing)
    {
      case CalculatingPlayerScore:
        exitGamestatusFinalizing();
        // line 113 "../../../../../Gameplay.ump"
        Player player = KingdominoApplication.getKingdomino().getCurrentGame().getNextPlayer();
				try {
					calculatePlayerScore(player);
				} catch (InvalidInputException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
        setGamestatusFinalizing(GamestatusFinalizing.RevealingFinalResult);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  public boolean finalResultRevealed()
  {
    boolean wasEventProcessed = false;
    
    GamestatusFinalizing aGamestatusFinalizing = gamestatusFinalizing;
    switch (aGamestatusFinalizing)
    {
      case RevealingFinalResult:
        exitGamestatusFinalizing();
        // line 127 "../../../../../Gameplay.ump"
        Game game = KingdominoApplication.getKingdomino().getCurrentGame();
				Player player = KingdominoApplication.getKingdomino().getCurrentGame().getNextPlayer();
				try {
					Controller.calculatePropertyAttribute(player);
				} catch (InvalidInputException e) {
					e.printStackTrace();
				} 

				try {
					calculateRanking(game);
				} catch (InvalidInputException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
        setGamestatusFinalizing(GamestatusFinalizing.GameOver);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  private void exitGamestatus()
  {
    switch(gamestatus)
    {
      case Initializing:
        exitGamestatusInitializing();
        break;
      case InGame:
        exitGamestatusInGame();
        break;
      case Finalizing:
        exitGamestatusFinalizing();
        break;
    }
  }

  private void setGamestatus(Gamestatus aGamestatus)
  {
    gamestatus = aGamestatus;

    // entry actions and do activities
    switch(gamestatus)
    {
      case Initializing:
        if (gamestatusInitializing == GamestatusInitializing.Null) { setGamestatusInitializing(GamestatusInitializing.SettingGameOptions); }
        break;
      case InGame:
        if (gamestatusInGame == GamestatusInGame.Null) { setGamestatusInGame(GamestatusInGame.PlacingDomino); }
        break;
      case Finalizing:
        if (gamestatusFinalizing == GamestatusFinalizing.Null) { setGamestatusFinalizing(GamestatusFinalizing.PlacingLastDomino); }
        break;
    }
  }

  private void exitGamestatusInitializing()
  {
    switch(gamestatusInitializing)
    {
      case SettingGameOptions:
        setGamestatusInitializing(GamestatusInitializing.Null);
        break;
      case CreatingFirstDraft:
        setGamestatusInitializing(GamestatusInitializing.Null);
        break;
      case SelectingFirstDomino:
        setGamestatusInitializing(GamestatusInitializing.Null);
        break;
    }
  }

  private void setGamestatusInitializing(GamestatusInitializing aGamestatusInitializing)
  {
    gamestatusInitializing = aGamestatusInitializing;
    if (gamestatus != Gamestatus.Initializing && aGamestatusInitializing != GamestatusInitializing.Null) { setGamestatus(Gamestatus.Initializing); }

    // entry actions and do activities
    switch(gamestatusInitializing)
    {
      case CreatingFirstDraft:
        // line 35 "../../../../../Gameplay.ump"
        shuffleDominoPile(); 
			try {
				createNextDraft();
			} catch (Exception e) {
				e.printStackTrace();
			};  ;
        break;
    }
  }

  private void exitGamestatusInGame()
  {
    switch(gamestatusInGame)
    {
      case PlacingDomino:
        setGamestatusInGame(GamestatusInGame.Null);
        break;
      case SelectingDomino:
        setGamestatusInGame(GamestatusInGame.Null);
        break;
      case DiscardingDomino:
        setGamestatusInGame(GamestatusInGame.Null);
        break;
      case CreatingNewDraft:
        setGamestatusInGame(GamestatusInGame.Null);
        break;
    }
  }

  private void setGamestatusInGame(GamestatusInGame aGamestatusInGame)
  {
    gamestatusInGame = aGamestatusInGame;
    if (gamestatus != Gamestatus.InGame && aGamestatusInGame != GamestatusInGame.Null) { setGamestatus(Gamestatus.InGame); }

    // entry actions and do activities
    switch(gamestatusInGame)
    {
      case PlacingDomino:
        // line 56 "../../../../../Gameplay.ump"
        generateOrderForPlacingDomino();
        break;
      case DiscardingDomino:
        // line 68 "../../../../../Gameplay.ump"
        Game game = KingdominoApplication.getKingdomino().getCurrentGame();
				Player player = KingdominoApplication.getKingdomino().getCurrentGame().getNextPlayer();
				int playerTerritoriesSize = player.getKingdom().getTerritories().size();
				DominoInKingdom dom = (DominoInKingdom) player.getKingdom().getTerritories().get(playerTerritoriesSize-1); //takes the last selected domino which corresponds to the domino the player is trying to place now
				discardDomino(dom);
        break;
      case CreatingNewDraft:
        // line 81 "../../../../../Gameplay.ump"
        try {
				createNextDraft();
			} catch (Exception e) {
				e.printStackTrace();}
        break;
    }
  }

  private void exitGamestatusFinalizing()
  {
    switch(gamestatusFinalizing)
    {
      case PlacingLastDomino:
        setGamestatusFinalizing(GamestatusFinalizing.Null);
        break;
      case DiscardingLastDomino:
        setGamestatusFinalizing(GamestatusFinalizing.Null);
        break;
      case CalculatingPlayerScore:
        setGamestatusFinalizing(GamestatusFinalizing.Null);
        break;
      case RevealingFinalResult:
        setGamestatusFinalizing(GamestatusFinalizing.Null);
        break;
      case GameOver:
        setGamestatusFinalizing(GamestatusFinalizing.Null);
        break;
    }
  }

  private void setGamestatusFinalizing(GamestatusFinalizing aGamestatusFinalizing)
  {
    gamestatusFinalizing = aGamestatusFinalizing;
    if (gamestatus != Gamestatus.Finalizing && aGamestatusFinalizing != GamestatusFinalizing.Null) { setGamestatus(Gamestatus.Finalizing); }

    // entry actions and do activities
    switch(gamestatusFinalizing)
    {
      case DiscardingLastDomino:
        // line 99 "../../../../../Gameplay.ump"
        Game game = KingdominoApplication.getKingdomino().getCurrentGame();
				Player player = KingdominoApplication.getKingdomino().getCurrentGame().getNextPlayer();
				int playerTerritoriesSize = player.getKingdom().getTerritories().size();
				DominoInKingdom dom = (DominoInKingdom) player.getKingdom().getTerritories().get(playerTerritoriesSize-1); //takes the last selected domino which corresponds to the domino the player is trying to place now
				discardDomino(dom);
        break;
    }
  }

  public void delete()
  {}


  /**
   * Setter for test setup
   */
  // line 157 "../../../../../Gameplay.ump"
   public void setGameStatus(String status){
    switch (status) {
		case "CreatingFirstDraft":
			this.setGamestatus(Gamestatus.Initializing);
			this.setGamestatusInitializing(GamestatusInitializing.CreatingFirstDraft);
		case "SelectingFirstDomino":
			this.setGamestatus(Gamestatus.Initializing);
			this.setGamestatusInitializing(GamestatusInitializing.SelectingFirstDomino);

		case "PlacingDomino":
			this.setGamestatus(Gamestatus.InGame);
			this.setGamestatusInGame(GamestatusInGame.PlacingDomino);
		case "SelectingDomino":
			this.setGamestatus(Gamestatus.InGame);
			this.setGamestatusInGame(GamestatusInGame.SelectingDomino);
		case "DiscardingDomino":
			this.setGamestatus(Gamestatus.InGame);
			this.setGamestatusInGame(GamestatusInGame.DiscardingDomino);
		case "CreatingNewDraft":
			this.setGamestatus(Gamestatus.InGame);
			this.setGamestatusInGame(GamestatusInGame.CreatingNewDraft);

		case "CalculatingPlayerScore":
			this.setGamestatus(Gamestatus.Finalizing);
			this.setGamestatusFinalizing(GamestatusFinalizing.CalculatingPlayerScore);
		case "RevealingFinalResult":
			this.setGamestatus(Gamestatus.Finalizing);
			this.setGamestatusFinalizing(GamestatusFinalizing.RevealingFinalResult);
		case "DiscardingLastDomino":
			this.setGamestatus(Gamestatus.Finalizing);
			this.setGamestatusFinalizing(GamestatusFinalizing.DiscardingLastDomino);
		case "PlacingLastDomino":
			this.setGamestatus(Gamestatus.Finalizing);
			this.setGamestatusFinalizing(GamestatusFinalizing.PlacingLastDomino);
		case "GameOver":
			this.setGamestatus(Gamestatus.Finalizing);
			this.setGamestatusFinalizing(GamestatusFinalizing.GameOver);
		default:
			throw new RuntimeException("Invalid gamestatus string was provided: " + status);
		}
  }


  /**
   * Guards
   */
  // line 204 "../../../../../Gameplay.ump"
   public static  boolean gameExists(){
    Kingdomino kingdomino = KingdominoApplication.getKingdomino();
		Game game = kingdomino.getCurrentGame();
		return (game!=null);
  }

  // line 211 "../../../../../Gameplay.ump"
   public static  boolean pileIsEmpty(){
    // Contributors: Ryad

		Kingdomino kingdomino = KingdominoApplication.getKingdomino();
		Game game = kingdomino.getCurrentGame();
		return game.getPileIsEmpty();
  }

  // line 219 "../../../../../Gameplay.ump"
   public static  boolean pileIsAlmostEmpty(){
    // Contributors: Ryad
		Kingdomino kingdomino = KingdominoApplication.getKingdomino();
		Game game = kingdomino.getCurrentGame();
		boolean pileIsAlmostEmpty = false;

		if ((game.getNumberOfPlayers() == 3 | game.getNumberOfPlayers() == 4) && (game.numberOfAllDrafts() == 11)) 
			pileIsAlmostEmpty = true;

		if ((game.getNumberOfPlayers() == 2) && (game.numberOfAllDrafts() == 5))
				pileIsAlmostEmpty = true; 
				
		return pileIsAlmostEmpty;
  }


  /**
   * methods for making a domino selection:
   */
  // line 235 "../../../../../Gameplay.ump"
   public void makeDominoSelection(Player player, Domino domino){
    Draft draft = KingdominoApplication.getKingdomino().getCurrentGame().getNextDraft();
		boolean available = true;
		
		if(draft.getSelections().size() > 0) {
			for(int i = 0; i < draft.getSelections().size(); i++) {
				if(draft.getSelections().get(i).getDomino().getId() == domino.getId()) available = false;
			}
		}
		
		if(available) {
			DominoSelection selected = new DominoSelection(player, domino, draft);
			player.setDominoSelection(selected);
			draft.addSelection(selected);
		}
  }

  // line 253 "../../../../../Gameplay.ump"
   public boolean validateDominoSelection(){
    Player player = KingdominoApplication.getKingdomino().getCurrentGame().getNextPlayer();
		boolean valid = false;
		if(player.getDominoSelection() != null) {
			valid = true;
		}
		return valid;
  }

  // line 263 "../../../../../Gameplay.ump"
   public boolean isCurrentPlayerTheLastInTurn(){
    // Contributors: Vadim, ...
		Kingdomino kingdomino = KingdominoApplication.getKingdomino();
		Game game = kingdomino.getCurrentGame();
		boolean isCurrentPlayerLastInTurn = false;
		
		// if there is only one domino left to be selected in the next draft
		
		try {
		if (game.getNextDraft() != null) {
			if (game.getNextDraft().getSelections().size() == game.getNumberOfPlayers() - 1 || (game.getCurrentDraft().getIdSortedDominos().size() == 1)) {
				isCurrentPlayerLastInTurn = true;
				System.out.println("This is the last turn of the current draft");
			} else {
				isCurrentPlayerLastInTurn = false;
			}
		}		
		} catch(NullPointerException e) {}
		return isCurrentPlayerLastInTurn;
  }

  // line 285 "../../../../../Gameplay.ump"
   public boolean isCurrentTurnTheLastInGame(){
    // Contributors: Vadim, ...
		boolean isCurrentTurnLastInGame = false;

		// if next player's domino selection is unexistent, then the 
		// current turn is the last of the game for the given player

		try {

			Kingdomino kingdomino = KingdominoApplication.getKingdomino();
			Game game = kingdomino.getCurrentGame();

			if (!game.hasNextDraft()) { 
				isCurrentTurnLastInGame = true;
			}
			} catch (NullPointerException e) {
				isCurrentTurnLastInGame = false; 
		}
		return isCurrentTurnLastInGame;
  }

  // line 306 "../../../../../Gameplay.ump"
   public boolean isFinalTurnOfLastPlayerInGame(){
    // Contributors: Vadim

		Kingdomino kingdomino = KingdominoApplication.getKingdomino();
		Game game = kingdomino.getCurrentGame();

		boolean isFinalTurnOfLastPlayerInGame = false;

		// if next player is null, then the 
		// current turn is the last of the game (when the current player is the completely the last one to place his/her domino, the nextPlayer is null) 
		try {
			Player nextPlayer = game.getNextPlayer();
			DominoSelection nextPlayersSelection = nextPlayer.getDominoSelection();

			if (nextPlayersSelection == null) {
				isFinalTurnOfLastPlayerInGame = true;
			}
		} catch (NullPointerException e) {
			isFinalTurnOfLastPlayerInGame = true;
		}
		return isFinalTurnOfLastPlayerInGame;
  }


  /**
   * You may need to add more guards here
   * Actions
   * 
   * F#5: Shuffle domino pile: As a player, I want to play have a randomly
   * shuffled pile of dominos so that every game becomes unique
   * 
   * @author Michael Buchar
   * @param no parameters
   * 
   */
  // line 344 "../../../../../Gameplay.ump"
   public static  List<Player> generateInitialPlayerOrder(){
    return Controller.generateInitialPlayerOrder();
  }

  // line 348 "../../../../../Gameplay.ump"
   public static  void shuffleDominoPile(){
    Controller.shuffleDominoPile();
  }

  // line 353 "../../../../../Gameplay.ump"
   public static  void createNextDraft() throws Exception{
    Controller.createNextDraft();
  }

  // line 358 "../../../../../Gameplay.ump"
   public static  void generateOrderForPlacingDomino(){
    Controller.generateOrderForPlacingDomino();
  }


  /**
   * 
   * F#9 Orders the next draft of dominos using selection sort and reveals the draft
   * @author Niilo Vuokila
   * @param The current game
   */
  // line 367 "../../../../../Gameplay.ump"
   public static  void orderAndRevealNextDraft(){
    Controller.orderAndRevealNextDraft();
  }


  /**
   * 
   * F#22: Calculate player score: As a player, I want the Kingdomino app to automatically calculate the score
   * for each of my property based upon the size of that property and the number of crowns. The total score
   * of the player should also include the bonus score.
   * 
   * @author Alexandra Gafencu
   * @throws InvalidInputException
   * @returns the inputted player's score
   */
  // line 383 "../../../../../Gameplay.ump"
   public static  int calculatePlayerScore(Player player) throws InvalidInputException{
    return Controller.calculatePlayerScore(player);
  }


  /**
   * 
   * F#23: Calculate ranking: As a player, I want the Kingdomino app to
   * automatically calculate the ranking in order to know the winner of a finished
   * 
   * 
   * @author Michael Buchar
   * @param none
   * @throws InvalidInputException 
   * @returns ranking of players in descending order (the winner is first in the list, the loser last, etc)
   * 
   */
  // line 400 "../../../../../Gameplay.ump"
   public static  List<Player> calculateRanking(Game game) throws InvalidInputException{
    return Controller.calculateRanking(game);
  }

  // line 430 "../../../../../Gameplay.ump"
   public static  void discardDomino(DominoInKingdom domino){
    /* F#18: Discard domino: As a player, I wish to discard a domino if it cannot be placed to my kingdom in a
		 * valid way
		 * @author Ryad Ammar
		 */

		/*
		 * THIS FEATURE REQUIRES: - the feature(s) F14, F15, F16, F17
		 */

		/*
		 * This method scans the 10 cells surrounding the castle of the kingdom and
		 * tries to place the domino on each cell. If there is an available cell for the
		 * domino, the domino is "ErroneouslyPreplaced". Otherwise, the domino is
		 * "Discarded".
		 */

		Player player = domino.getKingdom().getPlayer();

		HashMap<Integer, DirectionKind> direction = new HashMap<Integer, DirectionKind>();
		direction.put(0, DirectionKind.Up);
		direction.put(1, DirectionKind.Down);
		direction.put(2, DirectionKind.Left);
		direction.put(3, DirectionKind.Right);

		for (Integer i = -4; i <= 4; i++) {
			domino.setX(i);

			for (Integer j = -4; j <= 4; j++) {
				domino.setY(j);

				for (Integer k = 0; k <= 1; k++) {
					domino.setDirection(direction.get(k));

					if (Controller.getDominoCondition(domino, player)) {
						domino.getDomino().setStatus(DominoStatus.ErroneouslyPreplaced);
						return;
					}

				}
			}
		}

		domino.getDomino().setStatus(DominoStatus.Discarded);
		domino.delete();
		return;
  }
  
  //------------------------
  // DEVELOPER CODE - PROVIDED AS-IS
  //------------------------
  
  // line 405 "../../../../../Gameplay.ump"
  public static HashMap<Player, Integer> sortByValue (HashMap<Player, Integer> hashmap) 
  {
    // Create a list from elements of HashMap 
		List<Entry<Player, Integer>> listOfEntries = 
				new LinkedList<Map.Entry<Player, Integer>>(hashmap.entrySet()); 

		// Sort the list 
		Collections.sort(listOfEntries, new Comparator<Map.Entry<Player, Integer>>() { 
			public int compare(Map.Entry<Player, Integer> entry1,  
					Map.Entry<Player, Integer> entry2) 
			{ 
				return ((entry1.getValue()).compareTo(entry2.getValue()) * (-1)); 
			} 
		}); 

		// put data from sorted list to hashmap  
		HashMap<Player, Integer> hashmap2 = new LinkedHashMap<Player, Integer>(); 
		for (Map.Entry<Player, Integer> entries : listOfEntries) { 
			hashmap2.put(entries.getKey(), entries.getValue()); 
		} 
		return hashmap2;
  }

  
}