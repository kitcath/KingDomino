package ca.mcgill.ecse223.kingdomino.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;

import javax.swing.DefaultComboBoxModel;
import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.GroupLayout.Alignment;
import javax.swing.border.LineBorder;

import ca.mcgill.ecse223.kingdomino.KingdominoApplication;
import ca.mcgill.ecse223.kingdomino.controller.Controller;
import ca.mcgill.ecse223.kingdomino.controller.Controller.RotationKind;
import ca.mcgill.ecse223.kingdomino.controller.InvalidInputException;
import ca.mcgill.ecse223.kingdomino.model.Castle;
import ca.mcgill.ecse223.kingdomino.model.Domino;
import ca.mcgill.ecse223.kingdomino.model.DominoInKingdom;
import ca.mcgill.ecse223.kingdomino.model.DominoSelection;
import ca.mcgill.ecse223.kingdomino.model.Draft;
import ca.mcgill.ecse223.kingdomino.model.DominoInKingdom.DirectionKind;
import ca.mcgill.ecse223.kingdomino.model.Draft.DraftStatus;
import ca.mcgill.ecse223.kingdomino.model.Game;
import ca.mcgill.ecse223.kingdomino.model.Kingdom;
import ca.mcgill.ecse223.kingdomino.model.KingdomTerritory;
import ca.mcgill.ecse223.kingdomino.model.Kingdomino;
import ca.mcgill.ecse223.kingdomino.model.Player;
import ca.mcgill.ecse223.kingdomino.model.Player.PlayerColor;
import ca.mcgill.ecse223.kingdomino.model.TerrainType;
import ca.mcgill.ecse223.kingdomino.model.Domino.DominoStatus;

import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFileChooser;

import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.awt.event.ActionEvent;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.SwingConstants;
import javax.swing.JToolBar;
import javax.swing.UIManager;
import java.awt.Dimension;
import java.awt.Rectangle;
import javax.swing.JTextField;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.SystemColor;

public class AGameplay extends JFrame {
	/**
	 * This class is essentially where the users play the game. 
	 * @author Alexandra Gafencu, Niilo  Vuokila, Vadim Tuchila, Ryad Ammar && Catherine Van Gheluwe
	 */

	private JFrame frame;
	private static JPanel contentPane;
	public static JComboBox browseByTerrainTypeComboBox;
	private JTextField browseDominoByIDTextField;
	private static JLabel[] draftComp;
	static JLabel castle1;
	static JLabel castle2;
	static JLabel castle3;
	static JLabel castle4;

	private final Color[] COLOR_ARRAY= {Color.decode("#FFFACD"), Color.decode("#593E1A")};

	
	

	/**
	 * @author Ryad Ammar
	 * Launches application
	 */
	public static void AGameplay()  
	{
		EventQueue.invokeLater(new Runnable() 
		{
			public void run() 
			{
				try 
				{
					AGameplay frame = new AGameplay();
					frame.setVisible(true);
				} catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		});
	}



	/**
	 * Create the frame.
	 */
	public AGameplay() 
	{

		initComponents();
		createEvents();


	}
	
	
	
	class DominoLabel extends JLabel{
		
		DominoLabel(){
			
			setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/menugreencastle.PNG")).getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH)));			
			setVerticalTextPosition(SwingConstants.BOTTOM);
			setHorizontalTextPosition(SwingConstants.CENTER);

		}
		
	}
	
	
 
	
	/**
	 * 
	 * @author Alexandra Gafencu
	 *
	 */
	class KingViewPanel extends JPanel { 
		public static final int LENGTH = 9;
		private final Color[] COLOR_ARRAY= {Color.decode("#FFFACD"), Color.decode("#593E1A"), Color.decode("#FFFFFF")};
		public KingViewPanel() {
			
			
			setLayout(new GridLayout(LENGTH, LENGTH));

	
			for(int i=0;i<9;i++) {
								
				for(int j=0;j<9;j++) {

					add(new TileView());
				}
			}
			
		}
		
		/**
		 * Generic setting a picture
		 * @author Alexandra Gafencu
		 * @param x
		 * @param y
		 * @param terraintype
		 * @param numberOfCrowns
		 */
		public void setLabel (int x, int y, TerrainType terraintype, int numberOfCrowns) {
			
			int index= 4*LENGTH + 4 - y * LENGTH + x;
			
			TileView component=(TileView) this.getComponent(index);
			
			//seticon
			component.setTypeView(terraintype, numberOfCrowns);
			
		}

		/**
		 * Sets the castle picture
		 * @param x
		 * @param y
		 * @param color
		 */
		public void setCastleLabel(int x, int y, PlayerColor color) {
			int index= 4*LENGTH + 4 - y * LENGTH + x;
			TileView component=(TileView) this.getComponent(index);
			component.setCastleView(color);
		}

		/**
		 * Sets the picture for the right side of the domino
		 * @param x
		 * @param y
		 * @param direction
		 * @param rightTile
		 * @param rightCrown
		 */
		public void setRightLabel(int x, int y, DirectionKind direction, TerrainType rightTile, int rightCrown) {
			int x2 = x;
			int y2 = y;

			switch (direction) {
			case Up:
				y2++;
				break;
			case Down:
				y2--;
				break;
			case Left:
				x2--;
				break;
			case Right:
				x2++;
				break;
			}
			setLabel(x2, y2, rightTile, rightCrown);
		}


		public void clean() {
			for(int i=0;i<LENGTH;i++) {
				for(int j=0;j<LENGTH;j++) {
					TileView component=(TileView) this.getComponent(j*LENGTH +i);
					component.SetEmpty();
				}
			}
						
		}
		
		
	}
	
	/**
	 * Class for the tiles
	 * @author Alexandra Gafencu
	 *
	 */
	class TileView extends JLabel{
		
		TileView(Color color){
			setPreferredSize(new Dimension(30,30));
			setOpaque(true);
			setBackground(color);
		}
		
		TileView(String url){
			setPreferredSize(new Dimension(30,30));
			//setOpaque(true);
			setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource(url)).getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH)));			
		}

		public TileView() {
			SetEmpty();
		}
		

		public void SetEmpty() {

			setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/emptygrid.png")).getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH)));
		}

		public void setCastleView(PlayerColor color) {

			String url="";
			
			switch(color) {
				case Pink:
					url="/viewresources/pinkCastle.png";
					break;
				case Yellow:
					url="/viewresources/yellowCastle.png";
					break;
				case Blue:
					url="/viewresources/blueCastle.png";
					break;
				case Green:
					url="/viewresources/greenCastle.png";
					break;	
			
			}
			
			
			setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource(url)).getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH)));			
			
		}

		public void setTypeView(TerrainType terraintype, int numberOfCrowns) {

			String url="";
			
			switch(terraintype) {
			
			case WheatField:
				switch(numberOfCrowns) {
				case 0:
					url="/viewresources/WheatField.png";
					break;	
				case 1:
					url="/viewresources/WheatField-1c.png";
					break;	
				case 2:
					url="/viewresources/WheatField-2c.png";
					break;		
				case 3:
					url="/viewresources/WheatField-3c.png";
					break;		
				}
				break;
			
			case Forest: 
				switch(numberOfCrowns) {
				case 0:
					url="/viewresources/Forest.png";
					break;	
				case 1:
					url="/viewresources/Forest-1c.png";
					break;	
				case 2:
					url="/viewresources/Forest-2c.png";
					break;		
				case 3:
					url="/viewresources/Forest-3c.png";
					break;		
				}
				break;

			case Lake:
				switch(numberOfCrowns) {
				case 0:
					url="/viewresources/Lake.png";
					break;	
				case 1:
					url="/viewresources/Lake-1c.png";
					break;	
				case 2:
					url="/viewresources/Lake-2c.png";
					break;		
				case 3:
					url="/viewresources/Lake-3c.png";
					break;		
				}
				break;

			case Grass:
				switch(numberOfCrowns) {
				case 0:
					url="/viewresources/Grass.png";
					break;	
				case 1:
					url="/viewresources/grass-1c.png";
					break;	
				case 2:
					url="/viewresources/grass-2c.png";
					break;		
				case 3:
					url="/viewresources/grass-3c.png";
					break;		
				}
				break;
			case Swamp:
				switch(numberOfCrowns) {
				case 0:
					url="/viewresources/Swamp.png";
					break;	
				case 1:
					url="/viewresources/Swamp-1c.png";
					break;	
				case 2:
					url="/viewresources/Swamp-2c.png";
					break;		
				case 3:
					url="/viewresources/Swamp-3c.png";
					break;		
				}
				break;
			
			case Mountain:
				switch(numberOfCrowns) {
				case 0:
					url="/viewresources/Mountain.png";
					break;	
				case 1:
					url="/viewresources/Mountain-1c.png";
					break;	
				case 2:
					url="/viewresources/Mountain-2c.png";
					break;		
				case 3:
					url="/viewresources/Mountain-3c.png";
					break;		
				}
				break;
			
			}
					
			setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource(url)).getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH)));			

		}

	}



	private void tryStartGame() {
	
		Kingdomino kd = KingdominoApplication.getKingdomino();
		Game game = kd.getCurrentGame();

		int count = 0;
		List<Player> players = game.getPlayers();
		for (Player p : players) {
			if( p.hasDominoSelection())
				count ++;
		}
	
		if(count == 4) {
			repaintGame();
		}
	}

	/**
	 * @author Alexandra Gafencu
	 * @return the DominoInKingdom currently selected
	 */
	public DominoInKingdom GetCrtSelection() {

		Kingdomino kd = KingdominoApplication.getKingdomino();
		Game game = kd.getCurrentGame();

		Player p = game.getNextPlayer();
		if (p != null) {
			DominoSelection ds = p.getDominoSelection();
			if (ds != null) {
				return getDominoInKingdomByID(ds.getDomino().getId(), p);

			}
		}
		return null;
	}
	
	public void moveLeft() {

		DominoInKingdom domino = GetCrtSelection();
		if (domino != null) {
			Controller.moveCurrentDomino(domino, DirectionKind.Left);
		}
		repaintGame();
		this.repaint();
	}

	public void moveRight() {
		DominoInKingdom domino = GetCrtSelection();
		if (domino != null) {
			Controller.moveCurrentDomino(domino, DirectionKind.Right);
		}
		repaintGame();
		this.repaint();
	}

	public void moveUp() {
		DominoInKingdom domino = GetCrtSelection();
		if (domino != null) {
			Controller.moveCurrentDomino(domino, DirectionKind.Up);
		}
		repaintGame();
		this.repaint();

	}

	public void moveDown() {
		DominoInKingdom domino = GetCrtSelection();
		if (domino != null) {
			Controller.moveCurrentDomino(domino, DirectionKind.Down);
		}
		repaintGame();
		this.repaint();

	}
	
	private void rotateCounterClockwise() {

		DominoInKingdom domino = GetCrtSelection();
		if (domino != null) {
			Controller.rotateCurrentDomino(domino, RotationKind.counterclockwise);
		}
		repaintGame();
		this.repaint();
	}

	private void rotateClockwise() {
		DominoInKingdom domino = GetCrtSelection();
		if (domino != null) {
			Controller.rotateCurrentDomino(domino, RotationKind.clockwise);
		}
		repaintGame();
		this.repaint();
	}

	/**
	 * @author Alexandra Gafencu
	 * Redraws the game depending on the movement and the dominoes placed
	 */
	private void repaintGame() {

		Kingdomino kd = KingdominoApplication.getKingdomino();
		Game game = kd.getCurrentGame();
		List<Player> players = game.getPlayers();

		for (Player p : players) {

			KingViewPanel pKingdom = mapPlayerToPanel.get(p.getColor());
			if (pKingdom != null) {
				int crtSelectionId = -1;
				boolean bFound = false;
				DominoSelection ds = p.getDominoSelection();
				if (ds != null) {
					crtSelectionId = ds.getDomino().getId();
				}

				pKingdom.clean();

				List<KingdomTerritory> territories = p.getKingdom().getTerritories();
				for (KingdomTerritory kt : territories) {

					if (kt instanceof Castle) {
						pKingdom.setCastleLabel(kt.getX(), kt.getY(), p.getColor());

					} else {
						
						DominoInKingdom d = (DominoInKingdom) kt;
						
						if(d.getDomino().getStatus()==DominoStatus.Discarded) {
							continue;
						}
						
						pKingdom.setLabel(kt.getX(), kt.getY(), d.getDomino().getLeftTile(),
								d.getDomino().getLeftCrown());
						pKingdom.setRightLabel(kt.getX(), kt.getY(), d.getDirection(), d.getDomino().getRightTile(),
								d.getDomino().getRightCrown());

						if (crtSelectionId == d.getDomino().getId()) {
							bFound = true;
						}

					}

				}
				if (!bFound) {
					if (ds != null) {
						DominoInKingdom kt = Controller.preplaceCurrentDomino(ds.getPlayer(), ds.getDomino());
						
						if(kt!=null&&kt.getDomino()!=null) {

							//if(this.getDominoInKingdomByID(kt.getDomino().getId(), p)!=null) {
							
								pKingdom.setLabel(kt.getX(), kt.getY(), kt.getDomino().getLeftTile(),
										kt.getDomino().getLeftCrown());
								pKingdom.setRightLabel(kt.getX(), kt.getY(), kt.getDirection(), kt.getDomino().getRightTile(),
										kt.getDomino().getRightCrown());
							//}
						}
					}
				}

			}

		}
	}



	private Map<PlayerColor, KingViewPanel> mapPlayerToPanel = new HashMap<>();

	/////////////////////////////////////////////////////////////////////////////////////////////
	// This method contains all of the code for creating and initializing components
	/////////////////////////////////////////////////////////////////////////////////////////////
	private void initComponents() {
		setTitle("Kingdomino");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1355, 750);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(224, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		Kingdomino kd = KingdominoApplication.getKingdomino();
		Game game = kd.getCurrentGame();
		List<Player> players = game.getPlayers();



		/**
		 * @author catherine van gheluwe 
		 * the exit buttons ensures that the users saves a game before leaving the application
		 */
		JButton btnExit = new JButton("EXIT");
		btnExit.setFont(new Font("Berlin Sans FB", Font.PLAIN, 12));
		btnExit.setForeground(new Color(216, 191, 216));
		btnExit.setBackground(new Color(255, 0, 255));
		btnExit.setBackground(new Color(64, 64, 64));
		btnExit.setBounds(5, 5, 73, 25);
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object[] options = {"Save", "Exit","Cancel"};
				
				int n = JOptionPane.showOptionDialog(contentPane, "Would you like to save before leaving?","Exit",JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE,null,options,options[0]);
				
				if (n == 0) {
					try {
						Controller.save(KingdominoApplication.getKingdomino());
						JFileChooser fileChooser = new JFileChooser();
						fileChooser.setDialogTitle("Specify a file to save");
						int userSelection = fileChooser.showSaveDialog(contentPane);
						
						if (userSelection == JFileChooser.APPROVE_OPTION) {
							File fileToSave = fileChooser.getSelectedFile();
							JOptionPane.showMessageDialog(contentPane,"Save as file path : " + fileToSave.getAbsolutePath(), "save confirmation",JOptionPane.INFORMATION_MESSAGE);
						}
					} catch (InvalidInputException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				} else if( n ==1) {
					System.exit(0);
				}else {
					return;
				}
			}
		});

		/**
		 * @author Catherine Van Gheluwe 
		 * the save game calls the persistence to save all the values of the game 
		 */
		JButton btnSave = new JButton("SAVE GAME");
		btnSave.setFont(new Font("Berlin Sans FB", Font.PLAIN, 12));
		btnSave.setBackground(new Color(245, 222, 179));
		btnSave.setForeground(new Color(0, 0, 0));
		btnSave.setBounds(223, 5, 128, 25);
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					
					Controller.save(KingdominoApplication.getKingdomino());
					JFileChooser fileChooser = new JFileChooser();
					fileChooser.setDialogTitle("Specify a file to save");
					int userSelection = fileChooser.showSaveDialog(contentPane);
					
					if (userSelection == JFileChooser.APPROVE_OPTION) {
						File fileToSave = fileChooser.getSelectedFile();
						JOptionPane.showMessageDialog(contentPane,"Save as file path : " + fileToSave.getAbsolutePath(), "save confirmation",JOptionPane.INFORMATION_MESSAGE);
					
					}
				} catch (InvalidInputException e1) {

				}
			}
		});

		JButton browseAllDominoesButton = new JButton("BROWSE ALL");
		browseAllDominoesButton.setFont(new Font("Berlin Sans FB", Font.PLAIN, 12));
		browseAllDominoesButton.setBackground(new Color(153, 255, 51));
		browseAllDominoesButton.setBounds(864, 32, 119, 23);
		browseAllDominoesButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BrowsingAllDominoesPage browseAll = new BrowsingAllDominoesPage();
				browseAll.browsingAllDominoesPage(); //opens a window with all dominoes in the game no matter the status

			}
		});

		browseByTerrainTypeComboBox = new JComboBox();
		browseByTerrainTypeComboBox.setFont(new Font("Berlin Sans FB", Font.PLAIN, 12));
		browseByTerrainTypeComboBox.setBounds(995, 32, 148, 22);
		browseByTerrainTypeComboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String error = "";
				String selectedTerrainType = (String) AGameplay.browseByTerrainTypeComboBox.getItemAt(AGameplay.browseByTerrainTypeComboBox.getSelectedIndex());
				int selectedIndex = AGameplay.browseByTerrainTypeComboBox.getSelectedIndex();

				if (selectedTerrainType.length() < 0)
					error = "Terrain type needs to be selected to browse dominoes by terrain type!";

				if (error.length() == 0) {
					// call the controller
					switch (selectedIndex) {
					case 1 : //"Wheat Field":
						JOptionPane.showMessageDialog(null, null , "Browsing by Terrain Type : Wheat Field", 
								JOptionPane.PLAIN_MESSAGE, new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/WheatFields.jpg")).getImage().getScaledInstance(1300, 600 , Image.SCALE_SMOOTH)));
						break;
					case 2 : //"Forest":
						JOptionPane.showMessageDialog(null, null , "Browsing by Terrain Type : Forest", 
								JOptionPane.PLAIN_MESSAGE, new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/Forests.jpg")).getImage().getScaledInstance(1300, 450, Image.SCALE_SMOOTH)));
						break;
					case 3 : //"Lake":
						JOptionPane.showMessageDialog(null, null , "Browsing by Terrain Type : Lake", 
								JOptionPane.PLAIN_MESSAGE, new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/Lakes.jpg")).getImage().getScaledInstance(1300, 500, Image.SCALE_SMOOTH)));
						break;
					case 4 : //"Grass":
						JOptionPane.showMessageDialog(null, null , "Browsing by Terrain Type : Grass", 
								JOptionPane.PLAIN_MESSAGE, new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/Grass.jpg")).getImage().getScaledInstance(1300, 600, Image.SCALE_SMOOTH)));
						break;
					case 5 : //"Swamp":
						JOptionPane.showMessageDialog(null, null , "Browsing by Terrain Type : Swamp", 
								JOptionPane.PLAIN_MESSAGE, new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/Swamps.jpg")).getImage().getScaledInstance(900, 400, Image.SCALE_SMOOTH)));
						break;
					case 6 : //"Mountain":
						JOptionPane.showMessageDialog(null, null , "Browsing by Terrain Type : Mountain", 
								JOptionPane.PLAIN_MESSAGE, new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/Mountains.jpg")).getImage().getScaledInstance(900, 400, Image.SCALE_SMOOTH)));
						break;
					default:
						break;
					}
				}
			}
		});
		
		browseByTerrainTypeComboBox.setBackground(new Color(102, 255, 153));
		browseByTerrainTypeComboBox.setModel(new DefaultComboBoxModel(new String[] {"Browse By Terrain", "Wheat Field", "Forest", "Lake", "Grass", "Swamp", "Mountain"}));
		contentPane.setLayout(null);
		
		int idx = 0;
		for(Player p : players) {
			
			//test
			//	testMove(game,p,34+idx);
			//endtest
			
			JPanel kingdomContainer = new JPanel();
			switch(idx) {
			case 0:
				kingdomContainer.setBounds(27, 53, 300, 300);
				break;
			case 1:
				kingdomContainer.setBounds(337, 53, 300, 300);
				break;
			case 2:
				kingdomContainer.setBounds(27, 364, 300, 300);
				break;
			case 3:
				kingdomContainer.setBounds(337, 364, 300, 300);
				break;
			}

			
			Color color = getColor(p.getColor());
			kingdomContainer.setBorder(new LineBorder(color, 2));
			contentPane.add(kingdomContainer);
			
			KingViewPanel pKingdom = new KingViewPanel();
			switch(idx) {
			case 0:
				pKingdom.setBounds(27, 53, 300, 300);
				break;
			case 1:
				pKingdom.setBounds(337, 53, 300, 300);
				break;
			case 2:
				pKingdom.setBounds(27, 364, 300, 300);
				break;
			case 3:
				pKingdom.setBounds(337, 364, 300, 300);
				break;
			}
		
			kingdomContainer.add(pKingdom);
			contentPane.add(kingdomContainer);
			
			mapPlayerToPanel.put(p.getColor(), pKingdom);
			
			List<KingdomTerritory> territories = p.getKingdom().getTerritories();
			for(KingdomTerritory kt : territories) {
				
				if( kt instanceof Castle) {
					pKingdom.setCastleLabel(kt.getX(), kt.getY(), p.getColor() ); 
					
				} else {
					
					DominoInKingdom d = (DominoInKingdom) kt;
					pKingdom.setLabel(kt.getX(), kt.getY(), d.getDomino().getLeftTile(), d.getDomino().getLeftCrown());
					pKingdom.setRightLabel(kt.getX(), kt.getY(), d.getDirection(), d.getDomino().getRightTile(), d.getDomino().getRightCrown());
				}
				
			}
			
			idx++;
		
		}
		
		setFocusable(true);
		

		setFocusTraversalKeysEnabled(false);

		contentPane.add(btnExit);
		contentPane.add(btnSave);
		contentPane.add(browseAllDominoesButton);
		contentPane.add(browseByTerrainTypeComboBox);

		JButton btnMainmenu = new JButton("MAIN MENU");
		btnMainmenu.setFont(new Font("Berlin Sans FB", Font.PLAIN, 12));
		btnMainmenu.setBackground(new Color(230, 230, 250));
		btnMainmenu.setForeground(new Color(0, 0, 0));
		btnMainmenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainMenu home = new MainMenu();
				home.setVisible(true);
				dispose();
			}
		});
		btnMainmenu.setBounds(88, 5, 125, 25);
		contentPane.add(btnMainmenu);



		browseDominoByIDTextField = new JTextField();
		browseDominoByIDTextField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String error = "";
				int selectedID = Integer.parseInt(browseDominoByIDTextField.getText());

				if (selectedID <= 0 || selectedID > 48) {
					JOptionPane.showMessageDialog(null, "Choose a domino between 1 and 48!");
				}
				if (error.length() == 0) {
					JOptionPane.showMessageDialog(null, null , "Browsing by Terrain Type : Wheat Field", 
							JOptionPane.PLAIN_MESSAGE, new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/domino" + selectedID + ".png")).getImage().getScaledInstance(300, 150 , Image.SCALE_SMOOTH)));
				
				}

			}

	});
		browseDominoByIDTextField.setBackground(new Color(255, 153, 102));
		browseDominoByIDTextField.setFont(new Font("Berlin Sans FB", Font.PLAIN, 12));
		browseDominoByIDTextField.setText("SEARCH DOMINO BY ID\r\n");
		browseDominoByIDTextField.setBounds(1153, 32, 157, 22);
		contentPane.add(browseDominoByIDTextField);
		browseDominoByIDTextField.setColumns(10);
		
		JPanel available_dominos = new JPanel();
		available_dominos.setBackground(null);
		available_dominos.setOpaque(false);
		available_dominos.setBorder(new LineBorder(SystemColor.scrollbar, 3));
		available_dominos.setBounds(1023, 114, 260, 550);
		contentPane.add(available_dominos);
		available_dominos.setLayout(null);
		
		JLabel lblChosenDominos = new JLabel("Chosen dominos:");
		lblChosenDominos.setFont(new Font("Yu Gothic UI", Font.BOLD, 16));
		lblChosenDominos.setBounds(703, 89, 137, 14);
		contentPane.add(lblChosenDominos);
		
		JLabel lblAvailableDominos = new JLabel("Available dominos:");
		lblAvailableDominos.setFont(new Font("Yu Gothic UI", Font.BOLD, 16));
		lblAvailableDominos.setBounds(1023, 89, 148, 14);
		contentPane.add(lblAvailableDominos);
		
		JLabel playerTurn = new JLabel(game.getNextPlayer().getColor()+"'s turn");
		playerTurn.setBackground(Color.DARK_GRAY);
		playerTurn.setForeground(Color.RED);
		playerTurn.setFont(new Font("Berlin Sans FB", Font.PLAIN, 18));
		playerTurn.setLabelFor(this);
		playerTurn.setBounds(450, 11, 148, 25);
		contentPane.add(playerTurn);
		
		JButton testerBtn = new JButton("Show draft");
		testerBtn.setBounds(667, 33, 89, 23);
		JButton testerBtn_1 = new JButton();
		testerBtn_1.setBackground(new Color(245, 222, 179));
		testerBtn_1.setSelectedIcon(null);
		testerBtn_1.setFont(new Font("Berlin Sans FB", Font.PLAIN, 12));
		testerBtn_1.setText("REVEAL DRAFT");
		testerBtn_1.setBounds(724, 32, 128, 23);
		contentPane.add(testerBtn_1);
		testerBtn_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evnt) {
				try {
					AGameplay.addDraftToView();
				} catch (InvalidInputException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		});
		
		JButton choose_d1 = new JButton("");
		choose_d1.setBounds(988, 154, 25, 25);
		choose_d1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evnt) {
				
				Game game = KingdominoApplication.getKingdomino().getCurrentGame();
				List<Domino> draftDominos = KingdominoApplication.getKingdomino().getCurrentGame().getNextDraft().getIdSortedDominos();
				String dir;
				if(game.getNextPlayer().getColor() == PlayerColor.Blue) dir = "/viewresources/blueCastle.png";
				else if(game.getNextPlayer().getColor() == PlayerColor.Green) dir = "/viewresources/greenCastle.png";
				else if(game.getNextPlayer().getColor() == PlayerColor.Pink) dir = "/viewresources/pinkCastle.png";
				else dir = "/viewresources/yellowCastle.png";
				castle1.setIcon(new ImageIcon(new javax.swing.ImageIcon(AGameplay.class.getResource(dir)).getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH)));
				
				try {
					Controller.chooseNextDomino(game.getNextDraft(), game.getNextPlayer(), game.getNextDraft().getIdSortedDomino(0));
					playerTurn.setText(game.getNextPlayer().getColor()+"'s turn");
					tryStartGame();
				} catch (InvalidInputException e) {
					System.out.println("No domino in draft");
				}
				int x = (draftComp[0].getX()-320);
				int y = draftComp[0].getY();
				if(x == 1063-320) {
					Integer id = new Integer(draftDominos.get(0).getId());
					removeDominoFromView(draftComp[0]);
					draftComp[0] = null;
					
					try {
						draftComp[0] = addDominoToView("f", Integer.toString(id), x, y, 180, 90);
					} catch (InvalidInputException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		});
		contentPane.add(choose_d1);
		
		JButton choose_d2 = new JButton("");
		choose_d2.setBounds(988, 279, 25, 25);
		choose_d2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evnt) {
				Game game = KingdominoApplication.getKingdomino().getCurrentGame();
				List<Domino> draftDominos = KingdominoApplication.getKingdomino().getCurrentGame().getNextDraft().getIdSortedDominos();
				String dir;
				if(game.getNextPlayer().getColor() == PlayerColor.Blue) dir = "/viewresources/blueCastle.png";
				else if(game.getNextPlayer().getColor() == PlayerColor.Green) dir = "/viewresources/greenCastle.png";
				else if(game.getNextPlayer().getColor() == PlayerColor.Pink) dir = "/viewresources/pinkCastle.png";
				else dir = "/viewresources/yellowCastle.png";
				castle2.setIcon(new ImageIcon(new javax.swing.ImageIcon(AGameplay.class.getResource(dir)).getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH)));
				
				try {
					Controller.chooseNextDomino(game.getNextDraft(), game.getNextPlayer(), game.getNextDraft().getIdSortedDomino(1));
					playerTurn.setText(game.getNextPlayer().getColor()+"'s turn");
					tryStartGame();
				} catch (InvalidInputException e) {
					System.out.println("No domino in draft");
				}
				int x = (draftComp[1].getX()-320);
				int y = draftComp[1].getY();
				if(x == 1063-320) {
					Integer id = new Integer(draftDominos.get(1).getId());
					removeDominoFromView(draftComp[1]);
					draftComp[1] = null;
					
					try {
						draftComp[1] = addDominoToView("f", Integer.toString(id), x, y, 180, 90);
					} catch (InvalidInputException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		});
		contentPane.add(choose_d2);
		
		JButton choose_d3 = new JButton("");
		choose_d3.setBounds(988, 404, 25, 25);
		choose_d3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evnt) {
				Game game = KingdominoApplication.getKingdomino().getCurrentGame();
				List<Domino> draftDominos = KingdominoApplication.getKingdomino().getCurrentGame().getNextDraft().getIdSortedDominos();
				String dir;
				if(game.getNextPlayer().getColor() == PlayerColor.Blue) dir = "/viewresources/blueCastle.png";
				else if(game.getNextPlayer().getColor() == PlayerColor.Green) dir = "/viewresources/greenCastle.png";
				else if(game.getNextPlayer().getColor() == PlayerColor.Pink) dir = "/viewresources/pinkCastle.png";
				else dir = "/viewresources/yellowCastle.png";
				castle3.setIcon(new ImageIcon(new javax.swing.ImageIcon(AGameplay.class.getResource(dir)).getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH)));
				
				try {
					Controller.chooseNextDomino(game.getNextDraft(), game.getNextPlayer(), game.getNextDraft().getIdSortedDomino(2));
					playerTurn.setText(game.getNextPlayer().getColor()+"'s turn");
					tryStartGame();
				} catch (InvalidInputException e) {
					System.out.println("No domino in draft");
				}
				int x = (draftComp[2].getX()-320);
				int y = draftComp[2].getY();
				if(x == 1063-320) {
					Integer id = new Integer(draftDominos.get(2).getId());
					removeDominoFromView(draftComp[2]);
					draftComp[2] = null;
					
					try {
						draftComp[2] = addDominoToView("f", Integer.toString(id), x, y, 180, 90);
					} catch (InvalidInputException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		});
		contentPane.add(choose_d3);
		
		JButton choose_d4 = new JButton("");
		choose_d4.setBounds(988, 529, 25, 25);
		choose_d4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evnt) {
				Game game = KingdominoApplication.getKingdomino().getCurrentGame();
				List<Domino> draftDominos = KingdominoApplication.getKingdomino().getCurrentGame().getNextDraft().getIdSortedDominos();
				String dir = null;
				if(game.getNextPlayer().getColor() == PlayerColor.Blue) dir = "/viewresources/blueCastle.png";
				else if(game.getNextPlayer().getColor() == PlayerColor.Green) dir = "/viewresources/greenCastle.png";
				else if(game.getNextPlayer().getColor() == PlayerColor.Pink) dir = "/viewresources/pinkCastle.png";
				else dir = "/viewresources/yellowCastle.png";
				castle4.setIcon(new ImageIcon(new javax.swing.ImageIcon(AGameplay.class.getResource(dir)).getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH)));
				
				try {
					Controller.chooseNextDomino(game.getNextDraft(), game.getNextPlayer(), game.getNextDraft().getIdSortedDomino(3));
					
					playerTurn.setText(game.getNextPlayer().getColor()+"'s turn");
					tryStartGame();
				} catch (InvalidInputException e) {
					JOptionPane.showMessageDialog(contentPane, "No Domino In Draft!", "Error",JOptionPane.ERROR_MESSAGE);	
				}
				
				int x = (draftComp[3].getX()-320);
				int y = draftComp[3].getY();
				if(x == 1063-320) {
					Integer id = new Integer(draftDominos.get(3).getId());
					removeDominoFromView(draftComp[3]);
					draftComp[3] = null;
					
					
					try {
						draftComp[3] = addDominoToView("f", Integer.toString(id), x, y, 180, 90);
					} catch (InvalidInputException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
			}
		});
		contentPane.add(choose_d4);
		

		castle1 = new JLabel("");
		castle1.setBounds(653, 154, 40, 40);
		contentPane.add(castle1);

		castle2 = new JLabel("");
		castle2.setBounds(653, 279, 40, 40);
		contentPane.add(castle2);

		castle3 = new JLabel("");
		castle3.setBounds(653, 404, 40, 40);
		contentPane.add(castle3);

		castle4 = new JLabel("");
		castle4.setBounds(653, 529, 40, 40);
		contentPane.add(castle4);
		
	
		
		///////////BUTTONS//////////////////
		
		JButton btnPlace = new JButton("PLACE DOMINO");
		btnPlace.setForeground(Color.WHITE);
		btnPlace.setBackground(new Color(0, 128, 0));
		btnPlace.setFont(new Font("Berlin Sans FB", Font.PLAIN, 13));
		btnPlace.setBounds(715, 678, 168, 25);
		btnPlace.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				Player player = KingdominoApplication.getKingdomino().getCurrentGame().getNextPlayer();
				
				if(player.getDominoSelection() != null) {
					Domino domino = player.getDominoSelection().getDomino();
					DominoInKingdom dom = null;
					
					for(int i =0; i<player.getKingdom().getTerritories().size(); i++) {
						if(player.getKingdom().getTerritory(i) instanceof DominoInKingdom) {
							if(domino.getId() == ((DominoInKingdom) player.getKingdom().getTerritory(i)).getDomino().getId()) {
								dom = ((DominoInKingdom) player.getKingdom().getTerritory(i));
							}
						}
					}
					
					try {
						Controller.placeCurrentDomino(player, dom.getDomino(), dom.getX(), dom.getY(), dom.getDirection());
						playerTurn.setText(game.getNextPlayer().getColor()+"'s turn");
					} catch (InvalidInputException e1) {
						JOptionPane.showMessageDialog(contentPane, "Domino is Incorrectly Placed!", "error",JOptionPane.ERROR_MESSAGE);	
					}
				}
			}
			
		});
		
		contentPane.add(btnPlace);
		
		JButton btnUp = new JButton("UP");
		btnUp.setFont(new Font("Berlin Sans FB", Font.PLAIN, 13));
		btnUp.setBackground(new Color(255, 218, 185));
		btnUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {	
				moveUp();
			}
		});
		btnUp.setBounds(12, 678, 73, 25);
		contentPane.add(btnUp);
		
		JButton btnDown = new JButton("DOWN");
		btnDown.setFont(new Font("Berlin Sans FB", Font.PLAIN, 13));

		btnDown.setBackground(new Color(255, 218, 185));
		btnDown.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				moveDown();
			}
		});
		btnDown.setBounds(97, 678, 80, 25);
		contentPane.add(btnDown);
		
		JButton btnLeft = new JButton("LEFT");
		btnLeft.setFont(new Font("Berlin Sans FB", Font.PLAIN, 13));
		
		btnLeft.setBackground(new Color(255, 218, 185));
		btnLeft.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				moveLeft();
			}
		});
		btnLeft.setBounds(189, 678, 80, 25);
		contentPane.add(btnLeft);
		
		JButton btnRight = new JButton("RIGHT");
		btnRight.setFont(new Font("Berlin Sans FB", Font.PLAIN, 13));
		btnRight.setBackground(new Color(255, 218, 185));
		btnRight.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				moveRight();
			}
		});
		btnRight.setBounds(281, 678, 80, 25);
		contentPane.add(btnRight);
		
		JButton btnClockwise = new JButton("CLOCKWISE");
		btnClockwise.setFont(new Font("Berlin Sans FB", Font.PLAIN, 13));
		btnClockwise.setBackground(new Color(230, 230, 250));
		btnClockwise.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				rotateClockwise();
			}
		});
		btnClockwise.setBounds(373, 678, 137, 25);
		contentPane.add(btnClockwise);
		
		JButton btnCounterclockwise = new JButton("COUNTERCLOCKWISE");
		btnCounterclockwise.setFont(new Font("Berlin Sans FB", Font.PLAIN, 13));
		btnCounterclockwise.setBackground(new Color(230, 230, 250));
		btnCounterclockwise.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				rotateCounterClockwise();
			}
		});
		btnCounterclockwise.setBounds(522, 678, 181, 25);
		contentPane.add(btnCounterclockwise);
		
		JPanel available_dominos_1 = new JPanel();
		available_dominos_1.setLayout(null);
		available_dominos_1.setOpaque(false);
		available_dominos_1.setBorder(new LineBorder(SystemColor.scrollbar, 3));
		available_dominos_1.setBackground((Color) null);
		available_dominos_1.setBounds(703, 114, 260, 550);
		contentPane.add(available_dominos_1);

		setIconImage(Toolkit.getDefaultToolkit()
				.getImage(AGameplay.class.getResource("/viewresources/icons8-castle-50.png")));

	}

	private Color getColor(PlayerColor color) {
		switch (color) {
		case Blue:
			return new Color(153, 204, 255);
		case Green:
			return new Color(153, 255, 153);
		case Yellow:
			return new Color(255, 255, 153);
		case Pink:
			return new Color(255, 204, 255);
		}
		return new Color(255, 255, 255);
	}

	public Domino getdominoByID(int id) {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		for (Domino domino : game.getAllDominos()) {
			if (domino.getId() == id) {
				return domino;
			}
		}
		throw new java.lang.IllegalArgumentException("Domino with ID " + id + " not found.");
	}

	private DominoInKingdom getDominoInKingdomByID(int id, Player p) {
		for (KingdomTerritory aDomino : p.getKingdom().getTerritories()) {

			if (aDomino instanceof DominoInKingdom) {
				DominoInKingdom domInKingdom = (DominoInKingdom) aDomino;
				if (domInKingdom.getDomino().getId() == id) {
					return domInKingdom;
				}
			}
		}
		return null;

	}

	DominoInKingdom testDominoInk;
	





/////////////////////////////////////////////////////////////////////////////////////////////
// This method contains all of the code for creating events
/////////////////////////////////////////////////////////////////////////////////////////////
	private void createEvents() {}
	
	
	/**
	 * addDraftToView : adds the given draft to the gameplay view on the right, from where players can pick a domino
	 * @author Niilo Vuokila
	 * @param the current draft to be added to the screen (right draft area)
	 * @throws InvalidInputException 
	 * @returns an array of JPanels, of the dominos in the draft
	 */
	public static JLabel[] addDraftToView() throws InvalidInputException {
		
		//removes dominoes from previous draft from the view
		if(draftComp!= null) {
			for(int i =0; i<draftComp.length; i++) {
				if(draftComp[i] != null) {
					removeDominoFromView(draftComp[i]);
					draftComp[i] = null;
					if(i == 0) castle1.setIcon(null);
					else if(i == 1) castle2.setIcon(null);
					else if(i == 2) castle3.setIcon(null);
					else castle4.setIcon(null);
				}
			}
		}
		
		List<Domino> list = KingdominoApplication.getKingdomino().getCurrentGame().getCurrentDraft().getIdSortedDominos();	//dominoes of the next draft to be displayed
		
		//create a label for the dominoes of the next draft
		String id;
		JLabel[] dominoList = new JLabel[list.size()];
		int initialY= 154;
		int step = 125;
		Integer obj;
		
		//adding each domino to the gameplay page
		for(int i = 0; i < list.size(); i++) {
			obj = new Integer(list.get(i).getId());
			id = Integer.toString(obj);
			dominoList[i] = addDominoToView("f", id, 1063, initialY+step*i, 180, 90);
		}
		draftComp = dominoList;
		
		return dominoList;
	}
	
	/**
	 * getGameCoordinate : gets the integer coordinate from the pixel coordinates on the screen (useless with current configuration)
	 * @author Niilo Vuokila
	 * @param the size of a side of the container (should be a square)
	 * @param the x coordinate of the container on the screen
	 * @param the y coordinate of the container  on the screen
	 * @param the x coordinate of the domino on the screen
	 * @param the y coordinate of the domino on the screen
	 * @returns an array of integers, x and y (returns -5 for either coordinate if invalid coordinate was provided)
	 */
	private int[] getGameCoordinate(int contSize, int contX, int contY, int domX, int domY) {
		int x = -5;
		int y = -5;
		int step= contSize/5;
		int domRelX = domX-contX;
		int domRelY = domY-contY;
		int[] gameCoord = new int[2];
	
		//has a range of 4 to check, avoids erroneous results for the integer coordinate
		if(domRelX == 0 || domRelX < 2) x = -2;
		else if(domRelX < step+2 || domRelX > step-2) x = -1; 
		else if(domRelX < (2*step)+2 || domRelX > (2*step)-2) x = 0;
		else if(domRelX < (3*step)+2 || domRelX > (3*step)-2) x = 1;
		else if(domRelX < (4*step)+2 || domRelX > (4*step)-2) x = 2;
	
		if(domRelY == 0 || domRelY < 2) x = -2;
		else if(domRelY < step+2 || domRelY > step-2) y = -1;
		else if(domRelY< (2*step)+2 || domRelY > (2*step)-2) y = 0;
		else if(domRelY < (3*step)+2 || domRelY > (3*step)-2) y = 1;
		else if(domRelY < (4*step)+2 || domRelY > (4*step)-2) y = 2;
	
		gameCoord[0] = x;
		gameCoord[1] = y;
	
		return gameCoord;
	}

	/**
	 * addDominoToView : adds the domino by the specified number to the view in the gameplay window.
	 * @author Niilo Vuokila
	 * @param spec - specification on if the back or the front is displayed: "f" for front "b" for back
	 * @param number - number of the domino
	 * @param x - the x coordinate on the screen
	 * @param y - the y coordinate on the screen
	 * @param width - width of the domino in pixels
	 * @param height - height of the domino in pixels
	 * @throws InvalidInputException 
	 * @returns the jpanel of the domino added
	 */
	private static JLabel addDominoToView(String spec, String number, int x, int y, int width, int height) throws InvalidInputException { 
		//container for the domino
		String dir;
		if(spec.equalsIgnoreCase("f")) dir = "/viewresources/domino"+number+".png";
		else if(spec.equalsIgnoreCase("b")) dir = "/viewresources/"+number+".png";
		else throw new InvalidInputException("argument for specification must be either b or f");
	
		//image parameters for the domino
		JLabel domino_image = new JLabel("");
		domino_image.setBounds(x, y, width, height);
		contentPane.add(domino_image);
		domino_image.setDoubleBuffered(true);
		domino_image.setMaximumSize(new Dimension(width, height));
		domino_image.setIcon(new ImageIcon(new javax.swing.ImageIcon(AGameplay.class.getResource(dir)).getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH)));
		domino_image.setOpaque(true);
		
		return domino_image;
	}
	/**
	 * removeDominoFromView : adds the domino by the specified number to the view in the gameplay window.
	 * @author Niilo Vuokila
	 * @param domino : the JLabel of the domino to be removed
	 */
	private static void removeDominoFromView(JLabel domino) {
		int x = domino.getX();
		int y = domino.getY();
		int height = domino.getHeight();
		int width = domino.getWidth();
		contentPane.remove(domino);
		contentPane.repaint(x, y, width, height);
		
	}
	
	/**
	 * Discard : shows message for discardDomino
	 * @author Ryad Ammar
	 * @param String : player's color 
	 */
	public static void discard(String player) {
			JOptionPane.showMessageDialog(contentPane,"Discarding "+player+"'s domino", "Notice",JOptionPane.INFORMATION_MESSAGE);
	}
}
