package ca.mcgill.ecse223.kingdomino.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import ca.mcgill.ecse223.kingdomino.KingdominoApplication;
import ca.mcgill.ecse223.kingdomino.controller.Controller;
import ca.mcgill.ecse223.kingdomino.controller.InvalidInputException;
import ca.mcgill.ecse223.kingdomino.model.Castle;
import ca.mcgill.ecse223.kingdomino.model.Domino;
import ca.mcgill.ecse223.kingdomino.model.Game;
import ca.mcgill.ecse223.kingdomino.model.Gameplay;
import ca.mcgill.ecse223.kingdomino.model.Kingdom;
import ca.mcgill.ecse223.kingdomino.model.Kingdomino;
import ca.mcgill.ecse223.kingdomino.model.Player;
import ca.mcgill.ecse223.kingdomino.model.TerrainType;
import ca.mcgill.ecse223.kingdomino.model.User;
import ca.mcgill.ecse223.kingdomino.model.Player.PlayerColor;

import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;
import java.util.List;
import javax.swing.ImageIcon;
import java.awt.Toolkit;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PlayerScore extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PlayerScore frame = new PlayerScore();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame which will display the rankings of the players in a particualr game 
	 * @author Alexandra Gafencu && Catherine Van Gheluwe
	 * @throws InvalidInputException 
	 */
	public PlayerScore() throws InvalidInputException {
		setIconImage(Toolkit.getDefaultToolkit().getImage(PlayerScore.class.getResource("/viewresources/icons8-castle-50.png")));
		setTitle("Kindomino");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 891, 452);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(224, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Final Scores");
		lblNewLabel.setFont(new Font("Berlin Sans FB", Font.PLAIN, 30));
		lblNewLabel.setBounds(374, 24, 150, 62);
		contentPane.add(lblNewLabel);
		
		Kingdomino kingdomino = KingdominoApplication.getKingdomino();
	

		Game currentGame = kingdomino.getCurrentGame();

		List<Player> playersRanked=Controller.calculateRanking(currentGame);
	
		
		Player player1=null;
		Player player2=null;
		Player player3=null;
		Player player4=null;

		
		String p1="";
		String p2="";
		String p3="";
		String p4="";
		

		player1=playersRanked.get(0);
		player2=playersRanked.get(1);
		player3=playersRanked.get(2);
		player4=playersRanked.get(3);
			
		p1=playersRanked.get(0).getUser().getName();
		p2=playersRanked.get(1).getUser().getName();
		p3=playersRanked.get(2).getUser().getName();
		p4=playersRanked.get(3).getUser().getName();
			
			

		int s1=player1.getTotalScore();
		int s2=player2.getTotalScore();
		int s3=player3.getTotalScore();
		int s4=player4.getTotalScore();


		JLabel username1 = new JLabel("1. "+ p1);
		username1.setFont(new Font("Berlin Sans FB", Font.PLAIN, 18));
		username1.setBounds(331, 175, 165, 16);
		contentPane.add(username1);
		
		JLabel username2 = new JLabel("2. "+ p2);
		username2.setFont(new Font("Berlin Sans FB", Font.PLAIN, 18));
		username2.setBounds(331, 210, 165, 16);
		contentPane.add(username2);
		
		JLabel username3 = new JLabel("3. "+ p3);
		username3.setFont(new Font("Berlin Sans FB", Font.PLAIN, 18));
		username3.setBounds(331, 248, 165, 16);
		contentPane.add(username3);
		
		JLabel username4 = new JLabel("4. "+ p4);
		username4.setFont(new Font("Berlin Sans FB", Font.PLAIN, 18));
		username4.setBounds(331, 288, 165, 16);
		contentPane.add(username4);
		
		JLabel score1 = new JLabel(s1+"");
		score1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		score1.setBounds(528, 175, 56, 16);
		contentPane.add(score1);
		
		JLabel score2 = new JLabel(s2+"");
		score2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		score2.setBounds(528, 210, 56, 16);
		contentPane.add(score2);
		
		JLabel score3 = new JLabel(s3+"");
		score3.setFont(new Font("Tahoma", Font.PLAIN, 18));
		score3.setBounds(528, 248, 56, 16);
		contentPane.add(score3);
		
		JLabel score4 = new JLabel(s4+"");
		score4.setFont(new Font("Tahoma", Font.PLAIN, 18));
		score4.setBounds(528, 288, 56, 16);
		contentPane.add(score4);
		
		JLabel deco1 = new JLabel("");
		deco1.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/CastleMenu.PNG")).getImage().getScaledInstance(200, 200, Image.SCALE_SMOOTH)));
		deco1.setBounds(47, 124, 200, 200);
		contentPane.add(deco1);
		
		JLabel deco2 = new JLabel("");
		deco2.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/viewresources/menugreencastle.PNG")).getImage().getScaledInstance(200, 200, Image.SCALE_SMOOTH)));
		
		deco2.setBounds(626, 124, 200, 200);
		contentPane.add(deco2);
		
		JButton btnMainMenu = new JButton("Main Menu");
		btnMainMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Controller.save(kingdomino); //save the ranking
					MainMenu mainMenu = new MainMenu();
					mainMenu.setVisible(true);
					
					setVisible(false); //you can't see me!
					dispose(); //Destroy the JFrame object
				} catch (InvalidInputException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnMainMenu.setFont(new Font("Berlin Sans FB", Font.PLAIN, 15));
		btnMainMenu.setBackground(Color.PINK);
		btnMainMenu.setBounds(12, 13, 124, 25);
		contentPane.add(btnMainMenu);
	}
}