package ca.mcgill.ecse223.kingdomino.stepdefinition;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import ca.mcgill.ecse223.kingdomino.KingdominoApplication;
import ca.mcgill.ecse223.kingdomino.controller.Controller;
import ca.mcgill.ecse223.kingdomino.model.Castle;
import ca.mcgill.ecse223.kingdomino.model.Domino;
import ca.mcgill.ecse223.kingdomino.model.Domino.DominoStatus;
import ca.mcgill.ecse223.kingdomino.model.DominoInKingdom;
import ca.mcgill.ecse223.kingdomino.model.DominoInKingdom.DirectionKind;
import ca.mcgill.ecse223.kingdomino.model.Game;
import ca.mcgill.ecse223.kingdomino.model.Kingdom;
import ca.mcgill.ecse223.kingdomino.model.KingdomTerritory;
import ca.mcgill.ecse223.kingdomino.model.Kingdomino;
import ca.mcgill.ecse223.kingdomino.model.Player;
import ca.mcgill.ecse223.kingdomino.model.Player.PlayerColor;
import ca.mcgill.ecse223.kingdomino.model.TerrainType;
import ca.mcgill.ecse223.kingdomino.model.User;
import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;



public class VerifyNeighborAdjacency {
	
	private DominoInKingdom domino1;
	private Player p1;
	private boolean result;
	

	DominoInKingdom dominoInKingdom1;
	Kingdomino kingdomino;
	 List<User> userList ;
	 List<List<String>> userNames;
	 List<String> names;
	 
	
	
	@Given("the game is initialized for neighbor adjacency")
	public void the_game_is_initialized_for_neighbor_adjacency() {
	    // Write code here that turns the phrase above into concrete actions
		// Intialize empty game
		kingdomino = new Kingdomino();
	    Game game = new Game(48, kingdomino);
        game.setNumberOfPlayers(4);
        kingdomino.setCurrentGame(game);

     addDefaultUsersAndPlayers(game);
	 createAllDominoes(game);
	 game.setNextPlayer(game.getPlayer(0));
	 for(int i = 0; i < 4; i++) {
		 User user = game.getPlayer(i).getUser();
		//kingdomino.addUser(user);
	 }
	 KingdominoApplication.setKingdomino(kingdomino);
	}

	@Given("the following dominoes are present in a player's kingdom:")
	public void the_following_dominoes_are_present_in_a_player_s_kingdom(io.cucumber.datatable.DataTable dataTable) {
	    // Write code here that turns the phrase above into concrete actions
	    // For automatic transformation, change DataTable to one of
	    // E, List<E>, List<List<E>>, List<Map<K,V>>, Map<K,V> or
	    // Map<K, List<V>>. E,K,V must be a String, Integer, Float,
	    // Double, Byte, Short, Long, BigInteger or BigDecimal.
	    //
	    // For other transformations you can register a DataTableType.

		    // Write code here that turns the phrase above into concrete actions
			Game game = KingdominoApplication.getKingdomino().getCurrentGame();
			
			List<Map<String, String>> valueMaps = dataTable.asMaps();
			for (Map<String, String> map : valueMaps) {
				// Get values from cucumber table
				Integer id = Integer.decode(map.get("id"));
				DirectionKind dir = getDirection(map.get("dominodir"));
				Integer posx = Integer.decode(map.get("posx"));
				Integer posy = Integer.decode(map.get("posy"));

				// Add the domino to a player's kingdom
				Domino dominoToPlace = getdominoByID(id);
				p1 = game.getPlayer(0);
				Kingdom kingdom = game.getPlayer(0).getKingdom();
				DominoInKingdom domInKingdom = new DominoInKingdom(posx, posy, kingdom, dominoToPlace);
				domInKingdom.setDirection(dir);
				dominoToPlace.setStatus(DominoStatus.PlacedInKingdom);
			}
	}

	@When("check current preplaced domino adjacency is initiated")
	public void check_current_preplaced_domino_adjacency_is_initiated() {
	    // Write code here that turns the phrase above into concrete actions
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		p1 = game.getPlayer(0);
		domino1 = getCurrentlyplaced(p1);
		result=Controller.verifyNeighborAdjacency(domino1);
	}
	
	private DominoInKingdom getCurrentlyplaced(Player p) {
		for(KingdomTerritory aDomino:p.getKingdom().getTerritories()) {
			if(aDomino instanceof DominoInKingdom) {
				DominoInKingdom domInKingdom=(DominoInKingdom) aDomino;
				if(domInKingdom.getDomino().getStatus() ==DominoStatus.CorrectlyPreplaced)
					return domInKingdom;
			}
		}
		return null;
	}

	@Then("the current-domino\\/existing-domino adjacency is {string}")
	public void the_current_domino_existing_domino_adjacency_is(String string) {
	    // Write code here that turns the phrase above into concrete actions
		
		assert(result==getResult(string));
	}
	
	private void addDefaultUsersAndPlayers(Game game) {
		String[] userNames = { "User1", "User2", "User3", "User4" };
		userList = game.getKingdomino().getUsers();
		for(int j = 0; j < userNames.length; j++) {
			
			String name = userNames[j];
			Player player = new Player(game);
			player.setColor(PlayerColor.values()[j]);
			
			//associate a user to a player 
			if(userList.contains(userNames[j])) {
				User user = User.getWithName(userNames[j]);
				player.setUser(user);
			}else {
				User user = User.getWithName(userNames[j]);
				player.setUser(user);
				
				/*User user = new User(userNames[j], kingdomino);
				kingdomino.addUser(userNames[j]);
				player.setUser(user);
				*/
			}
			Kingdom kingdom = new Kingdom(player);
			new Castle(0, 0, kingdom, player);
		}
	}
	
	public void createAllDominoes(Game game) {
		try {
			BufferedReader br = new BufferedReader(new FileReader("src/main/resources/alldominoes.dat"));
			String line = "";
			String delimiters = "[:\\+()]";
			while ((line = br.readLine()) != null) {
				String[] dominoString = line.split(delimiters); // {id, leftTerrain, rightTerrain, crowns}
				int dominoId = Integer.decode(dominoString[0]);
				TerrainType leftTerrain = getTerrainType(dominoString[1]);
				TerrainType rightTerrain = getTerrainType(dominoString[2]);
				int numCrown = 0;
				if (dominoString.length > 3) {
					numCrown = Integer.decode(dominoString[3]);
				}
				new Domino(dominoId, leftTerrain, rightTerrain, numCrown, game);
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
			throw new java.lang.IllegalArgumentException(
					"Error occured while trying to read alldominoes.dat: " + e.getMessage());
		}
	}

	public TerrainType getTerrainType(String terrain) {
		switch (terrain) {
		case "W":
			return TerrainType.WheatField;
		case "F":
			return TerrainType.Forest;
		case "M":
			return TerrainType.Mountain;
		case "G":
			return TerrainType.Grass;
		case "S":
			return TerrainType.Swamp;
		case "L":
			return TerrainType.Lake;
		default:
			throw new java.lang.IllegalArgumentException("Invalid terrain type: " + terrain);
		}
	}
	
	public Domino getdominoByID(int id) {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		for (Domino domino : game.getAllDominos()) {
			if (domino.getId() == id) {
				return domino;
			}
		}
		throw new java.lang.IllegalArgumentException("Domino with ID " + id + " not found.");
	}
	
	public DirectionKind getDirection(String dir) {
		switch (dir) {
		case "up":
			return DirectionKind.Up;
		case "down":
			return DirectionKind.Down;
		case "left":
			return DirectionKind.Left;
		case "right":
			return DirectionKind.Right;
		default:
			throw new java.lang.IllegalArgumentException("Invalid direction: " + dir);
		}
	}
	
	public boolean getResult(String string) {
		
		switch(string) {
		case "valid":
			return true;
		case "invalid":
			return false;
		default:
			throw new java.lang.IllegalArgumentException("Invalid result: " + string);
		}
	}
	@After
	public void tearDown() {
		Kingdomino kingdomino = KingdominoApplication.getKingdomino();
		if(kingdomino!=null) {
			kingdomino.delete();
			if(kingdomino.getCurrentGame()!=null) {
				kingdomino.getCurrentGame().delete();
			}
		}

	}
}
