package ca.mcgill.ecse223.kingdomino.stepdefinition;

import static org.junit.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import ca.mcgill.ecse223.kingdomino.KingdominoApplication;
import ca.mcgill.ecse223.kingdomino.controller.Controller;
import ca.mcgill.ecse223.kingdomino.model.Castle;
import ca.mcgill.ecse223.kingdomino.model.Domino;
import ca.mcgill.ecse223.kingdomino.model.Domino.DominoStatus;
import ca.mcgill.ecse223.kingdomino.model.DominoInKingdom;
import ca.mcgill.ecse223.kingdomino.model.DominoInKingdom.DirectionKind;
import ca.mcgill.ecse223.kingdomino.model.DominoSelection;
import ca.mcgill.ecse223.kingdomino.model.Draft;
import ca.mcgill.ecse223.kingdomino.model.Draft.DraftStatus;
import ca.mcgill.ecse223.kingdomino.model.Game;
import ca.mcgill.ecse223.kingdomino.model.Kingdom;
import ca.mcgill.ecse223.kingdomino.model.KingdomTerritory;
import ca.mcgill.ecse223.kingdomino.model.Kingdomino;
import ca.mcgill.ecse223.kingdomino.model.Player;
import ca.mcgill.ecse223.kingdomino.model.Player.PlayerColor;
import ca.mcgill.ecse223.kingdomino.model.TerrainType;
import ca.mcgill.ecse223.kingdomino.model.User;
import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MoveCurrentDomino {

	//Player p1;
	DominoInKingdom dominoInKingdom1;
	Kingdomino kingdomino;
	List<User> userList;
	List<List<String>> userNames;
	// String[] names;
	List<String> names;

	@Given("the game is initialized for move current domino")
	public void the_game_is_initialized_for_move_current_domino() {
		// Write code here that turns the phrase above into concrete actions
		kingdomino = new Kingdomino();
		Game game = new Game(48, kingdomino);
		game.setNumberOfPlayers(4);
		kingdomino.setCurrentGame(game);
		addDefaultUsersAndPlayers(game);
		createAllDominoes(game);
		game.setNextPlayer(game.getPlayer(0));
		KingdominoApplication.setKingdomino(kingdomino);

	}

	@Given("it is {string}'s turn")
	public void it_is_s_turn(String string) {
		// Write code here that turns the phrase above into concrete actions
		Controller.setCurrentPlayer(getPlayerByColor(string));
	}

	@Given("{string} has selected domino {int}")
	public void has_selected_domino(String string, Integer int1) {
		Player p1 = getPlayerByColor(string);
		Game game = p1.getGame();
		Domino domino = getdominoByID(int1);
		Kingdom kingdom = p1.getKingdom();
		new DominoInKingdom(0, 0, kingdom, domino);
		domino.setStatus(DominoStatus.ErroneouslyPreplaced);
		// p1.setd
		// var aNewDominoSelection = new DominoSelection();
		Draft draft = new Draft(DraftStatus.FaceDown, game);
		draft.addIdUnsortedDomino(domino);
		game.setCurrentDraft(draft);
		DominoSelection dominoSelection = new DominoSelection(p1, domino, game.getCurrentDraft());
		p1.setDominoSelection(dominoSelection);
		Controller.setCurrentPlayer(p1);
	}

	@When("{string} removes his king from the domino {int}")
	public void removes_his_king_from_the_domino(String string, Integer int1) {
		// Write code here that turns the phrase above into concrete actions
		Controller.setCurrentPlayer(getPlayerByColor(string));
		Domino d;
		DominoInKingdom dink = getDominoInKingdomByID(int1);
		if (dink != null) {
			d = dink.getDomino();
		} else {
			d = getDominoFromDraft(int1);
		}

		d.setStatus(DominoStatus.InCurrentDraft);
	}

	@Then("domino {int} should be tentative placed at position {int}:{int} of {string}'s kingdom with ErroneouslyPreplaced status")
	public void domino_should_be_tentative_placed_at_position_of_s_kingdom_with_ErroneouslyPreplaced_status(
			Integer int1, Integer int2, Integer int3, String string) {
		// Write code here that turns the phrase above into concrete actions
		Controller.setCurrentPlayer(getPlayerByColor(string));
		DominoInKingdom dominoInKingdom = getDominoInKingdomByID(int1);
		Controller.moveCurrentDomino(dominoInKingdom, DirectionKind.Up);

		Domino domino = dominoInKingdom.getDomino();

		assertEquals(domino.getStatus(), DominoStatus.ErroneouslyPreplaced);
		assert (dominoInKingdom.getX() == int2);
		assert (dominoInKingdom.getY() == int3);
	}

	@Given("{string}'s kingdom has following dominoes:")
	public void s_kingdom_has_following_dominoes(String string, io.cucumber.datatable.DataTable dataTable) {
		// Write code here that turns the phrase above into concrete actions
		// For automatic transformation, change DataTable to one of
		// E, List<E>, List<List<E>>, List<Map<K,V>>, Map<K,V> or
		// Map<K, List<V>>. E,K,V must be a String, Integer, Float,
		// Double, Byte, Short, Long, BigInteger or BigDecimal.
		//
		// For other transformations you can register a DataTableType.

		List<Map<String, String>> valueMaps = dataTable.asMaps();
		for (Map<String, String> map : valueMaps) {
			// Get values from cucumber table
			Integer id = Integer.decode(map.get("id"));
			DirectionKind dir = getDirection(map.get("dir"));
			Integer posx = Integer.decode(map.get("posx"));
			Integer posy = Integer.decode(map.get("posy"));

			// Add the domino to a player's kingdom
			Domino dominoToPlace = getdominoByID(id);
			Kingdom kingdom = getPlayerByColor(string).getKingdom();
			DominoInKingdom domInKingdom = new DominoInKingdom(posx, posy, kingdom, dominoToPlace);
			domInKingdom.setDirection(dir);
			dominoToPlace.setStatus(DominoStatus.PlacedInKingdom);
		}
	}

	@Given("domino {int} is tentatively placed at position {int}:{int} with direction {string}")
	public void domino_is_tentatively_placed_at_position_with_direction(Integer int1, Integer int2, Integer int3,
			String string) {
		// Write code here that turns the phrase above into concrete actions

		DominoInKingdom dominoInKingdom = getDominoInKingdomByID(int1);
		dominoInKingdom.setX(int2);
		dominoInKingdom.setY(int3);
		dominoInKingdom.setDirection(getDirection(string));
	}

	@When("{string} requests to move the domino {string}")
	public void requests_to_move_the_domino(String string, String string2) {
		// Write code here that turns the phrase above into concrete actions
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();

		Player p1 = getPlayerByColor(string);
		Controller.setCurrentPlayer(p1);
		game.setNextPlayer(p1);

		DominoInKingdom d1 = getDominoInKingdomByID(p1.getDominoSelection().getDomino().getId());
		DirectionKind dir = getDirection(string2);
		Controller.moveCurrentDomino(d1, dir);
	}

	@Then("the domino {int} should be tentatively placed at position {int}:{int} with direction {string}")
	public void the_domino_should_be_tentatively_placed_at_position_with_direction(Integer int1, Integer int2,
			Integer int3, String string) {
		// Write code here that turns the phrase above into concrete actions
		dominoInKingdom1 = getDominoInKingdomByID(int1);

		assert (dominoInKingdom1.getX() == int2);
		assert (dominoInKingdom1.getY() == int3);
		assertEquals(dominoInKingdom1.getDirection(), getDirection(string));
	}

	@Then("the new status of the domino is {string}")
	public void the_new_status_of_the_domino_is(String string) {
		// Write code here that turns the phrase above into concrete actions
		assert (dominoInKingdom1.getDomino().getStatus() == getDominoStatus(string));
	}

	@Given("domino {int} has status {string}")
	public void domino_has_status(Integer int1, String string) {
		// Write code here that turns the phrase above into concrete actions
		getDominoInKingdomByID(int1).getDomino().setStatus(getDominoStatus(string));
	}

	@Then("the domino {int} is still tentatively placed at position {int}:{int}")
	public void the_domino_is_still_tentatively_placed_at_position(Integer int1, Integer int2, Integer int3) {
		// Write code here that turns the phrase above into concrete actions
		dominoInKingdom1 = getDominoInKingdomByID(int1);
		assert (dominoInKingdom1.getX() == int2);
		assert (dominoInKingdom1.getY() == int3);
	}

	@Then("the domino should still have status {string}")
	public void the_domino_should_still_have_status(String string) {
		// Write code here that turns the phrase above into concrete actions
		DominoStatus status = dominoInKingdom1.getDomino().getStatus();
		assert (status == getDominoStatus(string));
	}

	@After
	public void tearDown() {
		Kingdomino kingdomino = KingdominoApplication.getKingdomino();
		if (kingdomino != null) {
			kingdomino.delete();
			if (kingdomino.getCurrentGame() != null) {
				kingdomino.getCurrentGame().delete();
			}
		}
	}

	// helper
	public void createAllDominoes(Game game) {
		try {
			BufferedReader br = new BufferedReader(new FileReader("src/main/resources/alldominoes.dat"));
			String line = "";
			String delimiters = "[:\\+()]";
			while ((line = br.readLine()) != null) {
				String[] dominoString = line.split(delimiters); // {id, leftTerrain, rightTerrain, crowns}
				int dominoId = Integer.decode(dominoString[0]);
				TerrainType leftTerrain = getTerrainType(dominoString[1]);
				TerrainType rightTerrain = getTerrainType(dominoString[2]);
				int numCrown = 0;
				if (dominoString.length > 3) {
					numCrown = Integer.decode(dominoString[3]);
				}
				new Domino(dominoId, leftTerrain, rightTerrain, numCrown, game);
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
			throw new java.lang.IllegalArgumentException(
					"Error occured while trying to read alldominoes.dat: " + e.getMessage());
		}
	}

	public TerrainType getTerrainType(String terrain) {
		switch (terrain) {
		case "W":
			return TerrainType.WheatField;
		case "F":
			return TerrainType.Forest;
		case "M":
			return TerrainType.Mountain;
		case "G":
			return TerrainType.Grass;
		case "S":
			return TerrainType.Swamp;
		case "L":
			return TerrainType.Lake;
		default:
			throw new java.lang.IllegalArgumentException("Invalid terrain type: " + terrain);
		}
	}

//	public void addDefaultUsersAndPlayers(Game game) {
//		String[] userNames = { "User1", "User2", "User3", "User4" };
//		for (int i = 0; i < userNames.length; i++) {
//			User user = game.getKingdomino().addUser(userNames[i]);
//			Player player = new Player(game);
//			player.setUser(user);
//			player.setColor(PlayerColor.values()[i]);
//			Kingdom kingdom = new Kingdom(player);
//			new Castle(0, 0, kingdom, player);
//		}
//	}

	private void addDefaultUsersAndPlayers(Game game) {
		String[] userNames = { "User1", "User2", "User3", "User4" };
		userList = game.getKingdomino().getUsers();
		for (int j = 0; j < userNames.length; j++) {

			String name = userNames[j];
			Player player = new Player(game);
			player.setColor(PlayerColor.values()[j]);

			// associate a user to a player
			if (userList.contains(userNames[j])) {
				User user = User.getWithName(userNames[j]);
				player.setUser(user);
			} else {
				User user = User.getWithName(userNames[j]);
				player.setUser(user);

				/*
				 * User user = new User(userNames[j], kingdomino);
				 * kingdomino.addUser(userNames[j]); player.setUser(user);
				 */
			}
			Kingdom kingdom = new Kingdom(player);
			new Castle(0, 0, kingdom, player);
		}
	}

	/**
	 * @author Alexandra Gafencu
	 * @param name
	 * @return a Player
	 */
	public Player getPlayerByColor(String color) {
		Kingdomino kingDomino = KingdominoApplication.getKingdomino();
		Game game = kingDomino.getCurrentGame();

		for (Player player : game.getPlayers()) {
			if (player.getColor() == getColorType(color)) {
				return player;
			}
		}
		throw new java.lang.IllegalArgumentException("Player with name " + color + " not found.");
	}

	public PlayerColor getColorType(String color) {
		switch (color.toLowerCase()) {
		case "blue":
			return PlayerColor.Blue;
		case "green":
			return PlayerColor.Green;
		case "yellow":
			return PlayerColor.Yellow;
		case "pink":
			return PlayerColor.Pink;
		}
		return PlayerColor.Blue;
	}

	public Domino getdominoByID(int id) {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		for (Domino domino : game.getAllDominos()) {
			if (domino.getId() == id) {
				return domino;
			}
		}
		throw new java.lang.IllegalArgumentException("Domino with ID " + id + " not found.");
	}

	/**
	 * @author Alexandra Gafencu
	 * @param id
	 * @return a DominoInKindom
	 */
	private DominoInKingdom getDominoInKingdomByID(int id) {
		for (KingdomTerritory aDomino : Controller.getCurrentPlayer().getKingdom().getTerritories()) {

			if (aDomino instanceof DominoInKingdom) {
				DominoInKingdom domInKingdom = (DominoInKingdom) aDomino;
				if (domInKingdom.getDomino().getId() == id) {
					return domInKingdom;
				}
			}
		}
		return null;

	}

	private Domino getDominoFromDraft(Integer int1) {
		for (Domino d : Controller.getCurrentPlayer().getGame().getAllDominos()) {
			if (d.getId() == int1)
				return d;
		}
		return null;
	}

	public DirectionKind getDirection(String dir) {
		switch (dir) {
		case "up":
			return DirectionKind.Up;
		case "down":
			return DirectionKind.Down;
		case "left":
			return DirectionKind.Left;
		case "right":
			return DirectionKind.Right;
		default:
			throw new java.lang.IllegalArgumentException("Invalid direction: " + dir);
		}
	}

	public DominoStatus getDominoStatus(String status) {
		switch (status) {
		case "InPile":
			return DominoStatus.InPile;
		case "Excluded":
			return DominoStatus.Excluded;
		case "InCurrentDraft":
			return DominoStatus.InCurrentDraft;
		case "InNextDraft":
			return DominoStatus.InNextDraft;
		case "ErroneouslyPreplaced":
			return DominoStatus.ErroneouslyPreplaced;
		case "CorrectlyPreplaced":
			return DominoStatus.CorrectlyPreplaced;
		case "PlacedInKingdom":
			return DominoStatus.PlacedInKingdom;
		case "Discarded":
			return DominoStatus.Discarded;
		default:
			throw new java.lang.IllegalArgumentException("Invalid domino status: " + status);
		}
	}
}