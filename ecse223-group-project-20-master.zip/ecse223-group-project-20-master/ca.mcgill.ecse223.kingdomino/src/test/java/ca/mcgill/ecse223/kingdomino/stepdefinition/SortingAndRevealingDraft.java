package ca.mcgill.ecse223.kingdomino.stepdefinition;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Iterator;
import java.util.List;

import ca.mcgill.ecse223.kingdomino.KingdominoApplication;
import ca.mcgill.ecse223.kingdomino.controller.Controller;
import ca.mcgill.ecse223.kingdomino.controller.InvalidInputException;
import ca.mcgill.ecse223.kingdomino.model.Domino;
import ca.mcgill.ecse223.kingdomino.model.DominoSelection;
import ca.mcgill.ecse223.kingdomino.model.Draft;
import ca.mcgill.ecse223.kingdomino.model.Draft.DraftStatus;
import ca.mcgill.ecse223.kingdomino.model.Game;
import ca.mcgill.ecse223.kingdomino.model.Gameplay;
import ca.mcgill.ecse223.kingdomino.model.Player;
import ca.mcgill.ecse223.kingdomino.model.Player.PlayerColor;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

// Contributors: Vadim
public class SortingAndRevealingDraft {
	@Given("there is a next draft, face down")
	public void there_is_a_next_draft_face_down() {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		Draft nextDraft = null;
		try {
			Gameplay.createNextDraft();
			nextDraft = game.getNextDraft();
			nextDraft.setDraftStatus(DraftStatus.FaceDown);
		} catch (Exception e) {
		}
	}

	@Given("all dominoes in current draft are selected")
	public void all_dominoes_in_current_draft_are_selected() {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		try {
			List <Domino> dominoesInDraft =  game.getCurrentDraft().getIdSortedDominos();
			List<DominoSelection> dominoSelections =  game.getCurrentDraft().getSelections();
			if (dominoesInDraft != null) {
				for (int i = 0; i < dominoesInDraft.size(); i++) {
					dominoSelections.get(i).setDomino(dominoesInDraft.get(i));
				} 
			}
		} catch (NullPointerException e) {} 
	}


	@When("next draft is sorted")
	public void next_draft_is_sorted() throws InvalidInputException {
		Gameplay.orderAndRevealNextDraft();
	}

	@When("next draft is revealed")
	public void next_draft_is_revealed() {
		Gameplay.orderAndRevealNextDraft();
	}

	@Then("the next draft shall be sorted")
	public void the_next_draft_shall_be_sorted() {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		Draft nextDraft = game.getNextDraft();
		List<Domino> sortedDominoes =  nextDraft.getIdSortedDominos();
		for (int i = 0; i < sortedDominoes.size(); i++) {
			assertEquals(true, (sortedDominoes.get(i).getId() < sortedDominoes.get(i+1).getId())); // the previous domino's ID is smaller than the next domino's ID
		}
	}

	@Then("the next draft shall be facing up")
	public void the_next_draft_shall_be_facing_up() {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		Draft nextDraft = game.getNextDraft();
		DraftStatus draftStatus = nextDraft.getDraftStatus();
		assertEquals(DraftStatus.FaceUp, draftStatus);
	}

	@Then("it shall be the player's turn with the lowest domino ID selection")
	public void it_shall_be_the_player_s_turn_with_the_lowest_domino_ID_selection() {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		List<DominoSelection> selections = game.getNextDraft().getSelections();
		Domino smallestDomino = selections.get(0).getDomino();
		for(int i = 1; i < selections.size(); i++) {
			if (selections.get(i).getDomino().getId() < smallestDomino.getId()) {
				smallestDomino = selections.get(i).getDomino();
			}
		}
		PlayerColor nextExpectedPlayer = smallestDomino.getDominoSelection().getPlayer().getColor(); //the smallest domino ID in the current draft //game.getCurrentDraft().getIdSortedDominos().get(0).getDominoSelection().getPlayer().getColor(); 
		
		PlayerColor nextActualPlayerColor = game.getNextPlayer().getColor(); //the next player of the game
		
		assertEquals(nextExpectedPlayer, nextActualPlayerColor);
}

}
