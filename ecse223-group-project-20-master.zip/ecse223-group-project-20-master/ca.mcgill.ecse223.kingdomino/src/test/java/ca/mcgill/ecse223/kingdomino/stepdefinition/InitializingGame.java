package ca.mcgill.ecse223.kingdomino.stepdefinition;
import static org.junit.Assert.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;

import ca.mcgill.ecse223.kingdomino.KingdominoApplication;
import ca.mcgill.ecse223.kingdomino.controller.Controller;
import ca.mcgill.ecse223.kingdomino.model.Castle;
import ca.mcgill.ecse223.kingdomino.model.Domino;
import ca.mcgill.ecse223.kingdomino.model.Draft;
import ca.mcgill.ecse223.kingdomino.model.Game;
import ca.mcgill.ecse223.kingdomino.model.Gameplay;
import ca.mcgill.ecse223.kingdomino.model.Gameplay.Gamestatus;
import ca.mcgill.ecse223.kingdomino.model.Gameplay.GamestatusInitializing;
import ca.mcgill.ecse223.kingdomino.model.Kingdom;
import ca.mcgill.ecse223.kingdomino.model.Kingdomino;
import ca.mcgill.ecse223.kingdomino.model.Player;
import ca.mcgill.ecse223.kingdomino.model.TerrainType;
import ca.mcgill.ecse223.kingdomino.model.User;
import ca.mcgill.ecse223.kingdomino.model.Draft.DraftStatus;
import ca.mcgill.ecse223.kingdomino.model.Player.PlayerColor;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class InitializingGame {
	Game game;
	Kingdomino kingdomino;
	List<Player> initialOrder;
	List<Player> shuffledPlayers;
	List<String> results;
	Player firstPlayer;
	
	
	@Given("the game has not been started")
	public void the_game_has_not_been_started() {
		// Intialize empty game
		kingdomino = new Kingdomino();
		game = new Game(48, kingdomino);
		game.setNumberOfPlayers(4);
		kingdomino.setCurrentGame(game);
		
		// Populate game
		addDefaultUsersAndPlayers(game);
		initialOrder = new ArrayList<Player> ();
		for(int i = 0; i < game.getPlayers().size(); i++) {
			Player aPlayer = game.getPlayer(i);
			initialOrder.add(aPlayer);
		}
		createAllDominoes(game);
		game.setNextPlayer(game.getPlayer(0));
		KingdominoApplication.setKingdomino(kingdomino);
		
		//-----------------------------------------------------------
		//CALL THE "INITIATING "STATE
		//-----------------------------------------------------------
	}

	@When("start of the game is initiated")
	public void start_of_the_game_is_initiated() throws Exception{
		
		//-----------------------------------------------------------
		//CALL THE "CREATING FIRST DRAFT" STATE
		//-----------------------------------------------------------
		game = kingdomino.getCurrentGame();
		
		Gameplay.shuffleDominoPile();
		Draft originalFirst = game.getCurrentDraft();
		Draft nextDraft = new Draft(DraftStatus.FaceDown, game);
		game.setNextDraft(nextDraft);
		try {
			Gameplay.createNextDraft();
			
			} catch (Exception e) {
			throw new Exception("next draft does not exist");
		}
		
		
		
		game.setNextDraft(originalFirst);
		Gameplay.orderAndRevealNextDraft();
		//reveal the first draft
		game.setCurrentDraft(originalFirst);
		game.setNextDraft(nextDraft);
		game.getCurrentDraft().setDraftStatus(DraftStatus.FaceUp);
	

		shuffledPlayers =	Controller.generateInitialPlayerOrder();
		for(int i = 0; i < shuffledPlayers.size(); i++) {
			game.addOrMovePlayerAt(shuffledPlayers.get(i),i);
			
		}
		
		//-----------------------------------------------------------
		//CALL THE "SELECTING FIRST DOMINO "STATE
		//-----------------------------------------------------------
		
	}	

	@Then("the pile shall be shuffled")
	public void the_pile_shall_be_shuffled() {
		game = kingdomino.getCurrentGame();
		Draft firstDraft = game.getAllDraft(0);
		DraftStatus firstStatus = firstDraft.getDraftStatus();
		String firstString = getStatus(firstStatus);
		String expect = getStatus(DraftStatus.FaceUp);
		assertEquals(expect, firstString);
		
	}

	@Then("the first draft shall be on the table")
	public void the_first_draft_shall_be_on_the_table() {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		Draft draft = game.getCurrentDraft();
		boolean currentDraftExists = (draft != null);

		assertEquals(true, currentDraftExists);
	}

	@Then("the first draft shall be revealed")
	public void the_first_draft_shall_be_revealed() {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		Draft draft = game.getCurrentDraft();
		DraftStatus draftStatus = draft.getDraftStatus();

		assertEquals(DraftStatus.FaceUp, draftStatus);
	}

	@Then("the initial order of players shall be determined")
	public void the_initial_order_of_players_shall_be_determined() {
		
		String aResult;
		List<Player> shuffledPlayers = game.getPlayers();
		List<String> results = new ArrayList<String> ();
		int count = 0;
		
		for(int i = 0; i < shuffledPlayers.size(); i++) {
			Player initialOrderPlayer = initialOrder.get(i);
			Player shuffledOrderPlayer = shuffledPlayers.get(i);
			
			if(initialOrderPlayer.equals(shuffledOrderPlayer)) {	
				count ++;
			}
			
		}
		
		if(count == 4) {
			 aResult = "fail";
		}else {
			 aResult = "pass";
		}
		
		assertEquals("pass", aResult);
	}

	@Then("the first player shall be selecting his\\/her first domino of the game")
	public void the_first_player_shall_be_selecting_his_her_first_domino_of_the_game() {
		Gameplay gameplay = KingdominoApplication.getStateMachine();
		GamestatusInitializing status = gameplay.getGamestatusInitializing();
		assertEquals(GamestatusInitializing.SelectingFirstDomino, status);
		

	}

	@Then("the second draft shall be on the table, face down")
	public void the_second_draft_shall_be_on_the_table_face_down() {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		DraftStatus nextDraftStatus = game.getNextDraft().getDraftStatus();

		assertEquals(DraftStatus.FaceDown, nextDraftStatus);

	}


	// HELPER METHODS
	private String getStatus(DraftStatus aStatus) {

		switch(aStatus) {
		
		case FaceDown:
			return "FaceDown";
		case Sorted:
			return "Sorted";
		case FaceUp:
			return "FaceUp";
		default:
			throw new java.lang.IllegalArgumentException("Invalid DraftStatus " + aStatus + ".");
			
		}
	}
	
	private void addDefaultUsersAndPlayers(Game game) {
		String[] userNames = { "User1", "User2", "User3", "User4" };
		for (int i = 0; i < userNames.length; i++) {
			User user = game.getKingdomino().addUser(userNames[i]);
			Player player = new Player(game);
			player.setUser(user);
			player.setColor(PlayerColor.values()[i]);
			Kingdom kingdom = new Kingdom(player);
			new Castle(0, 0, kingdom, player);
		}
	}

	private void createAllDominoes(Game game) {
		try {
			BufferedReader br = new BufferedReader(new FileReader("src/main/resources/alldominoes.dat"));
			String line = "";
			String delimiters = "[:\\+()]";
			while ((line = br.readLine()) != null) {
				String[] dominoString = line.split(delimiters); // {id, leftTerrain, rightTerrain, crowns}
				int dominoId = Integer.decode(dominoString[0]);
				TerrainType leftTerrain = getTerrainType(dominoString[1]);
				TerrainType rightTerrain = getTerrainType(dominoString[2]);
				int numCrown = 0;
				if (dominoString.length > 3) {
					numCrown = Integer.decode(dominoString[3]);
				}
				new Domino(dominoId, leftTerrain, rightTerrain, numCrown, game);
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
			throw new java.lang.IllegalArgumentException(
					"Error occured while trying to read alldominoes.dat: " + e.getMessage());
		}
	}

	private TerrainType getTerrainType(String terrain) {
		switch (terrain) {

		case "wheat":
			return TerrainType.WheatField;
		case "forest":
			return TerrainType.Forest;
		case "mountain":
			return TerrainType.Mountain;
		case "grass":
			return TerrainType.Grass;
		case "swamp":
			return TerrainType.Swamp;
		case "lake":
			return TerrainType.Lake;
		case "W":
			return TerrainType.WheatField;
		case "F":
			return TerrainType.Forest;
		case "M":
			return TerrainType.Mountain;
		case "G":
			return TerrainType.Grass;
		case "S":
			return TerrainType.Swamp;
		case "L":
			return TerrainType.Lake;
		default:
			throw new java.lang.IllegalArgumentException("Invalid terrain type: " + terrain);
		}
	}

	private Domino getdominoByID(int id) {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		for (Domino domino : game.getAllDominos()) {
			if (domino.getId() == id) {
				return domino;
			}
		}
		throw new java.lang.IllegalArgumentException("Domino with ID " + id + " not found.");
	}


}
