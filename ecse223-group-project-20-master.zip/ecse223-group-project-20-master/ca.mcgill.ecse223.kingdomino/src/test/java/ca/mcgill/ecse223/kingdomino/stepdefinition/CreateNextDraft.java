package ca.mcgill.ecse223.kingdomino.stepdefinition;

import static org.junit.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.logging.Logger;

import ca.mcgill.ecse223.kingdomino.controller.Controller;
import ca.mcgill.ecse223.kingdomino.controller.InvalidInputException;
import ca.mcgill.ecse223.kingdomino.KingdominoApplication;
import ca.mcgill.ecse223.kingdomino.model.BonusOption;
import ca.mcgill.ecse223.kingdomino.model.Castle;
import ca.mcgill.ecse223.kingdomino.model.Domino;
import ca.mcgill.ecse223.kingdomino.model.DominoInKingdom;
import ca.mcgill.ecse223.kingdomino.model.Domino.DominoStatus;
import ca.mcgill.ecse223.kingdomino.model.DominoInKingdom.DirectionKind;
import ca.mcgill.ecse223.kingdomino.model.Draft;
import ca.mcgill.ecse223.kingdomino.model.Draft.DraftStatus;
import ca.mcgill.ecse223.kingdomino.model.Game;
import ca.mcgill.ecse223.kingdomino.model.Kingdom;
import ca.mcgill.ecse223.kingdomino.model.Kingdomino;
import ca.mcgill.ecse223.kingdomino.model.Player;
import ca.mcgill.ecse223.kingdomino.model.Property;
import ca.mcgill.ecse223.kingdomino.model.Player.PlayerColor;
import ca.mcgill.ecse223.kingdomino.model.TerrainType;
import ca.mcgill.ecse223.kingdomino.model.User;
import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CreateNextDraft {
	@Given("the game is initialized to create next draft")
	public void the_game_is_initialized_to_create_next_draft() {
		// Initialize empty game
		Kingdomino kingdomino = new Kingdomino();
		Game game = new Game(48, kingdomino);
		game.setNumberOfPlayers(4);
		kingdomino.setCurrentGame(game);

		// Populate game
		addDefaultUsersAndPlayers(game);
		createAllDominoes(game);
		game.setNextPlayer(game.getPlayer(0));
		KingdominoApplication.setKingdomino(kingdomino);
	}

	@Given("there has been {int} drafts created")
	public void there_has_been_drafts_created(Integer int1) {
		int currNumDraft = int1;//Integer.parseInt(string);
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();

		// Populate the draft list with "previous" drafts
		for (int i = 0; i < currNumDraft; i++) {
			game.addAllDraft(new Draft(Draft.DraftStatus.Sorted, game));
		}
	}
	
	@Given("there is a current draft")
	public void there_is_a_current_draft() {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		Draft currentDraft = new Draft(DraftStatus.FaceUp, game);
		game.setCurrentDraft(currentDraft);
		game.addAllDraft(currentDraft);
	}

	@Given("there is a next draft")
	public void there_is_a_next_draft() {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		Draft nextDraft = new Draft(DraftStatus.FaceDown, game);
		game.setNextDraft(nextDraft);
		game.addAllDraft(nextDraft);
	}

	@Given("the top {int} dominoes in my pile have the IDs {string}")
	public void the_top_dominoes_in_my_pile_have_the_IDs(Integer int1, String string) {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
	
		List<String> tokenInt = getTokens(string);

		Domino topDomino1 = getdominoByID(Integer.parseInt(tokenInt.get(0))); // Finds the domino with ID int2
		Domino topDomino2 = getdominoByID(Integer.parseInt(tokenInt.get(1))); // Finds the domino with ID int3
		Domino topDomino3 = getdominoByID(Integer.parseInt(tokenInt.get(2))); // Finds the domino with ID int4
		Domino topDomino4 = getdominoByID(Integer.parseInt(tokenInt.get(3))); // Finds the domino with ID int5
		Domino topDomino5 = getdominoByID(Integer.parseInt(tokenInt.get(4))); // Finds the domino with ID int6
		
		topDomino1.setStatus(DominoStatus.InPile);
		topDomino2.setStatus(DominoStatus.InPile);
		topDomino3.setStatus(DominoStatus.InPile);
		topDomino4.setStatus(DominoStatus.InPile);
		topDomino5.setStatus(DominoStatus.InPile);

		game.setTopDominoInPile(topDomino1);
		topDomino1.setNextDomino(topDomino2);
		topDomino2.setNextDomino(topDomino3);
		topDomino3.setNextDomino(topDomino4);
		topDomino4.setNextDomino(topDomino5);
	}

	@When("create next draft is initiated")
	public void create_next_draft_is_initiated() {
		try {
			Controller.createNextDraft();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Then("a new draft is created from dominoes {string}")
	public void a_new_draft_is_created_from_dominoes(String string) {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		String actualListOfDominos = null;
		Draft nextDraft = game.getNextDraft();
		String expectedListOfDominos = string;
		
		Domino d1 = nextDraft.getIdUnsortedDominos().get(0);
		Domino d2 = nextDraft.getIdUnsortedDominos().get(1);
		Domino d3 = nextDraft.getIdUnsortedDominos().get(2);
		Domino d4 = nextDraft.getIdUnsortedDominos().get(3);
		
		actualListOfDominos = d1.getId()+","+ d2.getId()+","+ d3.getId()+","+ d4.getId();
		
		assertEquals(expectedListOfDominos, actualListOfDominos);
	
	}

	@Then("the next draft now has the dominoes {string}")
	public void the_next_draft_now_has_the_dominoes(String string) {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		String actualListOfDominos = null;
		Draft nextDraft = game.getNextDraft();
		String expectedListOfDominos = string;
		
		Domino d1 = nextDraft.getIdUnsortedDominos().get(0);
		Domino d2 = nextDraft.getIdUnsortedDominos().get(1);
		Domino d3 = nextDraft.getIdUnsortedDominos().get(2);
		Domino d4 = nextDraft.getIdUnsortedDominos().get(3);
		
		actualListOfDominos = d1.getId()+","+ d2.getId()+","+ d3.getId()+","+ d4.getId();
		
		assertEquals(expectedListOfDominos, actualListOfDominos);
	}

	@Then("the dominoes in the next draft are face down")
	public void the_dominoes_in_the_next_draft_are_face_down() {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		DraftStatus expectedDraftStatus = DraftStatus.FaceDown;
		DraftStatus actualDraftStatus = game.getNextDraft().getDraftStatus();
		assertEquals(expectedDraftStatus, actualDraftStatus);
	}
	
	@Then("the top domino of the pile is ID {int}")
	public void the_top_domino_of_the_pile_is_ID(Integer int1) {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		int expectedID = int1;//Integer.parseInt(string);
		int actualID = game.getTopDominoInPile().getId();
		assertEquals(expectedID, actualID);
	}

	@Then("the former next draft is now the current draft")
	public void the_former_next_draft_is_now_the_current_draft() {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		Draft expectedDraft = game.getCurrentDraft();
		Draft actualDraft = game.getNextDraft();
		assertEquals(expectedDraft, actualDraft);
	}
	
	@Given("this is a {int} player game")
	public void this_is_a_game(Integer int1) {
		int numPlayer = int1;//Integer.parseInt(string);
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		game.setNumberOfPlayers(numPlayer);
	}
	
	@Then("the pile is empty")
	public void the_pile_is_empty() {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		Domino actualTopDomino = game.getTopDominoInPile();
		Domino expectedTopDomino = null;
		assertEquals(expectedTopDomino, actualTopDomino);
	}

	@Then("there is no next draft")
	public void there_is_no_next_draft() {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		Draft actualDraft = game.getNextDraft();
		Draft expectedDraft = null;
		assertEquals(expectedDraft, actualDraft);
	}

	// HELPER METHODS
	public static List<String> getTokens(String str) {
		List<String> tokens = new ArrayList<>();
		StringTokenizer tokenizer = new StringTokenizer(str, ",");
		while (tokenizer.hasMoreElements()) {
			tokens.add(tokenizer.nextToken());
		}
		return tokens;
	}

	private void addDefaultUsersAndPlayers(Game game) {
		String[] userNames = { "User1", "User2", "User3", "User4" };
		for (int i = 0; i < userNames.length; i++) {
			User user = game.getKingdomino().addUser(userNames[i]);
			Player player = new Player(game);
			player.setUser(user);
			player.setColor(PlayerColor.values()[i]);
			Kingdom kingdom = new Kingdom(player);
			new Castle(0, 0, kingdom, player);
		}
	}

	private void createAllDominoes(Game game) {
		try {
			BufferedReader br = new BufferedReader(new FileReader("src/main/resources/alldominoes.dat"));
			String line = "";
			String delimiters = "[:\\+()]";
			while ((line = br.readLine()) != null) {
				String[] dominoString = line.split(delimiters); // {id, leftTerrain, rightTerrain, crowns}
				int dominoId = Integer.decode(dominoString[0]);
				TerrainType leftTerrain = getTerrainType(dominoString[1]);
				TerrainType rightTerrain = getTerrainType(dominoString[2]);
				int numCrown = 0;
				if (dominoString.length > 3) {
					numCrown = Integer.decode(dominoString[3]);
				}
				new Domino(dominoId, leftTerrain, rightTerrain, numCrown, game);
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
			throw new java.lang.IllegalArgumentException(
					"Error occured while trying to read alldominoes.dat: " + e.getMessage());
		}
	}

	private TerrainType getTerrainType(String terrain) {
		switch (terrain) {
		case "W":
			return TerrainType.WheatField;
		case "F":
			return TerrainType.Forest;
		case "M":
			return TerrainType.Mountain;
		case "G":
			return TerrainType.Grass;
		case "S":
			return TerrainType.Swamp;
		case "L":
			return TerrainType.Lake;
		default:
			throw new java.lang.IllegalArgumentException("Invalid terrain type: " + terrain);
		}
	}

	private DirectionKind getDirection(String dir) {
		switch (dir) {
		case "up":
			return DirectionKind.Up;
		case "down":
			return DirectionKind.Down;
		case "left":
			return DirectionKind.Left;
		case "right":
			return DirectionKind.Right;
		default:
			throw new java.lang.IllegalArgumentException("Invalid direction: " + dir);
		}
	}

	private Domino getdominoByID(int id) {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		for (Domino domino : game.getAllDominos()) {
			if (domino.getId() == id) {
				return domino;
			}
		}
		throw new java.lang.IllegalArgumentException("Domino with ID " + id + " not found.");
	}

	private DominoStatus getDominoStatus(String status) {
		switch (status) {
		case "inPile":
			return DominoStatus.InPile;
		case "excluded":
			return DominoStatus.Excluded;
		case "inCurrentDraft":
			return DominoStatus.InCurrentDraft;
		case "inNextDraft":
			return DominoStatus.InNextDraft;
		case "erroneouslyPreplaced":
			return DominoStatus.ErroneouslyPreplaced;
		case "correctlyPreplaced":
			return DominoStatus.CorrectlyPreplaced;
		case "placedInKingdom":
			return DominoStatus.PlacedInKingdom;
		case "discarded":
			return DominoStatus.Discarded;
		default:
			throw new java.lang.IllegalArgumentException("Invalid domino status: " + status);
		}
	}
}
