package ca.mcgill.ecse223.kingdomino.stepdefinition;

import ca.mcgill.ecse223.kingdomino.controller.Controller;

import static org.junit.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import ca.mcgill.ecse223.kingdomino.KingdominoApplication;
import ca.mcgill.ecse223.kingdomino.model.Castle;
import ca.mcgill.ecse223.kingdomino.model.Domino;
import ca.mcgill.ecse223.kingdomino.model.Domino.DominoStatus;
import ca.mcgill.ecse223.kingdomino.model.DominoInKingdom;
import ca.mcgill.ecse223.kingdomino.model.DominoInKingdom.DirectionKind;
import ca.mcgill.ecse223.kingdomino.model.Player.PlayerColor;
import ca.mcgill.ecse223.kingdomino.model.Game;
import ca.mcgill.ecse223.kingdomino.model.Kingdom;
import ca.mcgill.ecse223.kingdomino.model.KingdomTerritory;
import ca.mcgill.ecse223.kingdomino.model.Kingdomino;
import ca.mcgill.ecse223.kingdomino.model.Player;
import ca.mcgill.ecse223.kingdomino.model.TerrainType;
import ca.mcgill.ecse223.kingdomino.model.User;
import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class VerifyCastleAdjacency {
	
	boolean result;
	List<User> userList;
	int id;
	
	@Given("the game is initialized for castle adjacency")
	public void the_game_is_initialized_for_castle_adjacency() {
		// Intialize empty game
		Kingdomino kingdomino = new Kingdomino();
		Game game = new Game(48, kingdomino);
		game.setNumberOfPlayers(4);
		kingdomino.setCurrentGame(game);
		// Populate game
		addDefaultUsersAndPlayers(game);
		createAllDominoes(game);
		game.setNextPlayer(game.getPlayer(0));		 
		for(int i = 0; i < 4; i++) {
			 User user = game.getPlayer(i).getUser();
			//kingdomino.addUser(user);
		 }
		KingdominoApplication.setKingdomino(kingdomino);
	}

	@Given("the current player preplaced the domino with ID {int} at position {int}:{int} and direction {string}")
	public void the_current_player_preplaced_the_domino_with_ID_at_position_and_direction(Integer int1, Integer int2, Integer int3, String string) {
		Player player = KingdominoApplication.getKingdomino().getCurrentGame().getNextPlayer();
		List<Domino> dominos = KingdominoApplication.getKingdomino().getCurrentGame().getAllDominos();
		Domino domino = null;
		DirectionKind direction;
		id = int1;
		
		for(int i = 0; i< dominos.size(); i++) {
			if(int1 == dominos.get(i).getId()) domino = dominos.get(i);
		}
		
		if(string.equalsIgnoreCase("Up")) direction = DirectionKind.Up;
		else if(string.equalsIgnoreCase("Right")) direction = DirectionKind.Right;
		else if(string.equalsIgnoreCase("Down")) direction = DirectionKind.Down;
		else direction = DirectionKind.Left;
		
		domino.setStatus(DominoStatus.CorrectlyPreplaced);
		DominoInKingdom preplacedDomino = new DominoInKingdom(int2, int3, player.getKingdom(), domino);
		preplacedDomino.setDirection(direction);
		player.getKingdom().addTerritory(preplacedDomino);
	}

	@When("check castle adjacency is initiated")
	public void check_castle_adjacency_is_initiated() {
		KingdomTerritory a = null;
		Player player = KingdominoApplication.getKingdomino().getCurrentGame().getNextPlayer();
		
		for(int i = 0; i<player.getKingdom().getTerritories().size(); i++) {
			if(player.getKingdom().getTerritories().get(i) instanceof DominoInKingdom && ((DominoInKingdom) player.getKingdom().getTerritories().get(i)).getDomino().getId() == id ) {
				a = player.getKingdom().getTerritory(i);
				break;
			}
		}
		result = Controller.verifyCastleAdjacency((DominoInKingdom) a);
	}

	@Then("the castle\\/domino adjacency is {string}")
	public void the_castle_domino_adjacency_is(String string) {
		
	    if(string.equals("valid")) {
	    	assertEquals(true, result);
	    }
	    else if(string.equals("invalid")){
	    	assertEquals(false, result);
	    }
	}
	
	@After
	public void tearDown() {
		Kingdomino kingdomino = KingdominoApplication.getKingdomino();
		if (kingdomino != null) {
			kingdomino.delete();
		}
	}
	
	
	//HELPER METHODS-----------------------------------------------------------------------------------

	private void addDefaultUsersAndPlayers(Game game) {
		String[] userNames = { "User1", "User2", "User3", "User4" };
		userList = game.getKingdomino().getUsers();
		for(int j = 0; j < userNames.length; j++) {
			
			String name = userNames[j];
			Player player = new Player(game);
			player.setColor(PlayerColor.values()[j]);
			
			//associate a user to a player 
			if(userList.contains(userNames[j])) {
				User user = User.getWithName(userNames[j]);
				player.setUser(user);
			}else {
				User user = User.getWithName(userNames[j]);
				player.setUser(user);
				
				/*User user = new User(userNames[j], kingdomino);
				kingdomino.addUser(userNames[j]);
				player.setUser(user);
				*/
			}
			Kingdom kingdom = new Kingdom(player);
			new Castle(0, 0, kingdom, player);
		}
	}
	
	private void createAllDominoes(Game game) {
		try {
			BufferedReader br = new BufferedReader(new FileReader("src/main/resources/alldominoes.dat"));
			String line = "";
			String delimiters = "[:\\+()]";
			while ((line = br.readLine()) != null) {
				String[] dominoString = line.split(delimiters); // {id, leftTerrain, rightTerrain, crowns}
				int dominoId = Integer.decode(dominoString[0]);
				TerrainType leftTerrain = getTerrainType(dominoString[1]);
				TerrainType rightTerrain = getTerrainType(dominoString[2]);
				int numCrown = 0;
				if (dominoString.length > 3) {
					numCrown = Integer.decode(dominoString[3]);
				}
				new Domino(dominoId, leftTerrain, rightTerrain, numCrown, game);
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
			throw new java.lang.IllegalArgumentException(
					"Error occured while trying to read alldominoes.dat: " + e.getMessage());
		}
	}
	
	private TerrainType getTerrainType(String terrain) {
		switch (terrain) {
		case "W":
			return TerrainType.WheatField;
		case "F":
			return TerrainType.Forest;
		case "M":
			return TerrainType.Mountain;
		case "G":
			return TerrainType.Grass;
		case "S":
			return TerrainType.Swamp;
		case "L":
			return TerrainType.Lake;
		default:
			throw new java.lang.IllegalArgumentException("Invalid terrain type: " + terrain);
		}
	}
	
}
