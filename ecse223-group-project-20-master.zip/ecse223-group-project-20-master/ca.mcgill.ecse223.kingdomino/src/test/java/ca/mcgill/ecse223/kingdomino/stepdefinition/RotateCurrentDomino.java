package ca.mcgill.ecse223.kingdomino.stepdefinition;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import ca.mcgill.ecse223.kingdomino.KingdominoApplication;
import ca.mcgill.ecse223.kingdomino.controller.Controller;
import ca.mcgill.ecse223.kingdomino.controller.Controller.RotationKind;
import ca.mcgill.ecse223.kingdomino.model.Castle;
import ca.mcgill.ecse223.kingdomino.model.Domino;
import ca.mcgill.ecse223.kingdomino.model.Domino.DominoStatus;
import ca.mcgill.ecse223.kingdomino.model.DominoInKingdom;
import ca.mcgill.ecse223.kingdomino.model.DominoInKingdom.DirectionKind;
import ca.mcgill.ecse223.kingdomino.model.Game;
import ca.mcgill.ecse223.kingdomino.model.Kingdom;
import ca.mcgill.ecse223.kingdomino.model.KingdomTerritory;
import ca.mcgill.ecse223.kingdomino.model.Kingdomino;
import ca.mcgill.ecse223.kingdomino.model.Player;
import ca.mcgill.ecse223.kingdomino.model.Player.PlayerColor;
import ca.mcgill.ecse223.kingdomino.model.TerrainType;
import ca.mcgill.ecse223.kingdomino.model.User;
import io.cucumber.java.After;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class RotateCurrentDomino {

	private Player p1;
	DominoInKingdom dominoInKingdom1;
	Kingdomino kingdomino;

	List<User> userList;
	List<List<String>> userNames;

	List<String> names;
	private RotationKind rotationAction;

	@When("{string} requests to rotate the domino with {string}")
	public void requests_to_rotate_the_domino_with(String string, String string2) {
		// Write code here that turns the phrase above into concrete actions
		p1 = getPlayerByColor(string);
		rotationAction = getRotation(string2);
	}

	@Then("the domino {int} is still tentatively placed at {int}:{int} but with new direction {string}")
	public void the_domino_is_still_tentatively_placed_at_but_with_new_direction(Integer int1, Integer int2,
			Integer int3, String string) {
		// Write code here that turns the phrase above into concrete actions

		DominoInKingdom dominoInKingdom = getDominoInKingdomByID(int1);		
		Controller.rotateCurrentDomino(dominoInKingdom, rotationAction);

		assert (dominoInKingdom.getX() == int2);
		assert (dominoInKingdom.getY() == int3);
		assert (dominoInKingdom.getDirection() == getDirection(string));
	}

	@Then("the domino {int} should have status {string}")
	public void the_domino_should_have_status(Integer int1, String string) {
		// Write code here that turns the phrase above into concrete actions
		Domino d = getdominoByID(int1);
		assert (d.getStatus() == getDominoStatus(string));
	}

	@Then("domino {int} is tentatively placed at the same position {int}:{int} with the same direction {string}")
	public void domino_is_tentatively_placed_at_the_same_position_with_the_same_direction(Integer int1, Integer int2,
			Integer int3, String string) {

		DominoInKingdom dominoInKingdom = getDominoInKingdomByID(int1);
		assert (dominoInKingdom.getX() == int2);
		assert (dominoInKingdom.getY() == int3);
		assert (dominoInKingdom.getDirection() == getDirection(string));

	}

	@Then("domino {int} should still have status {string}")
	public void domino_should_still_have_status(Integer int1, String string) {
		// Write code here that turns the phrase above into concrete actions
		DominoInKingdom dominoInKingdom = getDominoInKingdomByID(int1);
		assert (dominoInKingdom.getDomino().getStatus() == getDominoStatus(string));
	}

	@After
	public void tearDown() {
		Kingdomino kingdomino = KingdominoApplication.getKingdomino();
		if (kingdomino != null) {
			kingdomino.delete();
			if (kingdomino.getCurrentGame() != null) {
				kingdomino.getCurrentGame().delete();
			}
		}
	}

	// helper
	public void createAllDominoes(Game game) {
		try {
			BufferedReader br = new BufferedReader(new FileReader("src/main/resources/alldominoes.dat"));
			String line = "";
			String delimiters = "[:\\+()]";
			while ((line = br.readLine()) != null) {
				String[] dominoString = line.split(delimiters); // {id, leftTerrain, rightTerrain, crowns}
				int dominoId = Integer.decode(dominoString[0]);
				TerrainType leftTerrain = getTerrainType(dominoString[1]);
				TerrainType rightTerrain = getTerrainType(dominoString[2]);
				int numCrown = 0;
				if (dominoString.length > 3) {
					numCrown = Integer.decode(dominoString[3]);
				}
				new Domino(dominoId, leftTerrain, rightTerrain, numCrown, game);
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
			throw new java.lang.IllegalArgumentException(
					"Error occured while trying to read alldominoes.dat: " + e.getMessage());
		}
	}

	public TerrainType getTerrainType(String terrain) {
		switch (terrain) {
		case "W":
			return TerrainType.WheatField;
		case "F":
			return TerrainType.Forest;
		case "M":
			return TerrainType.Mountain;
		case "G":
			return TerrainType.Grass;
		case "S":
			return TerrainType.Swamp;
		case "L":
			return TerrainType.Lake;
		default:
			throw new java.lang.IllegalArgumentException("Invalid terrain type: " + terrain);
		}
	}

//	public void addDefaultUsersAndPlayers(Game game) {
//		String[] userNames = { "User1", "User2", "User3", "User4" };
//		for (int i = 0; i < userNames.length; i++) {
//			User user = game.getKingdomino().addUser(userNames[i]);
//			Player player = new Player(game);
//			player.setUser(user);
//			player.setColor(PlayerColor.values()[i]);
//			Kingdom kingdom = new Kingdom(player);
//			new Castle(0, 0, kingdom, player);
//		}
//	}

	private void addDefaultUsersAndPlayers(Game game) {
		String[] userNames = { "User1", "User2", "User3", "User4" };
		userList = game.getKingdomino().getUsers();
		for (int j = 0; j < userNames.length; j++) {

			String name = userNames[j];
			Player player = new Player(game);
			player.setColor(PlayerColor.values()[j]);

			// associate a user to a player
			if (userList.contains(userNames[j])) {
				User user = User.getWithName(userNames[j]);
				player.setUser(user);
			} else {
				User user = User.getWithName(userNames[j]);
				player.setUser(user);

				/*
				 * User user = new User(userNames[j], kingdomino);
				 * kingdomino.addUser(userNames[j]); player.setUser(user);
				 */
			}
			Kingdom kingdom = new Kingdom(player);
			new Castle(0, 0, kingdom, player);
		}
	}

	/**
	 * @author Alexandra Gafencu
	 * @param name
	 * @return a Player
	 */
	public Player getPlayerByColor(String color) {
		Kingdomino kingDomino = KingdominoApplication.getKingdomino();
		Game game = kingDomino.getCurrentGame();

		for (Player player : game.getPlayers()) {
			if (player.getColor() == getColorType(color)) {
				return player;
			}
		}
		throw new java.lang.IllegalArgumentException("Player with name " + color + " not found.");
	}

	public PlayerColor getColorType(String color) {
		switch (color.toLowerCase()) {
		case "blue":
			return PlayerColor.Blue;
		case "green":
			return PlayerColor.Green;
		case "yellow":
			return PlayerColor.Yellow;
		case "pink":
			return PlayerColor.Pink;
		}
		return PlayerColor.Blue;
	}

	public Domino getdominoByID(int id) {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		for (Domino domino : game.getAllDominos()) {
			if (domino.getId() == id) {
				return domino;
			}
		}
		throw new java.lang.IllegalArgumentException("Domino with ID " + id + " not found.");
	}

	/**
	 * @author Alexandra Gafencu
	 * @param id
	 * @return a DominoInKindom
	 */
	private DominoInKingdom getDominoInKingdomByID(int id) {
		for (KingdomTerritory aDomino : p1.getKingdom().getTerritories()) {

			if (aDomino instanceof DominoInKingdom) {
				DominoInKingdom domInKingdom = (DominoInKingdom) aDomino;
				if (domInKingdom.getDomino().getId() == id) {
					return domInKingdom;
				}
			}
		}
		return null;

	}

	private Domino getDominoFromDraft(Integer int1) {
		for (Domino d : p1.getGame().getAllDominos()) {
			if (d.getId() == int1)
				return d;
		}
		return null;
	}

	public DirectionKind getDirection(String dir) {
		switch (dir) {
		case "up":
			return DirectionKind.Up;
		case "down":
			return DirectionKind.Down;
		case "left":
			return DirectionKind.Left;
		case "right":
			return DirectionKind.Right;
		default:
			throw new java.lang.IllegalArgumentException("Invalid direction: " + dir);
		}
	}

	public DominoStatus getDominoStatus(String status) {
		switch (status) {
		case "InPile":
			return DominoStatus.InPile;
		case "Excluded":
			return DominoStatus.Excluded;
		case "InCurrentDraft":
			return DominoStatus.InCurrentDraft;
		case "InNextDraft":
			return DominoStatus.InNextDraft;
		case "ErroneouslyPreplaced":
			return DominoStatus.ErroneouslyPreplaced;
		case "CorrectlyPreplaced":
			return DominoStatus.CorrectlyPreplaced;
		case "PlacedInKingdom":
			return DominoStatus.PlacedInKingdom;
		case "Discarded":
			return DominoStatus.Discarded;
		default:
			throw new java.lang.IllegalArgumentException("Invalid domino status: " + status);
		}
	}

	/**
	 * @author Alexandra Gafencu
	 * @param rot (rotation)
	 * @return a RotationKind
	 */
	public RotationKind getRotation(String rot) {
		switch (rot) {
		case "clockwise":
			return RotationKind.clockwise;
		case "counterclockwise":
			return RotationKind.counterclockwise;
		default:
			throw new java.lang.IllegalArgumentException("Invalid rotation: " + rot);
		}
	}

}