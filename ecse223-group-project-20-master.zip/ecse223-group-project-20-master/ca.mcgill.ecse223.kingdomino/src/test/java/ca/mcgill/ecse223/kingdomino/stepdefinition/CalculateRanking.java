package ca.mcgill.ecse223.kingdomino.stepdefinition;

import static org.junit.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import ca.mcgill.ecse223.kingdomino.KingdominoApplication;
import ca.mcgill.ecse223.kingdomino.controller.Controller;
import ca.mcgill.ecse223.kingdomino.controller.InvalidInputException;
import ca.mcgill.ecse223.kingdomino.model.Castle;
import ca.mcgill.ecse223.kingdomino.model.Domino;
import ca.mcgill.ecse223.kingdomino.model.DominoInKingdom;
import ca.mcgill.ecse223.kingdomino.model.Game;
import ca.mcgill.ecse223.kingdomino.model.Kingdom;
import ca.mcgill.ecse223.kingdomino.model.Kingdomino;
import ca.mcgill.ecse223.kingdomino.model.Player;
import ca.mcgill.ecse223.kingdomino.model.Player.PlayerColor;
import ca.mcgill.ecse223.kingdomino.model.TerrainType;
import ca.mcgill.ecse223.kingdomino.model.User;
import ca.mcgill.ecse223.kingdomino.model.Domino.DominoStatus;
import ca.mcgill.ecse223.kingdomino.model.DominoInKingdom.DirectionKind;
import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class CalculateRanking {
	
	/**
	 * F#23: Calculate ranking: As a player, I want the Kingdomino app to
	 * automatically calculate the ranking in order to know the winner of a finished
	 * game
	 * 
	 * @author Michael Buchar
	 */

	@Given("the game is initialized for calculate ranking")
	public void the_game_is_initialized_for_calculate_ranking() {
		// Write code here that turns the phrase above into concrete actions
		// Initialize empty game
		Kingdomino kingdomino = new Kingdomino();
		Game game = new Game(48, kingdomino);
		game.setNumberOfPlayers(4);
		kingdomino.setCurrentGame(game);
		// Populate game
		addDefaultUsersAndPlayers(game);
		createAllDominoes(game);
		game.setNextPlayer(game.getPlayer(0));
		KingdominoApplication.setKingdomino(kingdomino);
	}


	@Given("the players have the following two dominoes in their respective kingdoms:")
	public void the_players_have_the_following_two_dominoes_in_their_respective_kingdoms(io.cucumber.datatable.DataTable dataTable) {

		List<Map<String, String>> valueMaps = dataTable.asMaps(String.class, String.class);
		for (Map<String, String> map : valueMaps) {
			String color = map.get("player");
			Integer id1 = Integer.decode(map.get("domino1"));
			DirectionKind dir1 = getDirection(map.get("dominodir1"));
			Integer x1 = Integer.decode(map.get("posx1"));
			Integer y1 = Integer.decode(map.get("posy1"));
			Integer id2 = Integer.decode(map.get("domino2"));
			DirectionKind dir2 = getDirection(map.get("dominodir2"));
			Integer x2 = Integer.decode(map.get("posx2"));
			Integer y2 = Integer.decode(map.get("posy2"));

			Player player = getPlayerByColor(color);
			Kingdom kingdom = player.getKingdom();

			//Kingdom kingdom = getPlayerByColor(color).getKingdom();

			Domino domino1 = getdominoByID(id1);
			DominoInKingdom domino1InKingdom = new DominoInKingdom(x1, y1, kingdom, domino1);
			domino1InKingdom.setDirection((dir1));
			domino1.setStatus(DominoStatus.PlacedInKingdom);

			Domino domino2 = getdominoByID(id2);
			DominoInKingdom domino2InKingdom = new DominoInKingdom(x2, y2, kingdom, domino2);
			domino2InKingdom.setDirection((dir2));
			domino2.setStatus(DominoStatus.PlacedInKingdom);
		}
	} 

	@Given("the players have no tiebreak")
	public void the_players_have_no_tiebreak() {
		// doesn't matter to us, because it's the same as no tiebreak
		boolean noTieBreak = true;
	}

	@When("calculate ranking is initiated")
	public void calculate_ranking_is_initiated() {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		try {
			Controller.calculateRanking(game);
		} catch (InvalidInputException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	} 

	@Then("player standings shall be the followings:")
	public void player_standings_shall_be_the_followings(io.cucumber.datatable.DataTable dataTable) {

		List<Map<String, String>> valueMaps = dataTable.asMaps();
		for (Map<String, String> map : valueMaps) {
			// Get values from cucumber table
			String player = map.get("player");
			Integer rank = Integer.decode(map.get("standing"));

			assertEquals(rank, (Integer) getPlayerByColor(player).getCurrentRanking());
		}	

	}



	@After
	public void tearDown() {
		Kingdomino kingdomino = KingdominoApplication.getKingdomino();
		if (kingdomino != null) {
			kingdomino.delete();
		}
	}

	// HELPER METHODS
	private void addDefaultUsersAndPlayers(Game game) {
		String[] userNames = { "User1", "User2", "User3", "User4" };
		List<User> userList = game.getKingdomino().getUsers();
		for(int j = 0; j < userNames.length; j++) {

			String name = userNames[j];
			Player player = new Player(game);
			player.setColor(PlayerColor.values()[j]);

			//associate a user to a player 
			if(userList.contains(userNames[j])) {
				User user = User.getWithName(userNames[j]);
				player.setUser(user);
			}else {
				User user = User.getWithName(userNames[j]);
				player.setUser(user);

				/*User user = new User(userNames[j], kingdomino);
					kingdomino.addUser(userNames[j]);
					player.setUser(user);
				 */
			}
			Kingdom kingdom = new Kingdom(player);
			new Castle(0, 0, kingdom, player);
		}
	}


	private void createAllDominoes(Game game) {
		try {
			BufferedReader br = new BufferedReader(new FileReader("src/main/resources/alldominoes.dat"));
			String line = "";
			String delimiters = "[:\\+()]";
			while ((line = br.readLine()) != null) {
				String[] dominoString = line.split(delimiters); // {id, leftTerrain, rightTerrain, crowns}
				int dominoId = Integer.decode(dominoString[0]);
				TerrainType leftTerrain = getTerrainType(dominoString[1]);
				TerrainType rightTerrain = getTerrainType(dominoString[2]);
				int numCrown = 0;
				if (dominoString.length > 3) {
					numCrown = Integer.decode(dominoString[3]);
				}
				new Domino(dominoId, leftTerrain, rightTerrain, numCrown, game);
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
			throw new java.lang.IllegalArgumentException(
					"Error occured while trying to read alldominoes.dat: " + e.getMessage());
		}
	}

	private TerrainType getTerrainType(String terrain) {
		switch (terrain) {
		case "W":
			return TerrainType.WheatField;
		case "F":
			return TerrainType.Forest;
		case "M":
			return TerrainType.Mountain;
		case "G":
			return TerrainType.Grass;
		case "S":
			return TerrainType.Swamp;
		case "L":
			return TerrainType.Lake;
		default:
			throw new java.lang.IllegalArgumentException("Invalid terrain type: " + terrain);
		}
	}

	private DirectionKind getDirection(String dir) {
		switch (dir) {
		case "up":
			return DirectionKind.Up;
		case "down":
			return DirectionKind.Down;
		case "left":
			return DirectionKind.Left;
		case "right":
			return DirectionKind.Right;
		default:
			throw new java.lang.IllegalArgumentException("Invalid direction: " + dir);
		}
	}
	private Domino getdominoByID(int id) {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		for (Domino domino : game.getAllDominos()) {
			if (domino.getId() == id) {
				return domino;
			}
		}
		throw new java.lang.IllegalArgumentException("Domino with ID " + id + " not found.");
	}

	private Player getPlayerByColor(String s) {
		List<Player> currPlayers = KingdominoApplication.getKingdomino().getCurrentGame().getPlayers();
		PlayerColor c;
		switch(s) {
		case "pink":
			c = PlayerColor.Pink;
			break;
		case "blue":
			c = PlayerColor.Blue;
			break;
		case "green":
			c = PlayerColor.Green;
			break;
		case "yellow":
			c = PlayerColor.Yellow;
			break;
		default:
			return null;
		}
		for(Player p : currPlayers) {
			if(p.getColor().equals(c)) return p;
		}
		return null;
	}
}


