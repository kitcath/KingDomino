package ca.mcgill.ecse223.kingdomino.stepdefinition;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import ca.mcgill.ecse223.kingdomino.KingdominoApplication;
import ca.mcgill.ecse223.kingdomino.controller.Controller;
import ca.mcgill.ecse223.kingdomino.controller.InvalidInputException;
import ca.mcgill.ecse223.kingdomino.model.Castle;
import ca.mcgill.ecse223.kingdomino.model.Domino;
import ca.mcgill.ecse223.kingdomino.model.DominoInKingdom;
import ca.mcgill.ecse223.kingdomino.model.Game;
import ca.mcgill.ecse223.kingdomino.model.Kingdom;
import ca.mcgill.ecse223.kingdomino.model.KingdomTerritory;
import ca.mcgill.ecse223.kingdomino.model.Kingdomino;
import ca.mcgill.ecse223.kingdomino.model.Player;
import ca.mcgill.ecse223.kingdomino.model.TerrainType;
import ca.mcgill.ecse223.kingdomino.model.User;
import ca.mcgill.ecse223.kingdomino.model.Domino.DominoStatus;
import ca.mcgill.ecse223.kingdomino.model.DominoInKingdom.DirectionKind;
import ca.mcgill.ecse223.kingdomino.model.Draft;
import ca.mcgill.ecse223.kingdomino.model.Player.PlayerColor;
import ca.mcgill.ecse223.kingdomino.model.Property;
import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoadGame {
	private Kingdomino kingdomino;
	private boolean gameEnd = false;
	private List<Player> players;
	ArrayList<Domino> actualClaimedDominoes = null;
	ArrayList<Integer> expectedTilesByID = new ArrayList<Integer>();
	ArrayList<Domino> includedDominoes = new ArrayList<Domino>();
	ArrayList<Integer> includedDominoesByID = new ArrayList<Integer>();
	private Game game = null;
	String error = null;
	String dominoesByID = null;
	Player p1 = null;
	List<User> userList;


	@Given("the game is initialized for load game")
	public void the_game_is_initialized_for_load_game() {
		// Initialize empty game
		Kingdomino kingdomino = new Kingdomino();
		Game game = new Game(48, kingdomino);
		game.setNumberOfPlayers(4);
		kingdomino.setCurrentGame(game);

		// Populate game
		addDefaultUsersAndPlayers(game);
		createAllDominoes(game);
		game.setNextPlayer(game.getPlayer(0));
		for (int i = 0; i < game.getPlayers().size(); i++) {
			User user = game.getPlayer(i).getUser();

		}

		KingdominoApplication.setKingdomino(kingdomino);

	}

	@When("I initiate loading a saved game from {string}")
	public void i_initiate_loading_a_saved_game_from(String string) throws InvalidInputException {
		try {
			kingdomino = Controller.load(string);
			game = kingdomino.getCurrentGame();
		} catch (InvalidInputException e) {
			error = e.getMessage();
		}

	}

	@When("each tile placement is valid")
	public void each_tile_placement_is_valid() {
		
		 kingdomino = KingdominoApplication.getKingdomino();
		
		List<Player> players = kingdomino.getCurrentGame().getPlayers();
		//setting all dominoes of all properties in the kingdoms of all players to correctly placed (valid placement)
		for (Player player : players) {
			List<Property> properties = player.getKingdom().getProperties();
			for (int i = 0; i < properties.size(); i++) {
				List<Domino> dominoes = properties.get(i).getIncludedDominos();
				for (int j = 0; j < dominoes.size(); j++) {
					dominoes.get(j).setStatus(getDominoStatus("placedInKingdom"));
				}
			}
		}
	}

	@When("the game result is not yet final")
	public void the_game_result_is_not_yet_final() {
		game = kingdomino.getCurrentGame();
		gameEnd = (!game.hasNextPlayer());
		// game.hasNextDraft()
	}

	@Then("it shall be player {int}'s turn")
	public void it_shall_be_player_s_turn(Integer int1) {
		game = KingdominoApplication.getKingdomino().getCurrentGame();
		if(!gameEnd) {
			Player actualNextPlayer = game.getPlayer(int1-1);
			Player expectedPlayer = game.getPlayer(int1-1);
			assertEquals(expectedPlayer, actualNextPlayer);
		}
	}

	@Then("each of the players should have the corresponding tiles on their grid:")
	public void each_of_the_players_should_have_the_corresponding_tiles_on_their_grid(io.cucumber.datatable.DataTable dataTable) {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		players = game.getPlayers();

		List<Map<String, String>> valueMaps = dataTable.asMaps();
		for (Map<String, String> map : valueMaps) {
			// Get the expected Dominoes from cucumber table
			//searching for all the dominos in list of all dominos:
			Integer playerId = Integer.decode(map.get("playerNumber"));
			Player p1 = game.getPlayer(playerId-1); //player from the datatable
			ArrayList<Integer> expectedTilesByID = new ArrayList<Integer>();

			dominoesByID = map.get("p" + playerId + "tiles");
			String[] splitString = dominoesByID.split(",", 0);
			for(int i =0; i<splitString.length; i++) {
				for(int j =0; j<game.getAllDominos().size(); j+=1) {
					if(game.getAllDominos().get(j).getId() == (int) Integer.parseInt(splitString[i])) {
						expectedTilesByID.add(game.getAllDominos().get(j).getId());
					}
				}
			}

			expectedTilesByID.sort(Comparator.naturalOrder()); // rearrange the list of IDs in the right order (if it's not the case already)

			//find the Actual Included Dominoes

			List<Property> properties = p1.getKingdom().getProperties();
			for (int j = 0; j < properties.size(); j++) {
				Property property = properties.get(j);
				for (int i = 0; i < property.getSize(); i++) {
					ArrayList<Domino> occupiedDominoes = (ArrayList<Domino>) property.getIncludedDominos();
					for (int k = 0; i< occupiedDominoes.size(); k++) {
						includedDominoes.add(occupiedDominoes.get(k));
					}
				}
			}

			//list of all actual included dominoes by ID
			for (int i = 0; i < includedDominoes.size(); i++) {
				includedDominoesByID.add(includedDominoes.get(i).getId());
			}
			includedDominoesByID.sort(Comparator.naturalOrder()); // rearrange the list of IDs in the right order (if it's not the case already)

			//compare the expected to actual tiles on the player's grid
			for (int i = 0; i < expectedTilesByID.size(); i++) {
				assertEquals(expectedTilesByID.get(i), includedDominoesByID.get(i));
			}

		}

	}

	@Then("each of the players should have claimed the corresponding tiles:")
	public void each_of_the_players_should_have_claimed_the_corresponding_tiles(io.cucumber.datatable.DataTable dataTable) {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		players = game.getPlayers();
		List<Map<String, String>> valueMaps = dataTable.asMaps();
		for (Map<String, String> map : valueMaps) {
			// Get the expected Dominoes from cucumber table
			Integer playerID = Integer.decode(map.get("player"));
			p1 = game.getPlayer(playerID);
			Domino actualClaimedDomino = p1.getDominoSelection().getDomino();
			int actualClaimedDominoId = actualClaimedDomino.getId();

			actualClaimedDominoes.add(actualClaimedDomino);


			//Expected claimed domino
			Integer claimedTileId = Integer.decode(map.get("p" + playerID + "claimed"));

			//asserting right domino selection after loading the game
			assertEquals(claimedTileId, actualClaimedDominoId);
		}
	}

	@Then("tiles {string} shall be unclaimed on the board")
	public void tiles_shall_be_unclaimed_on_the_board(String string) {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		players = game.getPlayers();
		ArrayList<Integer> expectedUnclaimedDominoesById = new ArrayList<Integer>();

		String[] splitString = string.split(",", 0);
		for(int i =0; i<splitString.length; i++) {
			for(int j =0; j<game.getAllDominos().size(); j+=1) {
				if(game.getAllDominos().get(j).getId() == (int) Integer.parseInt(splitString[i])) {
					expectedUnclaimedDominoesById.add(game.getAllDominos().get(j).getId());
				}
			}
		}
		expectedUnclaimedDominoesById.sort(Comparator.naturalOrder()); // rearrange the list of IDs in the right order (if it's not the case already)

		
		
		//Find actually unclaimed dominoes in the drafts
		ArrayList<Integer> actualUnclaimedDominoesById = new ArrayList<Integer>();

		for (Domino domino : game.getAllDominos()) {
			for (Domino someDomino : actualClaimedDominoes) {
				if(someDomino != null) {
					if(domino.getStatus().equals(getDominoStatus("inCurrentDraft")) 
							|| domino.getStatus().equals(getDominoStatus("inNextDraft"))
							&& !domino.equals(someDomino)) {
						actualUnclaimedDominoesById.add(domino.getId()); 
					}
				}
			}
		}
		actualUnclaimedDominoesById.sort(Comparator.naturalOrder()); // rearrange the list of IDs in the right order (if it's not the case already)

		// compare both
		for (int i = 0; i < expectedUnclaimedDominoesById.size(); i++) {
			assertEquals(expectedUnclaimedDominoesById.get(i), actualUnclaimedDominoesById.get(i));
		}
	}

	@Then("the game shall become ready to start")
	public void the_game_shall_become_ready_to_start() {
		assertEquals(true, !gameEnd);
	}


	@Then("the game shall notify the user that the loaded game is invalid")
	  public void the_game_shall_notify_the_user_that_the_loaded_game_is_invalid() {
		assertEquals("The Game File Is Invalid", error);
	}

	@After
	public void tearDown() {
		Kingdomino kingdomino = KingdominoApplication.getKingdomino();
		if (kingdomino != null) {
			kingdomino.delete();
		}
	}


	///////////////////////////////////////
	/// -----Private Helper Methods---- ///
	///////////////////////////////////////

	private void addDefaultUsersAndPlayers(Game game) {
		String[] userNames = { "User1", "User2", "User3", "User4" };
		userList = game.getKingdomino().getUsers();
		for (int j = 0; j < userNames.length; j++) {

			String name = userNames[j];
			Player player = new Player(game);
			player.setColor(PlayerColor.values()[j]);

			// associate a user to a player
			if (userList.contains(userNames[j])) {
				User user = User.getWithName(userNames[j]);
				player.setUser(user);
			} else {
				User user = User.getWithName(userNames[j]);
				player.setUser(user);
			}
			Kingdom kingdom = new Kingdom(player);
			new Castle(0, 0, kingdom, player);
		}
	}

	private void createAllDominoes(Game game) {
		try {
			BufferedReader br = new BufferedReader(new FileReader("src/main/resources/alldominoes.dat"));
			String line = "";
			String delimiters = "[:\\+()]";
			while ((line = br.readLine()) != null) {
				String[] dominoString = line.split(delimiters); // {id, leftTerrain, rightTerrain, crowns}
				int dominoId = Integer.decode(dominoString[0]);
				TerrainType leftTerrain = getTerrainType(dominoString[1]);
				TerrainType rightTerrain = getTerrainType(dominoString[2]);
				int numCrown = 0;
				if (dominoString.length > 3) {
					numCrown = Integer.decode(dominoString[3]);
				}
				new Domino(dominoId, leftTerrain, rightTerrain, numCrown, game);
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
			throw new java.lang.IllegalArgumentException(
					"Error occured while trying to read alldominoes.dat: " + e.getMessage());
		}
	}

	private Domino getdominoByID(int id) {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		for (Domino domino : game.getAllDominos()) {
			if (domino.getId() == id) {
				return domino;
			}
		}
		throw new java.lang.IllegalArgumentException("Domino with ID " + id + " not found.");
	}

	private TerrainType getTerrainType(String terrain) {
		switch (terrain) {
		case "W":
			return TerrainType.WheatField;
		case "F":
			return TerrainType.Forest;
		case "M":
			return TerrainType.Mountain;
		case "G":
			return TerrainType.Grass;
		case "S":
			return TerrainType.Swamp;
		case "L":
			return TerrainType.Lake;
		default:
			throw new java.lang.IllegalArgumentException("Invalid terrain type: " + terrain);
		}
	}

	private DirectionKind getDirection(String dir) {
		switch (dir) {
		case "up":
			return DirectionKind.Up;
		case "down":
			return DirectionKind.Down;
		case "left":
			return DirectionKind.Left;
		case "right":
			return DirectionKind.Right;
		default:
			throw new java.lang.IllegalArgumentException("Invalid direction: " + dir);
		}
	}

	private DominoStatus getDominoStatus(String status) {
		switch (status) {
		case "inPile":
			return DominoStatus.InPile;
		case "excluded":
			return DominoStatus.Excluded;
		case "inCurrentDraft":
			return DominoStatus.InCurrentDraft;
		case "inNextDraft":
			return DominoStatus.InNextDraft;
		case "erroneouslyPreplaced":
			return DominoStatus.ErroneouslyPreplaced;
		case "correctlyPreplaced":
			return DominoStatus.CorrectlyPreplaced;
		case "placedInKingdom":
			return DominoStatus.PlacedInKingdom;
		case "discarded":
			return DominoStatus.Discarded;
		default:
			throw new java.lang.IllegalArgumentException("Invalid domino status: " + status);
		}
	}
}
