package ca.mcgill.ecse223.kingdomino.stepdefinition;

import static org.junit.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import ca.mcgill.ecse223.kingdomino.KingdominoApplication;
import ca.mcgill.ecse223.kingdomino.controller.InvalidInputException;
import ca.mcgill.ecse223.kingdomino.model.Gameplay;
import ca.mcgill.ecse223.kingdomino.model.BonusOption;
import ca.mcgill.ecse223.kingdomino.model.Castle;
import ca.mcgill.ecse223.kingdomino.model.Domino;
import ca.mcgill.ecse223.kingdomino.model.Domino.DominoStatus;
import ca.mcgill.ecse223.kingdomino.model.DominoInKingdom;
import ca.mcgill.ecse223.kingdomino.model.DominoInKingdom.DirectionKind;
import ca.mcgill.ecse223.kingdomino.model.Game;
import ca.mcgill.ecse223.kingdomino.model.Kingdom;
import ca.mcgill.ecse223.kingdomino.model.KingdomTerritory;
import ca.mcgill.ecse223.kingdomino.model.Kingdomino;
import ca.mcgill.ecse223.kingdomino.model.Player;
import ca.mcgill.ecse223.kingdomino.model.Player.PlayerColor;
import ca.mcgill.ecse223.kingdomino.model.Property;
import ca.mcgill.ecse223.kingdomino.model.TerrainType;
import ca.mcgill.ecse223.kingdomino.model.User;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import java.util.*;

public class CalculatingPlayerScore {
	List<User> userList ;
	Game game;
	Player currentPlayer;
	Kingdom currentKingdom;
	DominoInKingdom preplacedDomino;
	Domino selectedDomino;
	Domino anotherDomino;
	Integer currentScore;
	
 	@Given("the game is initialized for calculating player score")
	public void the_game_is_initialized_for_calculating_player_score() {
		Kingdomino kingdomino = new Kingdomino();
		game = new Game(48, kingdomino);
		game.setNumberOfPlayers(4);
		kingdomino.setCurrentGame(game);
				
		// Populate game
		 addDefaultUsersAndPlayers(game);
		 createAllDominoes(game);
		 game.setNextPlayer(game.getPlayer(0));
		 for(int i = 0; i < game.getPlayers().size(); i++) {
			User user = game.getPlayer(i).getUser();
			game.getPlayer(i).setPropertyScore(0);
			game.getPlayer(i).setBonusScore(0);
				 
		 }
			
		KingdominoApplication.setKingdomino(kingdomino);
	}

	@Given("the current player has no dominoes in his\\/her kingdom yet")
	public void the_current_player_has_no_dominoes_in_his_her_kingdom_yet() {
	    currentPlayer = game.getPlayer(0);
	    List<KingdomTerritory> currentTerritories = currentPlayer.getKingdom().getTerritories();
	    List<Property> currentProperties = currentPlayer.getKingdom().getProperties();
	    
	    if(currentTerritories.size() == 1 && currentProperties.size() == 0) {
	    	return;
	    }else {
	    	int propertySize = currentProperties.size();
	    	int territorySize = currentTerritories.size();
	    	for(int i = 0; i < currentProperties.size(); i ++) {
	    		Property aProperty = currentProperties.get(i);
	    		aProperty.delete();
	    	}
	    	for(int j = 1; j < territorySize; j++) {
	    		KingdomTerritory aTerritory = currentTerritories.get(j);
	    		aTerritory.delete();
	    	}
	    }
	}

	@Given("the score of the current player is {int}")
	public void the_score_of_the_current_player_is(Integer int1) {
		currentPlayer = game.getPlayer(0);
		currentPlayer.setPropertyScore(int1);
	   
	}

	@Given("the current player is preplacing his\\/her domino with ID {int} at location {int}:{int} with direction {string}")
	public void the_current_player_is_preplacing_his_her_domino_with_ID_at_location_with_direction(Integer int1, Integer int2, Integer int3, String string) {
		currentKingdom = game.getPlayer(0).getKingdom();
		selectedDomino = getdominoByID(int1);
		preplacedDomino = new DominoInKingdom(int2, int3,currentKingdom, selectedDomino);
		DirectionKind direction = getDirection(string);
		preplacedDomino.setDirection(direction);
	}

	@Given("the preplaced domino has the status {string}")
	public void the_preplaced_domino_has_the_status(String string) {
	   DominoStatus preplacedStatus = getStatus(string);
	   selectedDomino.setStatus(DominoStatus.CorrectlyPreplaced);
	}

	@When("the current player places his\\/her domino")
	public void the_current_player_places_his_her_domino() throws InvalidInputException {
		currentPlayer = game.getPlayer(0);
		try {
			currentScore = Gameplay.calculatePlayerScore(currentPlayer);
		} catch (InvalidInputException e) {
			throw new InvalidInputException("no such player in current game");
		}
	}

	@Then("the score of the current player shall be {int}")
	public void the_score_of_the_current_player_shall_be(Integer int1) {
	   assertEquals(int1, currentScore);
	}

	@Given("the game has no bonus options selected")
	public void the_game_has_no_bonus_options_selected() {
	   boolean hasBonusOptions = game.hasSelectedBonusOptions();
	   if (hasBonusOptions == false) {
		   return;
	   }else {
		  List<BonusOption> bonusOptions = game.getSelectedBonusOptions();
		   for(int i = 0; i < bonusOptions.size(); i++ ) {
			   BonusOption selectedOption = bonusOptions.get(i);
			   selectedOption.delete();
		   }
	   }
	}

	@Given("the current player is placing his\\/her domino with ID {int}")
	public void the_current_player_is_placing_his_her_domino_with_ID(Integer int1) throws InvalidInputException{
	    anotherDomino = getdominoByID(int1);
	    currentPlayer = game.getPlayer(0);
	    try {
			 currentScore = Gameplay.calculatePlayerScore(currentPlayer);
		} catch (InvalidInputException e) {
			throw new InvalidInputException("no such player in current game");
		}
	}

	@Given("it is impossible to place the current domino in his\\/her kingdom")
	public void it_is_impossible_to_place_the_current_domino_in_his_her_kingdom() {
	   anotherDomino.setStatus(DominoStatus.ErroneouslyPreplaced);
	  
	}

	@When("the current player discards his\\/her domino")
	public void the_current_player_discards_his_her_domino() throws InvalidInputException {
	    anotherDomino.setStatus(DominoStatus.Discarded);
	  
	    
	}
	
	
						//-------------------------------------------
						// 		PRIVATE HELPER METHODS
						//-------------------------------------------
	private void addDefaultUsersAndPlayers(Game game) {
		String[] userNames = { "User1", "User2", "User3", "User4" };
		userList = game.getKingdomino().getUsers();
		for(int j = 0; j < userNames.length; j++) {
			
			String name = userNames[j];
			Player player = new Player(game);
			player.setColor(PlayerColor.values()[j]);
			
			//associate a user to a player 
			if(userList.contains(userNames[j])) {
				User user = User.getWithName(userNames[j]);
				player.setUser(user);
			}else {
				User user = User.getWithName(userNames[j]);
				player.setUser(user);
				
				/*User user = new User(userNames[j], kingdomino);
				kingdomino.addUser(userNames[j]);
				player.setUser(user);
				*/
			}
			Kingdom kingdom = new Kingdom(player);
			new Castle(0, 0, kingdom, player);
		}
	}

	public Domino getdominoByID(int id) {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		for (Domino domino : game.getAllDominos()) {
			if (domino.getId() == id) {
				return domino;
			}
		}
		throw new java.lang.IllegalArgumentException("Domino with ID " + id + " not found.");
	}

	private void createAllDominoes(Game game) {
		try {
			BufferedReader br = new BufferedReader(new FileReader("src/main/resources/alldominoes.dat"));
			String line = "";
			String delimiters = "[:\\+()]";
			while ((line = br.readLine()) != null) {
				String[] dominoString = line.split(delimiters); // {id, leftTerrain, rightTerrain, crowns}
				int dominoId = Integer.decode(dominoString[0]);
				TerrainType leftTerrain = getTerrainType(dominoString[1]);
				TerrainType rightTerrain = getTerrainType(dominoString[2]);
				int numCrown = 0;
				if (dominoString.length > 3) {
					numCrown = Integer.decode(dominoString[3]);
				}
				new Domino(dominoId, leftTerrain, rightTerrain, numCrown, game);
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
			throw new java.lang.IllegalArgumentException(
					"Error occured while trying to read alldominoes.dat: " + e.getMessage());
		}
}
	private TerrainType getTerrainType(String terrain) {
		switch (terrain) {
		case "W":
			return TerrainType.WheatField;
		case "F":
			return TerrainType.Forest;
		case "M":
			return TerrainType.Mountain;
		case "G":
			return TerrainType.Grass;
		case "S":
			return TerrainType.Swamp;
		case "L":
			return TerrainType.Lake;
		default:
			throw new java.lang.IllegalArgumentException("Invalid terrain type: " + terrain);
		}
	}
	public DominoStatus getStatus(String status) {
		switch(status) {
		case "CorrectlyPreplaced":
			return DominoStatus.CorrectlyPreplaced;
		case "Excluded":
			return DominoStatus.Excluded;
		case "InPile":
			return DominoStatus.InPile;
		case "InNextDraft":
			return DominoStatus.InNextDraft;
		case "InCurrentDraft":
			return DominoStatus.InCurrentDraft;
		case "ErroneouslyPreplaced":
			return DominoStatus.ErroneouslyPreplaced;
		case "PlacedInKingdom":
			return DominoStatus.PlacedInKingdom;
		case "Discarded":
			return DominoStatus.Discarded;
		default:
			throw new java.lang.IllegalArgumentException("Invalid status: " + status);
		
		}
		
		//Excluded, InPile, InNextDraft, InCurrentDraft, CorrectlyPreplaced, ErroneouslyPreplaced, PlacedInKingdom, Discarded 
	}
	public DirectionKind getDirection(String dir) {
		switch (dir) {
		case "up":
			return DirectionKind.Up;
		case "down":
			return DirectionKind.Down;
		case "left":
			return DirectionKind.Left;
		case "right":
			return DirectionKind.Right;
		default:
			throw new java.lang.IllegalArgumentException("Invalid direction: " + dir);
		}
	}

}