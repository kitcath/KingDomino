package ca.mcgill.ecse223.kingdomino.stepdefinition;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import ca.mcgill.ecse223.kingdomino.KingdominoApplication;
import ca.mcgill.ecse223.kingdomino.controller.Controller;
import ca.mcgill.ecse223.kingdomino.controller.InvalidInputException;
import ca.mcgill.ecse223.kingdomino.model.Castle;
import ca.mcgill.ecse223.kingdomino.model.Domino;
import ca.mcgill.ecse223.kingdomino.model.DominoSelection;
import ca.mcgill.ecse223.kingdomino.model.Game;
import ca.mcgill.ecse223.kingdomino.model.Kingdom;
import ca.mcgill.ecse223.kingdomino.model.Kingdomino;
import ca.mcgill.ecse223.kingdomino.model.Player;
import ca.mcgill.ecse223.kingdomino.model.TerrainType;
import ca.mcgill.ecse223.kingdomino.model.User;
import ca.mcgill.ecse223.kingdomino.model.Domino.DominoStatus;
import ca.mcgill.ecse223.kingdomino.model.DominoInKingdom.DirectionKind;
import ca.mcgill.ecse223.kingdomino.model.Draft;
import ca.mcgill.ecse223.kingdomino.model.Draft.DraftStatus;
import ca.mcgill.ecse223.kingdomino.model.Player.PlayerColor;
import io.cucumber.java.en.*;

public class ChooseNextDomino {

	/**
	 * F#10: Choose next domino: As a player, I wish to be able to choose a
	 * designated domino from the next draft assuming that this domino has not yet
	 * been chosen by any other players.
	 * 
	 * @author Michael Buchar
	 */


	@Given("the game is initialized for choose next domino")
	public void the_game_is_initialized_for_choose_next_domino() {
		// Write code here that turns the phrase above into concrete actions
		Kingdomino kingdomino = new Kingdomino();
		Game game = new Game(48, kingdomino);
		game.setNumberOfPlayers(4);
		kingdomino.setCurrentGame(game);
		// Populate game
		addDefaultUsersAndPlayers(game);
		createAllDominoes(game);
		game.setNextPlayer(game.getPlayer(0));
		KingdominoApplication.setKingdomino(kingdomino);
		//throw new cucumber.api.PendingException();
	}

	@Given("the next draft is sorted with dominoes {string}")
	public void the_next_draft_is_sorted_with_dominoes(String string) {
		
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		String[] idAsString = string.split(",");
		Domino[] fourDominos = new Domino[idAsString.length];
		for (int i = 0; i < fourDominos.length; i++) {
			Domino domino = getdominoByID(Integer.parseInt(idAsString[i]));
			fourDominos[i] = domino;
		}
		Draft nextDraft = new Draft(DraftStatus.Sorted, game);
		nextDraft.setIdSortedDominos(fourDominos);
		game.setNextDraft(nextDraft);
		//throw new cucumber.api.PendingException();
	}

	@Given("player's domino selection {string}")
	public void player_s_domino_selection(String string) {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		Draft nextDraft = game.getNextDraft();
		String[] selection = string.split("(,\\s*)");
		for(int i = 0; i < selection.length; i++) {
			if (!selection[i].equals("none")) {
				DominoSelection selectionToAdd = new DominoSelection(getPlayerByColor(selection[i]), nextDraft.getIdSortedDomino(i), nextDraft);
				nextDraft.addSelection(selectionToAdd);
			}
		}

		
	}

	@Given("the current player is {string}")
	public void the_current_player_is(String string) {
		// Write code here that turns the phrase above into concrete actions
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		game.setNextPlayer(getPlayerByColor(string));
		//throw new cucumber.api.PendingException();
	}

	@When("current player chooses to place king on {string}")
	public void current_player_chooses_to_place_king_on(String string) {
		// Write code here that turns the phrase above into concrete actions
		//CHECK IF CHOICE IS VALID IN THIS METHOD!
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
//		for(DominoSelection existingChoices: game.getNextDraft().getSelections()) {
//			if (existingChoices.getDomino().getId() == chosenDomioID) {
//				System.out.println("This Domino is already chosen.");
//				return;
//			}
//		}
//		game.getNextDraft().addSelection(game.getNextPlayer(), getdominoByID(chosenDomioID));
		int chosenDominoID = Integer.parseInt(string);
		Domino selectedDomino = getdominoByID(chosenDominoID);
		try {
			Controller.chooseNextDomino(game.getNextDraft(),game.getNextPlayer(), selectedDomino);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//throw new cucumber.api.PendingException();
	}

	@Then("current player king now is on {string}")
	public void current_player_king_now_is_on(String string) {
		// Write code here that turns the phrase above into concrete actions
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		int chosenDominoID = Integer.parseInt(string);
		DominoSelection addedSelection = null;
		List<DominoSelection> updatedSelections = game.getNextDraft().getSelections();
		for (DominoSelection selection: updatedSelections) {
			if (selection.getDomino().getId() == chosenDominoID) {
				addedSelection = selection;
			}
		}
		assertEquals(game.getNextPlayer().getColor(), addedSelection.getPlayer().getColor());
		//throw new cucumber.api.PendingException();
	}

	@Then("the selection for next draft is now equal to {string}")
	public void the_selection_for_next_draft_is_now_equal_to(String string) {
		// Write code here that turns the phrase above into concrete actions
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		Draft nextDraft = game.getNextDraft();
		String[] selection = string.split("(,\\s*)");
		ArrayList<String> expected = new ArrayList<String>();
		ArrayList<String> expected2 = new ArrayList<String>();
		for (int i = 0; i < selection.length; i++) {
			if(!selection[i].equals("none")) {
				expected.add(selection[i]);
			}
			expected2.add(selection[i]);
		}
		assertEquals(expected.size(), nextDraft.getSelections().size());

		List<DominoSelection> actualSelections = nextDraft.getSelections();

		for (DominoSelection selections: actualSelections) {
			if(selections.getPlayer().getColor().equals(PlayerColor.Blue)) {
				Domino actualSelected = selections.getDomino();
				int nthDomino = expected2.indexOf("blue");
				Domino chosen = nextDraft.getIdSortedDomino(nthDomino);
				assertEquals(chosen.getId(), actualSelected.getId());
			}
			else if(selections.getPlayer().getColor().equals(PlayerColor.Green)) {
				Domino actualSelected = selections.getDomino();
				int nthDomino = expected2.indexOf("green");
				Domino chosen = nextDraft.getIdSortedDomino(nthDomino);
				assertEquals(chosen.getId(), actualSelected.getId());
			}
			else if(selections.getPlayer().getColor().equals(PlayerColor.Yellow)) {
				Domino actualSelected = selections.getDomino();
				int nthDomino = expected2.indexOf("yellow");
				Domino chosen = nextDraft.getIdSortedDomino(nthDomino);
				assertEquals(chosen.getId(), actualSelected.getId());
			}
			else if(selections.getPlayer().getColor().equals(PlayerColor.Pink)) {
				Domino actualSelected = selections.getDomino();
				int nthDomino = expected2.indexOf("pink");
				Domino chosen = nextDraft.getIdSortedDomino(nthDomino);
				assertEquals(chosen.getId(), actualSelected.getId());
			}
		}
		//throw new cucumber.api.PendingException();
	}

	@Then("the selection for the next draft selection is still {string}")
	public void the_selection_for_the_next_draft_selection_is_still(String string) {
		// Write code here that turns the phrase above into concrete actions
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		Draft nextDraft = game.getNextDraft();
		String[] selection = string.split("(,\\s*)");
		ArrayList<String> expected = new ArrayList<String>();
		ArrayList<String> expected2 = new ArrayList<String>();
		for (int i = 0; i < selection.length; i++) {
			if(!selection[i].equals("none")) {
				expected.add(selection[i]);
			}
			expected2.add(selection[i]);
		}
		assertEquals(expected.size(), nextDraft.getSelections().size());

		List<DominoSelection> actualSelections = nextDraft.getSelections();

		for (DominoSelection selections: actualSelections) {
			if(selections.getPlayer().getColor().equals(PlayerColor.Blue)) {
				Domino actualSelected = selections.getDomino();
				int nthDomino = expected2.indexOf("blue");
				Domino chosen = nextDraft.getIdSortedDomino(nthDomino);
				assertEquals(chosen.getId(), actualSelected.getId());
			}
			else if(selections.getPlayer().getColor().equals(PlayerColor.Green)) {
				Domino actualSelected = selections.getDomino();
				int nthDomino = expected2.indexOf("green");
				Domino chosen = nextDraft.getIdSortedDomino(nthDomino);
				assertEquals(chosen.getId(), actualSelected.getId());
			}
			else if(selections.getPlayer().getColor().equals(PlayerColor.Yellow)) {
				Domino actualSelected = selections.getDomino();
				int nthDomino = expected2.indexOf("yellow");
				Domino chosen = nextDraft.getIdSortedDomino(nthDomino);
				assertEquals(chosen.getId(), actualSelected.getId());
			}
			else if(selections.getPlayer().getColor().equals(PlayerColor.Pink)) {
				Domino actualSelected = selections.getDomino();
				int nthDomino = expected2.indexOf("pink");
				Domino chosen = nextDraft.getIdSortedDomino(nthDomino);
				assertEquals(chosen.getId(), actualSelected.getId());
			}
		}
		//throw new cucumber.api.PendingException();
	}


	// private helper methods
	private void addDefaultUsersAndPlayers(Game game) {
		String[] userNames = { "User1", "User2", "User3", "User4" };
		for (int i = 0; i < userNames.length; i++) {
			User user = game.getKingdomino().addUser(userNames[i]);
			Player player = new Player(game);
			player.setUser(user);
			player.setColor(PlayerColor.values()[i]);
			Kingdom kingdom = new Kingdom(player);
			new Castle(0, 0, kingdom, player);
		}
	}

	private void createAllDominoes(Game game) {
		try {
			BufferedReader br = new BufferedReader(new FileReader("src/main/resources/alldominoes.dat"));
			String line = "";
			String delimiters = "[:\\+()]";
			while ((line = br.readLine()) != null) {
				String[] dominoString = line.split(delimiters); // {id, leftTerrain, rightTerrain, crowns}
				int dominoId = Integer.decode(dominoString[0]);
				TerrainType leftTerrain = getTerrainType(dominoString[1]);
				TerrainType rightTerrain = getTerrainType(dominoString[2]);
				int numCrown = 0;
				if (dominoString.length > 3) {
					numCrown = Integer.decode(dominoString[3]);
				}
				new Domino(dominoId, leftTerrain, rightTerrain, numCrown, game);
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
			throw new java.lang.IllegalArgumentException(
					"Error occured while trying to read alldominoes.dat: " + e.getMessage());
		}
	}

	private Domino getdominoByID(int id) {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		for (Domino domino : game.getAllDominos()) {
			if (domino.getId() == id) {
				return domino;
			}
		}
		throw new java.lang.IllegalArgumentException("Domino with ID " + id + " not found.");
	}

	private TerrainType getTerrainType(String terrain) {
		switch (terrain) {
		case "W":
			return TerrainType.WheatField;
		case "F":
			return TerrainType.Forest;
		case "M":
			return TerrainType.Mountain;
		case "G":
			return TerrainType.Grass;
		case "S":
			return TerrainType.Swamp;
		case "L":
			return TerrainType.Lake;
		default:
			throw new java.lang.IllegalArgumentException("Invalid terrain type: " + terrain);
		}
	}

	private Player getPlayerByColor(String color) {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		for (Player player: game.getPlayers()) {
			if (player.getColor().toString().toLowerCase().equals(color)) {
				return player;
			}
		}
		System.out.println("invalid color name");
		return null;
	}

}