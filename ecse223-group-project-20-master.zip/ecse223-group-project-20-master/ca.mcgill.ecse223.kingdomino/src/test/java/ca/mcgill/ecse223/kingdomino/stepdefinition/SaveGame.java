package ca.mcgill.ecse223.kingdomino.stepdefinition;


import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import static org.junit.Assert.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import ca.mcgill.ecse223.kingdomino.KingdominoApplication;
import ca.mcgill.ecse223.kingdomino.persistence.KingDominoPersistence;
import ca.mcgill.ecse223.kingdomino.controller.Controller;
import ca.mcgill.ecse223.kingdomino.controller.InvalidInputException;
import ca.mcgill.ecse223.kingdomino.model.Castle;
import ca.mcgill.ecse223.kingdomino.model.Domino;
import ca.mcgill.ecse223.kingdomino.model.Game;
import ca.mcgill.ecse223.kingdomino.model.Kingdom;
import ca.mcgill.ecse223.kingdomino.model.Kingdomino;
import ca.mcgill.ecse223.kingdomino.model.Player;
import ca.mcgill.ecse223.kingdomino.model.TerrainType;
import ca.mcgill.ecse223.kingdomino.model.User;
import ca.mcgill.ecse223.kingdomino.model.Domino.DominoStatus;
import ca.mcgill.ecse223.kingdomino.model.DominoInKingdom.DirectionKind;
import ca.mcgill.ecse223.kingdomino.model.Player.PlayerColor;
import io.cucumber.datatable.dependency.com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SaveGame {
	
	   Kingdomino kingDomino;
	    private List<Player> players;
	    private List<Game> AllGames;
	    private boolean stillInProgress;
	    private File temp;
	    private boolean exist;
	    List<User> userList ;
	    private Game game;
	    
	    
	    @Given("the game is initialized for save game")
		public void the_program_is_started_and_ready_for_providing_user_profile() {
			   kingDomino = new Kingdomino();
			    game = new Game(48, kingDomino);
		        game.setNumberOfPlayers(4);
		        kingDomino.setCurrentGame(game);

		     addDefaultUsersAndPlayers(game);
			 createAllDominoes(game);
			 game.setNextPlayer(game.getPlayer(0));
			 for(int i = 0; i < 4; i++) {
				 User user = game.getPlayer(i).getUser();
				 
			 }
			 KingdominoApplication.setKingdomino(kingDomino);
		     
		}

	@Given("the game is still in progress")
	public void the_game_is_still_in_progress() {
		// Write code here that turns the phrase above into concrete actions
        Kingdomino kingdomino = KingdominoApplication.getKingdomino();
        Game current = kingdomino.getCurrentGame();

       stillInProgress = (!current.hasNextPlayer());
	}

	@Given("no file named {string} exists in the filesystem")
	public void no_file_named_exists_in_the_filesystem(String string) {
		
		 temp = new File(string);
        if(temp.exists() && !temp.isDirectory()){
          exist = true;
        }  else{
            exist = false;
        }
	}

	@When("the user initiates saving the game to a file named {string}")
	public void the_user_initiates_saving_the_game_to_a_file_named(String string) throws InvalidInputException {
		
		try {
			
   	 		Controller.save(kingDomino);
   	 		
   	 	} catch (InvalidInputException e) {
   	 		throw new InvalidInputException("cannot save file " + string);
   	 	}
	}

	@Then("a file named {string} shall be created in the filesystem")
	public void a_file_named_shall_be_created_in_the_filesystem(String string) throws Exception {
		try {
			String actual = KingDominoPersistence.getFile(string);
			assertEquals(string,actual);
		} catch (Exception e) {
			
			throw new Exception("file does not exist");
		}
		
	}

	@Given("the file named {string} exists in the filesystem")
	public void the_file_named_exists_in_the_filesystem(String string) {
		
		List<Object>  list = KingDominoPersistence.getFiles();
		File temp = new File(string);
		boolean exist = temp.exists();
	}

	@When("the user agrees to overwrite the existing file named {string}")
	public void the_user_agrees_to_overwrite_the_existing_file_named(String string) throws InvalidInputException {
	    try {
			
			Controller.save(kingDomino);
			 kingDomino = Controller.load(string);
		} catch (InvalidInputException e) {
			throw new InvalidInputException("cannot load a file with the name" + string);
		}
	    
	    
	}

	@Then("the file named {string} shall be updated in the filesystem")
	public void the_file_named_shall_be_updated_in_the_filesystem(String string) {
		
	  List<Object> listFiles = KingDominoPersistence.getFiles();
      assertNotEquals(kingDomino, listFiles.get(1));
	}
	
				///////////////////////////////////////
				/// -----Private Helper Methods---- ///
				///////////////////////////////////////

	private void addDefaultUsersAndPlayers(Game game) {
			String[] userNames = { "User1", "User2", "User3", "User4" };
			userList = game.getKingdomino().getUsers();
			for(int j = 0; j < userNames.length; j++) {
				
				String name = userNames[j];
				Player player = new Player(game);
				player.setColor(PlayerColor.values()[j]);
				
				//associate a user to a player 
				if(userList.contains(userNames[j])) {
					User user = User.getWithName(userNames[j]);
					player.setUser(user);
				}else {
					User user = User.getWithName(userNames[j]);
					player.setUser(user);
					
				}
				Kingdom kingdom = new Kingdom(player);
				new Castle(0, 0, kingdom, player);
			}
		}


	private void createAllDominoes(Game game) {
		try {
			BufferedReader br = new BufferedReader(new FileReader("src/main/resources/alldominoes.dat"));
			String line = "";
			String delimiters = "[:\\+()]";
			while ((line = br.readLine()) != null) {
				String[] dominoString = line.split(delimiters); // {id, leftTerrain, rightTerrain, crowns}
				int dominoId = Integer.decode(dominoString[0]);
				TerrainType leftTerrain = getTerrainType(dominoString[1]);
				TerrainType rightTerrain = getTerrainType(dominoString[2]);
				int numCrown = 0;
				if (dominoString.length > 3) {
					numCrown = Integer.decode(dominoString[3]);
				}
				new Domino(dominoId, leftTerrain, rightTerrain, numCrown, game);
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
			throw new java.lang.IllegalArgumentException(
					"Error occured while trying to read alldominoes.dat: " + e.getMessage());
		}
	}

	private Domino getdominoByID(int id) {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		for (Domino domino : game.getAllDominos()) {
			if (domino.getId() == id) {
				return domino;
			}
		}
		throw new java.lang.IllegalArgumentException("Domino with ID " + id + " not found.");
	}

	private TerrainType getTerrainType(String terrain) {
		switch (terrain) {
		case "W":
			return TerrainType.WheatField;
		case "F":
			return TerrainType.Forest;
		case "M":
			return TerrainType.Mountain;
		case "G":
			return TerrainType.Grass;
		case "S":
			return TerrainType.Swamp;
		case "L":
			return TerrainType.Lake;
		default:
			throw new java.lang.IllegalArgumentException("Invalid terrain type: " + terrain);
		}
	}

	private DirectionKind getDirection(String dir) {
		switch (dir) {
		case "up":
			return DirectionKind.Up;
		case "down":
			return DirectionKind.Down;
		case "left":
			return DirectionKind.Left;
		case "right":
			return DirectionKind.Right;
		default:
			throw new java.lang.IllegalArgumentException("Invalid direction: " + dir);
		}
	}

	private DominoStatus getDominoStatus(String status) {
		switch (status) {
		case "inPile":
			return DominoStatus.InPile;
		case "excluded":
			return DominoStatus.Excluded;
		case "inCurrentDraft":
			return DominoStatus.InCurrentDraft;
		case "inNextDraft":
			return DominoStatus.InNextDraft;
		case "erroneouslyPreplaced":
			return DominoStatus.ErroneouslyPreplaced;
		case "correctlyPreplaced":
			return DominoStatus.CorrectlyPreplaced;
		case "placedInKingdom":
			return DominoStatus.PlacedInKingdom;
		case "discarded":
			return DominoStatus.Discarded;
		default:
			throw new java.lang.IllegalArgumentException("Invalid domino status: " + status);
		}
	
	}
}
