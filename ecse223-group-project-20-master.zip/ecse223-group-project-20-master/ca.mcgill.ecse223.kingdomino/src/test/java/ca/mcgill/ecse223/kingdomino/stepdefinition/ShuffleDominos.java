package ca.mcgill.ecse223.kingdomino.stepdefinition;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import ca.mcgill.ecse223.kingdomino.KingdominoApplication;
import ca.mcgill.ecse223.kingdomino.controller.*;
import ca.mcgill.ecse223.kingdomino.model.*;
import ca.mcgill.ecse223.kingdomino.model.Domino.DominoStatus;
import ca.mcgill.ecse223.kingdomino.model.Draft.DraftStatus;
import ca.mcgill.ecse223.kingdomino.model.Player.PlayerColor;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ShuffleDominos {

	/**
	 * F#5: Shuffle domino pile: As a player, I want to play have a randomly
	 * shuffled pile of dominos so that every game becomes unique
	 *
	 * @author Michael Buchar
	 */

	@Given("the game is initialized for shuffle dominoes")
	public void the_game_is_initialized_for_shuffle_dominoes() {
		Kingdomino kd = new Kingdomino();
		Game game = new Game(48, kd);
		game.setNumberOfPlayers(4);
		kd.setCurrentGame(game);
		// Populate game
		createAllDominoes(game);
		KingdominoApplication.setKingdomino(kd);
	}

	@Given("there are {int} players playing")
	public void there_are_players_playing(Integer numPlayers) {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		addDefaultUsersAndPlayers(game);
		game.setNextPlayer(game.getPlayer(0));		
	}

	@When("the shuffling of dominoes is initiated")
	public void the_shuffling_of_dominoes_is_initiated() {
		Controller.shuffleDominoPile();// call controller
	}

	@Then("the first draft shall exist")
	public void the_first_draft_shall_exist() {
		Draft draft = KingdominoApplication.getKingdomino().getCurrentGame().getCurrentDraft();
		assertNotNull(draft);
	}

	@Then("the first draft should have {int} dominoes on the board face down")
	public void the_first_draft_should_have_dominoes_on_the_board_face_down(Integer expectedNum) {
		Draft draft = KingdominoApplication.getKingdomino().getCurrentGame().getCurrentDraft();
		Integer dominosInDraft = draft.numberOfIdUnsortedDominos();
		Draft.DraftStatus status = draft.getDraftStatus();
		assertEquals(expectedNum, dominosInDraft);
		assertEquals(Draft.DraftStatus.FaceDown, status);
	}

	@Then("there should be {int} dominoes left in the draw pile")
	public void there_should_be_dominoes_left_in_the_draw_pile(Integer expectedNum) {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		Integer dominosInPile = game.numberOfAllDominos() - game.getCurrentDraft().numberOfIdUnsortedDominos(); 
		assertEquals(expectedNum, dominosInPile);
	}

	@When("I initiate to arrange the domino in the fixed order {string}")
	public void i_initiate_to_arrange_the_domino_in_the_fixed_order(String string) {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		Draft draft = new Draft(DraftStatus.FaceDown, game);
		//initializing list of dominoes and shuffling it
		List<Domino> allDominos = game.getAllDominos();

		int dominosOnTable = 0;
		int numPlayers = game.getNumberOfPlayers();

		switch (numPlayers) { //setting domino counts for different # of players
			case 2: dominosOnTable = 4; break;
			case 3: dominosOnTable = 3; break;
			case 4: dominosOnTable = 4; break;
			default: break; 
		}

		Domino curDomino;
		for (int i = 0; i < game.getMaxPileSize(); i++) {
			curDomino = allDominos.get(i);  //probably i but might be i+1
			if (i < dominosOnTable) {
				curDomino.setStatus(DominoStatus.InCurrentDraft);
				draft.addIdUnsortedDomino(curDomino);
			}
			else {
				curDomino.setStatus(DominoStatus.InPile);
			}
		}
		game.setCurrentDraft(draft);
		game.setTopDominoInPile(allDominos.get(dominosOnTable)); //set top domino to first domino after draft
	}

	@Then("the draw pile should consist of everything in {string} except the first {int} dominoes with their order preserved")
	public void the_draw_pile_should_consist_of_everything_in_except_the_first_dominoes_with_their_order_preserved(String drawPile, Integer expectedDominosOnTable) {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		Draft draft = KingdominoApplication.getKingdomino().getCurrentGame().getCurrentDraft();

		List<Domino> allDominos = game.getAllDominos();
		List<Domino> dominosInDrawPile = new ArrayList<Domino>();

		for (Domino d : allDominos) {
			if(d.getStatus() != Domino.DominoStatus.InCurrentDraft) {
				dominosInDrawPile.add(d);
			}
		}

		Integer dominosOnTable = allDominos.size() - dominosInDrawPile.size();
		assertEquals(expectedDominosOnTable, dominosOnTable);
	}


//HELPER METHODS
	private void addDefaultUsersAndPlayers(Game game) {
		String[] users = { "User1", "User2", "User3", "User4" };
		for (int i = 0; i < users.length; i++) {
			game.getKingdomino().addUser(users[i]);
			Player player = new Player(game);
			player.setColor(PlayerColor.values()[i]);
			Kingdom kingdom = new Kingdom(player);
			new Castle(0, 0, kingdom, player);
		}
	}

	private void createAllDominoes(Game game) {
		try {
			BufferedReader br = new BufferedReader(new FileReader("src/main/resources/alldominoes.dat"));
			String line = "";
			String delimiters = "[:\\+()]";
			while ((line = br.readLine()) != null) {
				String[] dominoString = line.split(delimiters); // {id, leftTerrain, rightTerrain, crowns}
				int dominoId = Integer.decode(dominoString[0]);
				TerrainType leftTerrain = getTerrainType(dominoString[1]);
				TerrainType rightTerrain = getTerrainType(dominoString[2]);
				int numCrown = 0;
				if (dominoString.length > 3) {
					numCrown = Integer.decode(dominoString[3]);
				}
				new Domino(dominoId, leftTerrain, rightTerrain, numCrown, game);
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
			throw new java.lang.IllegalArgumentException(
					"Error occured while trying to read alldominoes.dat: " + e.getMessage());
		}
	}

	private TerrainType getTerrainType(String terrain) {
		switch (terrain) {
		case "W":
			return TerrainType.WheatField;
		case "F":
			return TerrainType.Forest;
		case "M":
			return TerrainType.Mountain;
		case "G":
			return TerrainType.Grass;
		case "S":
			return TerrainType.Swamp;
		case "L":
			return TerrainType.Lake;
		default:
			throw new java.lang.IllegalArgumentException("Invalid terrain type: " + terrain);
		}
	}

}