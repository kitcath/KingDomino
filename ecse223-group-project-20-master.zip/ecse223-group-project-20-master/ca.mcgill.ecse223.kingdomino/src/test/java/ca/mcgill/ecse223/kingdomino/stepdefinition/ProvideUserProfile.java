package ca.mcgill.ecse223.kingdomino.stepdefinition;
import java.io.File;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import ca.mcgill.ecse223.kingdomino.KingdominoApplication;
import ca.mcgill.ecse223.kingdomino.persistence.KingDominoPersistence;
import ca.mcgill.ecse223.kingdomino.controller.Controller;
import ca.mcgill.ecse223.kingdomino.controller.InvalidInputException;
import ca.mcgill.ecse223.kingdomino.model.Castle;
import ca.mcgill.ecse223.kingdomino.model.Domino;
import ca.mcgill.ecse223.kingdomino.model.Game;
import ca.mcgill.ecse223.kingdomino.model.Kingdom;
import ca.mcgill.ecse223.kingdomino.model.Kingdomino;
import ca.mcgill.ecse223.kingdomino.model.Player;
import ca.mcgill.ecse223.kingdomino.model.TerrainType;
import ca.mcgill.ecse223.kingdomino.model.User;
import ca.mcgill.ecse223.kingdomino.model.Domino.DominoStatus;
import ca.mcgill.ecse223.kingdomino.model.DominoInKingdom.DirectionKind;
import ca.mcgill.ecse223.kingdomino.model.Player.PlayerColor;
import io.cucumber.datatable.dependency.com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.datatable.DataTable;


public class ProvideUserProfile {

	 Kingdomino kingdomino;
	 private Game game;
	 List<User> userList ;
	 List<List<String>> userNames;
	 List<String>caseInsensitive;
	 String expectedUsername;
	 Integer playedGames;
	 Integer wonGames;
	 User aUser;
	
	 List<String> names;
	 String expectedName;
	 List<Map<String,String>> stats;

	@Given("the program is started and ready for providing user profile")
	public void the_program_is_started_and_ready_for_providing_user_profile() {
			this.kingdomino = new Kingdomino();
		    game = new Game(48, kingdomino);
	        game.setNumberOfPlayers(4);
	        kingdomino.setCurrentGame(game);

	     addDefaultUsersAndPlayers(game);
		 createAllDominoes(game);
		 game.setNextPlayer(game.getPlayer(0));
		 for(int i = 0; i < game.getPlayers().size(); i++) {
			 User user = game.getPlayer(i).getUser();
			
		 }
		 
		
		
	     
	}
 
		@Given("there are no users exist")
		public void there_are_no_users_exist() {
		/**    Kingdomino kingDomino = KingdominoApplication.getKingdomino();
			//game = kingDomino.getCurrentGame();
			int size = kingDomino.getUsers().size();
	        if(kingDomino.getUsers() != null) {
	        	List<Game> allGames = kingDomino.getAllGames();
	        	for(int i = 0; i < allGames.size(); i++) {
	        		Game game = allGames.get(i);
	        		for(int j = 0; j < game.getPlayers().size(); j++) {
	        			//game.getPlayer(j).setUser(null);
	        			//User user =	game.getPlayer(j).getUser();
	        			game.removePlayer(game.getPlayer(j));
	        		}
	        		
	        	}
	        }
	       
	      /*  int numberOfUsers = users.size();
	        if(numberOfUsers == 0){
	            exist = false;
	        }*/
			
		}
		
		@When("I provide my username {string} and initiate creating a new user")
		public void i_provide_my_username_and_initiate_creating_a_new_user(String string) {
			
			kingdomino.addUser(string);
			userList = kingdomino.getUsers();
			//User aUser = Controller.provideUserProfile(this.expectedName);
			
	
		
		}

		@Then("the user {string} shall be in the list of users")
		public void the_user_shall_be_in_the_list_of_users(String string) {

	           	this.expectedUsername = userList.get(0).getName();
	            assertEquals(string, expectedUsername);
     
		}
		    
		
		@Given("the following users exist:")
		public void the_following_users_exist(DataTable dataTable) {
		   game = KingdominoApplication.getKingdomino().getCurrentGame();    
		   this.userNames = dataTable.asLists();
		  
		}
		
		
		
		@Then("the user creation shall {string}")
		public void the_user_creation_shall(String string) {
			Kingdomino kingdomino = KingdominoApplication.getKingdomino();
			
			String actualStatus;
			
			String specialChars = "~`!@#$%^&*()-_=+\\|[{]};:'\",<.>/?  ";
			boolean numberPresent = false;
			boolean upperCasePresent = false;
			boolean lowerCasePresent = false;
			boolean specialCharacterPresent = false;
			
			
			userList = new ArrayList<User>();
			caseInsensitive = new ArrayList<String>();
			for(int i = 0; i <this.userNames.size()-1; i++) {
				aUser = User.getWithName(this.userNames.get(i).get(0));
				 userList.add(aUser);
				 caseInsensitive.add(this.userNames.get(i+1).get(0));
				
			}
		
			for(int i = 0; i <aUser .getName().length(); i++) {
				char current = aUser.getName().charAt(i);
				if(Character.isDigit(current)) {
					numberPresent = true;
				}else if(Character.isUpperCase(current)) {
					upperCasePresent = true;
					break;
				} else if(Character.isLowerCase(current)) {
					lowerCasePresent = true;
				}else if(specialChars.contains(String.valueOf(current))) {
					specialCharacterPresent = true;
					break;
				}
			}
			
			
			if(specialCharacterPresent || upperCasePresent) {
				actualStatus = "fail";
				assertEquals(string, actualStatus);
			}else if(!(kingdomino.getUsers().contains(aUser)) ){
				actualStatus = "succeed";
			}
			
			else if (!(caseInsensitive.contains(aUser.getName()))) {
				actualStatus = "succeed";
				assertEquals(string, actualStatus);
			}else {
				actualStatus = "fail";
				assertEquals(string, actualStatus);
			}
			
		}
		
		@When("I initiate the browsing of all users")
		public void i_initiate_the_browsing_of_all_users() throws Exception {
		Kingdomino kingdomino = KingdominoApplication.getKingdomino();
		List<User> aUser = kingdomino.getUsers();
		  for(int i = 0; i < aUser.size(); i++) {
			String aName =  kingdomino.getUser(i).getName();
			try {
				Controller.provideUserProfile(aName,true);
			} catch (Exception e3) {
				throw new Exception ("no user with that name exists");
			}
		  }
		}

		@Then("the users in the list shall be in the following alphabetical order:")
		public void the_users_in_the_list_shall_be_in_the_following_alphabetical_order(io.cucumber.datatable.DataTable dataTable) {
			
			
			String currentName,currentPosition;
			
			Kingdomino kingdomino = KingdominoApplication.getKingdomino();
			List<String >actual = new ArrayList<String>();
			 
			List<List<String>> userNames = dataTable.asLists();
			names = new ArrayList<String> ();
			
			for(int i = 1; i <userNames.size(); i++) {
				currentName = userNames.get(i).get(0);
				currentPosition = userNames.get(i).get(1);
				
				i_provide_my_username_and_initiate_creating_a_new_user(currentName);
				names.add(currentName);
			}	
			
			Collections.sort(names);

			for(int i = 0; i < actual.size(); i++) {
				assertEquals(names.get(i), userNames.get(i+1).get(0));
			
			}
			
		}

		/**
		 * @param dataTable
		 */
		@Given("the following users exist with their game statistics:")
		public void the_following_users_exist_with_their_game_statistics(io.cucumber.datatable.DataTable dataTable) {
			
			stats = dataTable.asMaps();
		 	for(Map<String,String> aMap : stats) {
		 		String username = aMap.get("name");
		 		Integer playedGames = Integer.decode(aMap.get("playedGames"));
		 		Integer wonGames = Integer.decode(aMap.get("wonGames"));
		 		
		 		User aUser = User.getWithName(username);
		 		aUser.setPlayedGames(playedGames);
		 		aUser.setWonGames(wonGames);
		 		this.kingdomino.addUser(aUser);
		 		
		 		}
		 	}
		

		@When("I initiate querying the game statistics for a user {string}")
		public void i_initiate_querying_the_game_statistics_for_a_user(String string) throws Exception{
		  
			try {
				Controller.provideUserProfile(string,false);
			} catch (Exception e1) {
				throw new InvalidInputException (" No user with such name exists");
			}
	
		    
		}
		
		@Then("the number of games played by {string} shall be {int}")
	    public void the_number_of_games_played_by_shall_be(String string, Integer int1) {
			
			User aUser = User.getWithName(string);
			Integer actualPlayed = aUser.getPlayedGames();
	    	assertEquals(int1,actualPlayed);
	    	  
	       
	    }

	    @Then("the number of games won by {string} shall be {int}")
	    public void the_number_of_games_won_by_shall_be(String string, Integer int1) {
	    
	    
		 	
	   
	      User aUser = User.getWithName(string);
	      Integer actualWins =   aUser.getWonGames();
	      assertEquals(int1, actualWins);
	    }

	
		
@After
	public void tearDown() {
		Kingdomino kingdomino = KingdominoApplication.getKingdomino();
		if (kingdomino != null) {
			kingdomino.delete();
		}
	}
	// helper classes
		private void addDefaultUsersAndPlayers(Game game) {
			String[] userNames = { "User1", "User2", "User3", "User4" };
			userList = game.getKingdomino().getUsers();
			for(int j = 0; j < userNames.length; j++) {
				
				String name = userNames[j];
				Player player = new Player(game);
				player.setColor(PlayerColor.values()[j]);
				
				//associate a user to a player 
				if(userList.contains(userNames[j])) {
					User user = User.getWithName(userNames[j]);
					player.setUser(user);
				}else {
					User user = User.getWithName(userNames[j]);
					player.setUser(user);
					
					/*User user = new User(userNames[j], kingdomino);
					kingdomino.addUser(userNames[j]);
					player.setUser(user);
					*/
				}
				Kingdom kingdom = new Kingdom(player);
				new Castle(0, 0, kingdom, player);
			}
		}

		private void createAllDominoes(Game game) {
			try {
				BufferedReader br = new BufferedReader(new FileReader("src/main/resources/alldominoes.dat"));
				String line = "";
				String delimiters = "[:\\+()]";
				while ((line = br.readLine()) != null) {
					String[] dominoString = line.split(delimiters); // {id, leftTerrain, rightTerrain, crowns}
					int dominoId = Integer.decode(dominoString[0]);
					TerrainType leftTerrain = getTerrainType(dominoString[1]);
					TerrainType rightTerrain = getTerrainType(dominoString[2]);
					int numCrown = 0;
					if (dominoString.length > 3) {
						numCrown = Integer.decode(dominoString[3]);
					}
					new Domino(dominoId, leftTerrain, rightTerrain, numCrown, game);
				}
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
				throw new java.lang.IllegalArgumentException(
						"Error occured while trying to read alldominoes.dat: " + e.getMessage());
			}
		}

		private TerrainType getTerrainType(String terrain) {
			switch (terrain) {
			case "W":
				return TerrainType.WheatField;
			case "F":
				return TerrainType.Forest;
			case "M":
				return TerrainType.Mountain;
			case "G":
				return TerrainType.Grass;
			case "S":
				return TerrainType.Swamp;
			case "L":
				return TerrainType.Lake;
			default:
				throw new java.lang.IllegalArgumentException("Invalid terrain type: " + terrain);
			}
		}

		private DirectionKind getDirection(String dir) {
			switch (dir) {
			case "up":
				return DirectionKind.Up;
			case "down":
				return DirectionKind.Down;
			case "left":
				return DirectionKind.Left;
			case "right":
				return DirectionKind.Right;
			default:
				throw new java.lang.IllegalArgumentException("Invalid direction: " + dir);
			}
		}

		private DominoStatus getDominoStatus(String status) {
			switch (status) {
			case "inPile":
				return DominoStatus.InPile;
			case "excluded":
				return DominoStatus.Excluded;
			case "inCurrentDraft":
				return DominoStatus.InCurrentDraft;
			case "inNextDraft":
				return DominoStatus.InNextDraft;
			case "erroneouslyPreplaced":
				return DominoStatus.ErroneouslyPreplaced;
			case "correctlyPreplaced":
				return DominoStatus.CorrectlyPreplaced;
			case "placedInKingdom":
				return DominoStatus.PlacedInKingdom;
			case "discarded":
				return DominoStatus.Discarded;
			default:
				throw new java.lang.IllegalArgumentException("Invalid domino status: " + status);
			}
		}
}
