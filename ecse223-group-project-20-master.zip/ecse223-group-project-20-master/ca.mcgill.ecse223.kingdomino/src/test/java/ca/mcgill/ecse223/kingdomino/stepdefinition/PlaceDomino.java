package ca.mcgill.ecse223.kingdomino.stepdefinition;

import static org.junit.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import ca.mcgill.ecse223.kingdomino.controller.Controller;
import ca.mcgill.ecse223.kingdomino.controller.InvalidInputException;
import ca.mcgill.ecse223.kingdomino.KingdominoApplication;
import ca.mcgill.ecse223.kingdomino.model.Castle;
import ca.mcgill.ecse223.kingdomino.model.Domino;
import ca.mcgill.ecse223.kingdomino.model.DominoInKingdom;
import ca.mcgill.ecse223.kingdomino.model.DominoSelection;
import ca.mcgill.ecse223.kingdomino.model.Draft;
import ca.mcgill.ecse223.kingdomino.model.Draft.DraftStatus;
import ca.mcgill.ecse223.kingdomino.model.Player.PlayerColor;
import ca.mcgill.ecse223.kingdomino.model.Game;
import ca.mcgill.ecse223.kingdomino.model.Kingdom;
import ca.mcgill.ecse223.kingdomino.model.KingdomTerritory;
import ca.mcgill.ecse223.kingdomino.model.Kingdomino;
import ca.mcgill.ecse223.kingdomino.model.Player;
import ca.mcgill.ecse223.kingdomino.model.TerrainType;
import ca.mcgill.ecse223.kingdomino.model.User;
import ca.mcgill.ecse223.kingdomino.model.Domino.DominoStatus;
import ca.mcgill.ecse223.kingdomino.model.DominoInKingdom.DirectionKind;
import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class PlaceDomino {

	@Given("the {string}'s kingdom has the following dominoes:")
	public void the_s_kingdom_has_the_following_dominoes(String string, io.cucumber.datatable.DataTable dataTable) {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		List<Map<String, String>> valueMaps = dataTable.asMaps();
		for (Map<String, String> map : valueMaps) {
			// Get values from cucumber table
			Integer id = Integer.decode(map.get("domino"));
			DirectionKind dir = getDirection(map.get("dominodir"));
			Integer posx = Integer.decode(map.get("posx"));
			Integer posy = Integer.decode(map.get("posy"));
	
			// Add the domino to a player's kingdom
			Domino dominoToPlace = getdominoByID(id);
			Kingdom kingdom = Controller.getCurrentPlayer().getKingdom();
			DominoInKingdom domInKingdom = new DominoInKingdom(posx, posy, kingdom, dominoToPlace);
			domInKingdom.setDirection(dir);
			dominoToPlace.setStatus(DominoStatus.PlacedInKingdom);
		}
	}
	
	private int posX;
	private int posY;
	private DirectionKind direction;
	
	@Given("domino {int} is tentatively placed at position {int}:{int} with the direction {string}")
	public void domino_is_tentatively_placed_at_position_with_direction(Integer int1, Integer int2, Integer int3, String string) {
		Kingdomino kingdomino = KingdominoApplication.getKingdomino();
		Game game = kingdomino.getCurrentGame();
		Player player = Controller.getCurrentPlayer();
		Kingdom kingdom = player.getKingdom();
		Domino domino = game.getCurrentDraft().getIdUnsortedDomino(0);
		
		posX = int2;
		posY = int3;
		
		switch(string) {
			case "up":
				direction = DirectionKind.Up;
				break;
			case "left":
				direction = DirectionKind.Left;
				break;
			case "down":
				direction = DirectionKind.Down;
				break;
			case "right":
				direction = DirectionKind.Right;
				break;
		}

	}
	
	@Given("domino {int} is in {string} status")
	public void domino_is_in_status(Integer int1, String string) {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		Domino domino = null;
		for(int j = 0; j<game.getAllDominos().size(); j++) {
			if(game.getAllDominos().get(j).getId() == int1) {
				domino = game.getAllDominos().get(j);
			}
		}
		DominoStatus status = null;
		switch(string) {
		case "CorrectlyPreplaced":
			status = DominoStatus.CorrectlyPreplaced;
			break;
		case "Excluded":
			status =DominoStatus.Excluded;
			break;
		case "InPile":
			status = DominoStatus.InPile;
			break;
		case "InNextDraft":
			status = DominoStatus.InNextDraft;
			break;
		case "InCurrentDraft":
			status = DominoStatus.InCurrentDraft;
			break;
		case "ErroneouslyPreplaced":
			status = DominoStatus.ErroneouslyPreplaced;
			break;
		case "PlacedInKingdom":
			status = DominoStatus.PlacedInKingdom;
			break;
		case "Discarded":
			status = DominoStatus.Discarded;
			break;
	}
		domino.setStatus(status);
	}
	
	@When("{string} requests to place the selected domino {int}")
	public void requests_to_place_the_selected_domino(String string, Integer int1) throws InvalidInputException {
	    Kingdomino kingdomino = KingdominoApplication.getKingdomino();
		Game game = kingdomino.getCurrentGame();
		Player player = Controller.getCurrentPlayer();
		

		Domino domino = getdominoByID(int1);
		
		Controller.placeCurrentDomino(player, domino, posX, posY, direction);
		
	}
	
	@Then("{string}'s kingdom should now have domino {int} at position {int}:{int} with direction {string}")
	public void s_kingdom_should_now_have_domino_at_position_with_direction(String string, Integer int1, Integer int2, Integer int3, String string2) {
		Kingdomino kingdomino = KingdominoApplication.getKingdomino();
		Game game = kingdomino.getCurrentGame();
		Player player = Controller.getCurrentPlayer();
		
		//Player name:
		assertEquals(player.getColor(), getColorType(string));
		Kingdom kingdom = player.getKingdom();
		
		Domino domino = null;
		for(int i = 0; i<game.getAllDominos().size(); i++) {
			if(game.getAllDominos().get(i).getId() == int1) {
				domino = game.getAllDominos().get(i);
			}
		}
		
		DominoInKingdom placedDomino = null;
		for(int i = 0; i<kingdom.getTerritories().size(); i++) {
			if(( kingdom.getTerritories().get(i)) instanceof DominoInKingdom && ((DominoInKingdom) kingdom.getTerritories().get(i)).getDomino().getId() == int1) {
				placedDomino = (DominoInKingdom) kingdom.getTerritories().get(i);
			}
		}
		//X:
		assert(placedDomino.getX() == int2);
		//Y:
		assert(placedDomino.getY() == int3);
	}
	
	

	public PlayerColor getColorType(String color) {
		switch (color.toLowerCase()) {
		case "blue":
			return PlayerColor.Blue;
		case "green":
			return PlayerColor.Green;
		case "yellow":
			return PlayerColor.Yellow;
		case "pink":
			return PlayerColor.Pink;
		}
		return PlayerColor.Blue;
	}

	
	@After
	public void tearDown() {
		Kingdomino kingdomino = KingdominoApplication.getKingdomino();
		if (kingdomino != null) {
			kingdomino.delete();
		}
	}
	
	
	
	//HELPER METHODS-----------------------------------------------------------------------------------
	
		/**
		 * @author Alexandra Gafencu (modified by Niilo Vuokila)
		 * @param id
		 * @return a DominoInKindom
		 */
		private DominoInKingdom getDominoInKingdomByID(int id) {
			//Game game = KingdominoApplication.getKingdomino().getCurrentGame();
			
			Player p1 = Controller.getCurrentPlayer();
			List<KingdomTerritory> t =  p1.getKingdom().getTerritories();
			
			for(KingdomTerritory aDomino:Controller.getCurrentPlayer().getKingdom().getTerritories()) {
			
				if(aDomino instanceof DominoInKingdom) {
					DominoInKingdom domInKingdom=(DominoInKingdom) aDomino;
					if(domInKingdom.getDomino().getId()==id) {
						return domInKingdom;
					}
				}
			}
			return null;
		}
	
	
		private void addDefaultUsersAndPlayers(Game game) {
			String[] userNames = { "User1", "User2", "User3", "User4" };
			for (int i = 0; i < userNames.length; i++) {
				User user = game.getKingdomino().addUser(userNames[i]);
				Player player = new Player(game);
				player.setUser(user);
				player.setColor(PlayerColor.values()[i]);
				Kingdom kingdom = new Kingdom(player);
				new Castle(0, 0, kingdom, player);
			}
		}

		private void createAllDominoes(Game game) {
			try {
				BufferedReader br = new BufferedReader(new FileReader("src/main/resources/alldominoes.dat"));
				String line = "";
				String delimiters = "[:\\+()]";
				while ((line = br.readLine()) != null) {
					String[] dominoString = line.split(delimiters); // {id, leftTerrain, rightTerrain, crowns}
					int dominoId = Integer.decode(dominoString[0]);
					TerrainType leftTerrain = getTerrainType(dominoString[1]);
					TerrainType rightTerrain = getTerrainType(dominoString[2]);
					int numCrown = 0;
					if (dominoString.length > 3) {
						numCrown = Integer.decode(dominoString[3]);
					}
					new Domino(dominoId, leftTerrain, rightTerrain, numCrown, game);
				}
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
				throw new java.lang.IllegalArgumentException(
						"Error occured while trying to read alldominoes.dat: " + e.getMessage());
			}
		}

		private Domino getdominoByID(int id) {
			Game game = KingdominoApplication.getKingdomino().getCurrentGame();
			for (Domino domino : game.getAllDominos()) {
				if (domino.getId() == id) {
					return domino;
				}
			}
			throw new java.lang.IllegalArgumentException("Domino with ID " + id + " not found.");
		}

		private TerrainType getTerrainType(String terrain) {
			switch (terrain) {
			case "W":
				return TerrainType.WheatField;
			case "F":
				return TerrainType.Forest;
			case "M":
				return TerrainType.Mountain;
			case "G":
				return TerrainType.Grass;
			case "S":
				return TerrainType.Swamp;
			case "L":
				return TerrainType.Lake;
			default:
				throw new java.lang.IllegalArgumentException("Invalid terrain type: " + terrain);
			}
		}

		private DirectionKind getDirection(String dir) {
			switch (dir) {
			case "up":
				return DirectionKind.Up;
			case "down":
				return DirectionKind.Down;
			case "left":
				return DirectionKind.Left;
			case "right":
				return DirectionKind.Right;
			default:
				throw new java.lang.IllegalArgumentException("Invalid direction: " + dir);
			}
		}

		private DominoStatus getDominoStatus(String status) {
			switch (status) {
			case "inPile":
				return DominoStatus.InPile;
			case "excluded":
				return DominoStatus.Excluded;
			case "inCurrentDraft":
				return DominoStatus.InCurrentDraft;
			case "inNextDraft":
				return DominoStatus.InNextDraft;
			case "erroneouslyPreplaced":
				return DominoStatus.ErroneouslyPreplaced;
			case "correctlyPreplaced":
				return DominoStatus.CorrectlyPreplaced;
			case "placedInKingdom":
				return DominoStatus.PlacedInKingdom;
			case "discarded":
				return DominoStatus.Discarded;
			default:
				throw new java.lang.IllegalArgumentException("Invalid domino status: " + status);
			}
		}

}
