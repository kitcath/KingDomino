package ca.mcgill.ecse223.kingdomino.stepdefinition;

import static org.junit.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import ca.mcgill.ecse223.kingdomino.KingdominoApplication;
import ca.mcgill.ecse223.kingdomino.controller.Controller;
import ca.mcgill.ecse223.kingdomino.model.Castle;
import ca.mcgill.ecse223.kingdomino.model.Domino;
import ca.mcgill.ecse223.kingdomino.model.Draft;
import ca.mcgill.ecse223.kingdomino.model.Game;
import ca.mcgill.ecse223.kingdomino.model.Kingdom;
import ca.mcgill.ecse223.kingdomino.model.Kingdomino;
import ca.mcgill.ecse223.kingdomino.model.Player;
import ca.mcgill.ecse223.kingdomino.model.TerrainType;
import ca.mcgill.ecse223.kingdomino.model.User;
import ca.mcgill.ecse223.kingdomino.model.Domino.DominoStatus;
import ca.mcgill.ecse223.kingdomino.model.DominoInKingdom.DirectionKind;
import ca.mcgill.ecse223.kingdomino.model.Draft.DraftStatus;
import ca.mcgill.ecse223.kingdomino.model.Player.PlayerColor;
import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class OrderAndRevealNextDraft {
	
	List<User> userList;
	
	@Given("the game is initialized for order next draft of dominoes")
	public void the_game_is_initialized_for_order_next_draft_of_dominoes() {
		// Intialize empty game
		Kingdomino kingdomino = new Kingdomino();
		Game game = new Game(48, kingdomino);
		game.setNumberOfPlayers(4);
		kingdomino.setCurrentGame(game);
		// Populate game
		addDefaultUsersAndPlayers(game);
		createAllDominoes(game);
		game.setNextPlayer(game.getPlayer(0));
		 for(int i = 0; i < 4; i++) {
			 User user = game.getPlayer(i).getUser();
			//kingdomino.addUser(user);
		 }
		KingdominoApplication.setKingdomino(kingdomino);
		Draft draft = new Draft(DraftStatus.FaceDown, game);
		game.setNextDraft(draft);
	}

	@Given("the dominoes in next draft are facing down")
	public void the_dominoes_in_next_draft_are_facing_down() {
		Draft draft = KingdominoApplication.getKingdomino().getCurrentGame().getNextDraft();
		draft.setDraftStatus(DraftStatus.FaceDown);
	}

	@Given("the next draft is {string}")
	public void the_next_draft_is(String string) {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
	    Draft draft = game.getNextDraft();
	    
	    //searching for all the dominos in list of all dominos:
	    String[] splitString = string.split(",", 0);
	    for(int i =0; i<splitString.length; i+=1) {
	    	for(int j =0; j<game.getAllDominos().size(); j+=1) {
	    		if(game.getAllDominos().get(j).getId() == (int) Integer.parseInt(splitString[i])) {
	    			draft.addIdUnsortedDomino(game.getAllDominos().get(j));
	    		}
	    	}
	    }
	}

	@When("the ordering of the dominoes in the next draft is initiated")
	public void the_ordering_of_the_dominoes_in_the_next_draft_is_initiated() {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		Controller.orderAndRevealNextDraft();
	}

	@Then("the status of the next draft is sorted")
	public void the_status_of_the_next_draft_is_sorted() {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		Draft draft = game.getNextDraft();
	    assertEquals(draft.getDraftStatus(), DraftStatus.Sorted);
	}

	@Then("the order of dominoes in the draft will be {string}")
	public void the_order_of_dominoes_in_the_draft_will_be(String string) {
		Game game = KingdominoApplication.getKingdomino().getCurrentGame();
		Draft draft = game.getNextDraft();
		
		String[] splitString = string.split(",", 0);
		for(int i = 0; i < splitString.length; i++) {
			assertEquals((int) Integer.parseInt(splitString[i]), (int) draft.getIdSortedDominos().get(i).getId());
		}
	}

	@Given("the game is initialized for reveal next draft of dominoes")
	public void the_game_is_initialized_for_reveal_next_draft_of_dominoes() {
		// Intialize empty game
		Kingdomino kingdomino = new Kingdomino();
		Game game = new Game(48, kingdomino);
		game.setNumberOfPlayers(4);
		kingdomino.setCurrentGame(game);
		// Populate game
		addDefaultUsersAndPlayers(game);
		createAllDominoes(game);
		game.setNextPlayer(game.getPlayer(0));
		KingdominoApplication.setKingdomino(kingdomino);
		Draft draft = new Draft(DraftStatus.FaceDown, game);
		game.setNextDraft(draft);
	}

	@Given("the dominoes in next draft are sorted")
	public void the_dominoes_in_next_draft_are_sorted() {
		KingdominoApplication.getKingdomino().getCurrentGame().getNextDraft().setDraftStatus(DraftStatus.Sorted);
	}

	@When("the revealing of the dominoes in the next draft is initiated")
	public void the_revealing_of_the_dominoes_in_the_next_draft_is_initiated() {
	    // Write code here that turns the phrase above into concrete actions
		Controller.orderAndRevealNextDraft();
	}

	@Then("the status of the next draft is face up")
	public void the_status_of_the_next_draft_is_face_up() {
		assertEquals(KingdominoApplication.getKingdomino().getCurrentGame().getNextDraft().getDraftStatus(), DraftStatus.FaceUp);
	}

	@After
	public void tearDown() {
		Kingdomino kingdomino = KingdominoApplication.getKingdomino();
		if (kingdomino != null) {
			kingdomino.delete();
		}
	}
	
	
	
	//HELPER METHODS-----------------------------------------------------------------------------------

	private void addDefaultUsersAndPlayers(Game game) {
		String[] userNames = { "User1", "User2", "User3", "User4" };
		userList = game.getKingdomino().getUsers();
		for(int j = 0; j < userNames.length; j++) {
			
			String name = userNames[j];
			Player player = new Player(game);
			player.setColor(PlayerColor.values()[j]);
			
			//associate a user to a player 
			if(userList.contains(userNames[j])) {
				User user = User.getWithName(userNames[j]);
				player.setUser(user);
			}else {
				User user = User.getWithName(userNames[j]);
				player.setUser(user);
				
				/*User user = new User(userNames[j], kingdomino);
				kingdomino.addUser(userNames[j]);
				player.setUser(user);
				*/
			}
			Kingdom kingdom = new Kingdom(player);
			new Castle(0, 0, kingdom, player);
		}
	}

	private void createAllDominoes(Game game) {
		try {
			BufferedReader br = new BufferedReader(new FileReader("src/main/resources/alldominoes.dat"));
			String line = "";
			String delimiters = "[:\\+()]";
			while ((line = br.readLine()) != null) {
				String[] dominoString = line.split(delimiters); // {id, leftTerrain, rightTerrain, crowns}
				int dominoId = Integer.decode(dominoString[0]);
				TerrainType leftTerrain = getTerrainType(dominoString[1]);
				TerrainType rightTerrain = getTerrainType(dominoString[2]);
				int numCrown = 0;
				if (dominoString.length > 3) {
					numCrown = Integer.decode(dominoString[3]);
				}
				new Domino(dominoId, leftTerrain, rightTerrain, numCrown, game);
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
			throw new java.lang.IllegalArgumentException(
					"Error occured while trying to read alldominoes.dat: " + e.getMessage());
		}
	}

	private TerrainType getTerrainType(String terrain) {
		switch (terrain) {
		case "W":
			return TerrainType.WheatField;
		case "F":
			return TerrainType.Forest;
		case "M":
			return TerrainType.Mountain;
		case "G":
			return TerrainType.Grass;
		case "S":
			return TerrainType.Swamp;
		case "L":
			return TerrainType.Lake;
		default:
			throw new java.lang.IllegalArgumentException("Invalid terrain type: " + terrain);
		}
	}
}
